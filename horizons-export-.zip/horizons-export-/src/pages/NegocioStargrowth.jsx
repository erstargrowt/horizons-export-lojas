
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { CheckCircle, ArrowRight, Target, Zap, Shield, HelpCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { Link } from 'react-router-dom';

const NegocioStargrowth = () => {
  const benefits = [
    { title: 'Modelo Validado', desc: 'Estratégias testadas e aprovadas no mercado.' },
    { title: 'Baixo Risco', desc: 'Investimento inicial controlado e alta escalabilidade.' },
    { title: 'Suporte Total', desc: 'Acompanhamento do início ao fim da sua jornada.' },
    { title: 'Alta Rentabilidade', desc: 'Margens de lucro acima da média do mercado.' },
    { title: 'Networking', desc: 'Conexão com empreendedores de sucesso.' }
  ];

  const steps = [
    { num: '01', title: 'Cadastro', desc: 'Inscreva-se na plataforma e preencha seu perfil.' },
    { num: '02', title: 'Treinamento', desc: 'Acesse o conteúdo inicial e prepare-se.' },
    { num: '03', title: 'Planejamento', desc: 'Defina suas metas e plano de ação com mentores.' },
    { num: '04', title: 'Execução', desc: 'Coloque em prática e comece a gerar resultados.' },
  ];

  return (
    <>
      <Helmet>
        <title>Negócio Stargrowth - Seu Caminho para o Sucesso</title>
        <meta name="description" content="Descubra como empreender com segurança e alta rentabilidade com o modelo de negócio Stargrowth." />
      </Helmet>

      {/* Hero */}
      <section className="pt-20 pb-32 bg-[#003366] relative overflow-hidden text-white">
        <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
        <div className="container mx-auto px-4 relative z-10 text-center">
           <motion.h1 
             initial={{ opacity: 0, y: 20 }}
             animate={{ opacity: 1, y: 0 }}
             className="text-5xl md:text-7xl font-montserrat font-bold mb-8"
           >
             O Negócio do <span className="text-[#D4AF37]">Futuro</span>
           </motion.h1>
           <p className="text-xl md:text-2xl text-gray-300 max-w-3xl mx-auto mb-12 font-light">
             Um ecossistema completo desenhado para transformar sua ambição em resultados reais e escaláveis.
           </p>
           <button className="bg-[#D4AF37] hover:bg-[#F4D03F] text-[#003366] font-bold py-4 px-10 rounded-full text-lg transition-transform hover:scale-105 shadow-lg shadow-[#D4AF37]/20">
             Quero Fazer Parte
           </button>
        </div>
      </section>

      {/* Description */}
      <section className="py-20 bg-white -mt-20 relative z-20 rounded-t-[3rem]">
         <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-16 items-center">
               <div>
                  <h2 className="text-4xl font-bold text-[#003366] mb-6 font-montserrat">Por que Stargrowth?</h2>
                  <p className="text-gray-600 leading-relaxed mb-6 text-lg">
                     Nascemos da necessidade de profissionalizar o empreendedorismo digital. Combinamos educação de ponta, tecnologia proprietária e uma comunidade vibrante para criar um ambiente onde o sucesso é a consequência natural do esforço direcionado.
                  </p>
                  <p className="text-gray-600 leading-relaxed text-lg">
                     Não vendemos atalhos. Oferecemos um mapa, uma bússola e companheiros de jornada experientes.
                  </p>
               </div>
               <div className="grid grid-cols-2 gap-4">
                  <img src="https://images.unsplash.com/photo-1552664730-d307ca884978" className="rounded-2xl shadow-xl w-full h-64 object-cover mt-8" />
                  <img src="https://images.unsplash.com/photo-1542744173-8e7e53415bb0" className="rounded-2xl shadow-xl w-full h-64 object-cover" />
               </div>
            </div>
         </div>
      </section>

      {/* Benefits Grid */}
      <section className="py-20 bg-gray-50">
         <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center text-[#003366] mb-16">Benefícios Exclusivos</h2>
            <div className="grid md:grid-cols-3 lg:grid-cols-5 gap-6">
               {benefits.map((b, i) => (
                  <motion.div 
                    key={i}
                    whileHover={{ y: -10 }}
                    className="bg-white p-6 rounded-xl shadow-lg border-t-4 border-[#D4AF37] text-center"
                  >
                     <div className="bg-blue-50 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4 text-[#003366]">
                        <CheckCircle size={24} />
                     </div>
                     <h3 className="font-bold text-[#003366] mb-2">{b.title}</h3>
                     <p className="text-sm text-gray-500">{b.desc}</p>
                  </motion.div>
               ))}
            </div>
         </div>
      </section>

      {/* How it Works */}
      <section className="py-20 bg-[#003366] text-white">
         <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-16">Como Funciona</h2>
            <div className="grid md:grid-cols-4 gap-8">
               {steps.map((s, i) => (
                  <div key={i} className="relative">
                     <div className="text-6xl font-black text-white/10 absolute -top-8 -left-4">{s.num}</div>
                     <div className="relative z-10 bg-white/5 backdrop-blur-sm p-6 rounded-xl border border-white/10 h-full hover:bg-white/10 transition-colors">
                        <h3 className="text-xl font-bold text-[#D4AF37] mb-3">{s.title}</h3>
                        <p className="text-gray-300">{s.desc}</p>
                     </div>
                  </div>
               ))}
            </div>
         </div>
      </section>

      {/* FAQ */}
      <section className="py-20 bg-white">
         <div className="container mx-auto px-4 max-w-3xl">
            <h2 className="text-3xl font-bold text-center text-[#003366] mb-12">Perguntas Frequentes</h2>
            <div className="space-y-4">
               {[
                 { q: 'Preciso ter experiência prévia?', a: 'Não. Nosso modelo é desenhado para ensinar do zero.' },
                 { q: 'Qual o investimento inicial?', a: 'Temos planos acessíveis a partir de R$ 997, adequados para diferentes estágios.' },
                 { q: 'Quanto tempo para ver resultados?', a: 'A maioria dos alunos começa a ter retorno nos primeiros 90 dias.' },
                 { q: 'O suporte é vitalício?', a: 'Depende do plano escolhido, mas garantimos suporte intensivo inicial para todos.' }
               ].map((faq, i) => (
                  <details key={i} className="group bg-gray-50 rounded-xl p-6 cursor-pointer open:bg-white open:shadow-lg transition-all border border-gray-100">
                     <summary className="flex justify-between items-center font-bold text-[#003366] list-none">
                        {faq.q}
                        <ChevronDown className="group-open:rotate-180 transition-transform" />
                     </summary>
                     <p className="mt-4 text-gray-600">{faq.a}</p>
                  </details>
               ))}
            </div>
         </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-gradient-to-r from-[#003366] to-[#004d99] text-center">
         <div className="container mx-auto px-4">
            <h2 className="text-4xl font-bold text-white mb-8">Seu futuro começa com uma decisão</h2>
            <Link to="/plano-de-negocio" className="inline-flex items-center gap-2 bg-[#D4AF37] hover:bg-[#F4D03F] text-[#003366] font-bold py-5 px-12 rounded-full text-xl transition-all shadow-xl hover:shadow-2xl hover:-translate-y-1">
               Ver Planos Disponíveis <ArrowRight />
            </Link>
         </div>
      </section>
    </>
  );
};

export default NegocioStargrowth;
