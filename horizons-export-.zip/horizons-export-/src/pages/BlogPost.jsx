
import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Clock, Calendar, ChevronLeft, Share2, Facebook, Linkedin, Twitter, MessageCircle } from 'lucide-react';
import { blogPosts } from '@/data/blog';
import { products } from '@/data/products';
import { useGoogleAnalytics } from '@/context/GoogleAnalyticsContext';

const BlogPost = () => {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { trackEvent } = useGoogleAnalytics();
  
  const post = blogPosts.find(p => p.slug === slug);

  if (!post) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <h2 className="text-2xl font-bold text-[#003366] mb-4">Artigo não encontrado</h2>
        <button 
          onClick={() => navigate('/blog')}
          className="text-[#D4AF37] font-bold hover:underline"
        >
          Voltar para o Blog
        </button>
      </div>
    );
  }

  // Get recommended products
  const recommendedProducts = products.filter(p => post.recommendedProducts.includes(p.id));

  // Find prev/next posts for navigation
  const currentIndex = blogPosts.findIndex(p => p.id === post.id);
  const prevPost = currentIndex > 0 ? blogPosts[currentIndex - 1] : null;
  const nextPost = currentIndex < blogPosts.length - 1 ? blogPosts[currentIndex + 1] : null;

  const shareUrl = window.location.href;
  const shareText = `Confira este artigo incrível da Stargrowth: ${post.title}`;

  const handleShare = (platform) => {
    trackEvent('share', { method: platform, content_type: 'blog_post', item_id: slug });
    let url = '';
    switch (platform) {
      case 'whatsapp':
        url = `https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`;
        break;
      case 'facebook':
        url = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`;
        break;
      case 'twitter':
        url = `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`;
        break;
      case 'linkedin':
        url = `https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(shareUrl)}&title=${encodeURIComponent(post.title)}`;
        break;
      default:
        break;
    }
    window.open(url, '_blank');
  };

  const handleNavigation = (newSlug) => {
    trackEvent('select_content', {
      content_type: 'blog_post',
      item_id: newSlug
    });
    navigate(`/blog/${newSlug}`);
  };

  return (
    <>
      <Helmet>
        <title>{post.title} - Blog Stargrowth</title>
        <meta name="description" content={post.description} />
      </Helmet>

      <div className="min-h-screen bg-white">
        {/* Hero Image */}
        <div className="w-full h-[40vh] md:h-[50vh] relative overflow-hidden">
          <img 
            src={post.image} 
            alt={post.title} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
          
          <div className="absolute bottom-0 left-0 w-full p-6 md:p-12 text-white container mx-auto">
             <motion.div
               initial={{ opacity: 0, y: 20 }}
               animate={{ opacity: 1, y: 0 }}
               transition={{ duration: 0.6 }}
               className="max-w-4xl"
             >
                <div className="flex items-center gap-2 mb-4">
                  <button 
                    onClick={() => navigate('/blog')}
                    className="flex items-center gap-1 text-sm font-bold text-[#D4AF37] hover:text-white transition-colors bg-black/30 backdrop-blur px-3 py-1 rounded-full"
                  >
                    <ChevronLeft size={16} /> Voltar para Blog
                  </button>
                  <span className="bg-[#D4AF37] text-[#003366] text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                    {post.category}
                  </span>
                </div>

                <h1 className="text-3xl md:text-5xl lg:text-6xl font-montserrat font-bold leading-tight mb-4 text-shadow">
                  {post.title}
                </h1>

                <div className="flex flex-wrap items-center gap-6 text-sm md:text-base font-medium text-gray-200">
                  <span className="flex items-center gap-2">
                    <img 
                      src={`https://ui-avatars.com/api/?name=${post.author}&background=random`} 
                      alt={post.author} 
                      className="w-8 h-8 rounded-full border-2 border-[#D4AF37]"
                    />
                    {post.author}
                  </span>
                  <span className="flex items-center gap-2">
                    <Calendar size={18} className="text-[#D4AF37]" />
                    {new Date(post.publishedAt).toLocaleDateString('pt-BR')}
                  </span>
                  <span className="flex items-center gap-2">
                    <Clock size={18} className="text-[#D4AF37]" />
                    {post.readTime} de leitura
                  </span>
                </div>
             </motion.div>
          </div>
        </div>

        <div className="container mx-auto px-4 py-12 grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Main Content */}
          <article className="lg:col-span-8">
            {/* Breadcrumb */}
            <nav className="text-sm text-gray-500 mb-8 font-poppins hidden md:block">
              <span className="hover:text-[#003366] cursor-pointer" onClick={() => navigate('/')}>Home</span> {' > '}
              <span className="hover:text-[#003366] cursor-pointer" onClick={() => navigate('/blog')}>Blog</span> {' > '}
              <span className="font-medium text-[#003366]">{post.title}</span>
            </nav>

            {/* Content Body */}
            <div 
              className="prose prose-lg max-w-none prose-headings:font-montserrat prose-headings:text-[#003366] prose-headings:font-bold prose-p:text-gray-700 prose-p:font-poppins prose-p:leading-relaxed prose-a:text-[#D4AF37] hover:prose-a:text-[#b5922f] prose-img:rounded-xl"
              dangerouslySetInnerHTML={{ __html: post.content }}
            />

            {/* Share Section */}
            <div className="mt-12 pt-8 border-t border-gray-100">
              <h3 className="text-lg font-bold text-[#003366] mb-4 flex items-center gap-2">
                <Share2 size={20} /> Compartilhe este artigo:
              </h3>
              <div className="flex gap-4">
                <button onClick={() => handleShare('whatsapp')} className="p-3 bg-green-500 text-white rounded-full hover:bg-green-600 transition-colors shadow-md hover:-translate-y-1 transform">
                  <MessageCircle size={20} />
                </button>
                <button onClick={() => handleShare('facebook')} className="p-3 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors shadow-md hover:-translate-y-1 transform">
                  <Facebook size={20} />
                </button>
                <button onClick={() => handleShare('twitter')} className="p-3 bg-sky-500 text-white rounded-full hover:bg-sky-600 transition-colors shadow-md hover:-translate-y-1 transform">
                  <Twitter size={20} />
                </button>
                <button onClick={() => handleShare('linkedin')} className="p-3 bg-blue-800 text-white rounded-full hover:bg-blue-900 transition-colors shadow-md hover:-translate-y-1 transform">
                  <Linkedin size={20} />
                </button>
              </div>
            </div>

            {/* Post Navigation */}
            <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-4">
              {prevPost ? (
                <div 
                  onClick={() => handleNavigation(prevPost.slug)}
                  className="p-6 border border-gray-100 rounded-xl hover:border-[#D4AF37] hover:bg-gray-50 cursor-pointer transition-all group"
                >
                  <span className="text-xs text-gray-500 uppercase font-bold mb-2 block">Anterior</span>
                  <h4 className="font-bold text-[#003366] group-hover:text-[#D4AF37] transition-colors">{prevPost.title}</h4>
                </div>
              ) : <div />}
              
              {nextPost && (
                <div 
                  onClick={() => handleNavigation(nextPost.slug)}
                  className="p-6 border border-gray-100 rounded-xl hover:border-[#D4AF37] hover:bg-gray-50 cursor-pointer transition-all group text-right"
                >
                  <span className="text-xs text-gray-500 uppercase font-bold mb-2 block">Próximo</span>
                  <h4 className="font-bold text-[#003366] group-hover:text-[#D4AF37] transition-colors">{nextPost.title}</h4>
                </div>
              )}
            </div>
          </article>

          {/* Sidebar */}
          <aside className="lg:col-span-4 space-y-8">
            {/* Recommended Products */}
            <div className="bg-gray-50 p-6 rounded-2xl sticky top-24">
              <h3 className="text-xl font-montserrat font-bold text-[#003366] mb-6 pb-2 border-b border-gray-200">
                Produtos Recomendados
              </h3>
              <div className="space-y-6">
                {recommendedProducts.map(product => (
                  <div key={product.id} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
                     <img src={product.image} alt={product.name} className="w-full h-32 object-cover rounded-lg mb-3" />
                     <h4 className="font-bold text-sm text-[#003366] mb-2 line-clamp-2">{product.name}</h4>
                     <div className="flex justify-between items-center mb-3">
                        <span className="font-bold text-[#D4AF37]">R$ {product.discountPrice.toFixed(2)}</span>
                        {product.discount > 0 && (
                          <span className="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-bold">-{product.discount}%</span>
                        )}
                     </div>
                     <button 
                       onClick={() => navigate(`/produto/${product.id}`)}
                       className="w-full bg-[#003366] text-white text-xs font-bold py-2 rounded-lg hover:bg-[#004d99] transition-colors"
                     >
                       Ver Produto
                     </button>
                  </div>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </div>
    </>
  );
};

export default BlogPost;
