
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { Watch, ShoppingBag, Palette, Gift, Book, Smartphone, Baby, Zap, ChevronRight, Home } from 'lucide-react';

const Departamentos = () => {
  const departments = [
    { name: 'Loja Relógios', description: 'Modelos clássicos, esportivos e smartwatches das melhores marcas.', icon: Watch, link: '/categorias?category=Relógios', bg: 'bg-amber-50', text: 'text-amber-700', border: 'border-amber-100' },
    { name: 'Eletrônicos', description: 'Tecnologia de ponta para facilitar seu dia a dia e entretenimento.', icon: Smartphone, link: '/categorias?category=Eletrônicos', bg: 'bg-indigo-50', text: 'text-indigo-700', border: 'border-indigo-100' },
    { name: 'Cosméticos', description: 'Beleza e cuidados pessoais com produtos selecionados.', icon: Palette, link: '/categorias?category=Cosméticos', bg: 'bg-pink-50', text: 'text-pink-700', border: 'border-pink-100' },
    { name: 'Moda Kids', description: 'Estilo, conforto e diversão para os pequenos.', icon: Baby, link: '/categorias?category=Kids', bg: 'bg-cyan-50', text: 'text-cyan-700', border: 'border-cyan-100' },
    { name: 'eBooks', description: 'Conhecimento e desenvolvimento pessoal ao seu alcance.', icon: Book, link: '/categorias?category=eBooks', bg: 'bg-emerald-50', text: 'text-emerald-700', border: 'border-emerald-100' },
    { name: 'Só Novidades', description: 'Os lançamentos mais quentes do mercado em primeira mão.', icon: Zap, link: '/categorias?category=Novidades', bg: 'bg-yellow-50', text: 'text-yellow-700', border: 'border-yellow-100' },
    { name: 'Loja Galen', description: 'Artigos exclusivos de moda e acessórios premium.', icon: ShoppingBag, link: '/categorias', bg: 'bg-blue-50', text: 'text-blue-700', border: 'border-blue-100' },
    { name: 'Conceito', description: 'Design e inovação em produtos para casa e decoração.', icon: Palette, link: '/categorias', bg: 'bg-purple-50', text: 'text-purple-700', border: 'border-purple-100' },
    { name: 'Loja Falco', description: 'Presentes especiais para momentos inesquecíveis.', icon: Gift, link: '/categorias', bg: 'bg-rose-50', text: 'text-rose-700', border: 'border-rose-100' },
  ];

  return (
    <>
      <Helmet>
        <title>Stargrowth | Departamentos</title>
        <meta name="description" content="Explore todos os departamentos da nossa loja online. Eletrônicos, Moda, Beleza e muito mais." />
      </Helmet>

      <div className="bg-gray-50 min-h-screen py-8">
        <div className="container mx-auto px-4">
          
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-8">
            <Link to="/" className="hover:text-[#003366] flex items-center gap-1"><Home size={14} /> Home</Link>
            <ChevronRight size={14} />
            <span className="text-[#003366] font-bold">Departamentos</span>
          </div>

          <h1 className="text-3xl md:text-4xl font-montserrat font-bold text-[#003366] mb-4 text-center">Nossos Departamentos</h1>
          <p className="text-gray-600 text-center max-w-2xl mx-auto mb-12">Navegue por nossas lojas especializadas e encontre exatamente o que você procura com a qualidade Stargrowth.</p>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {departments.map((dept, index) => (
              <Link 
                key={index}
                to={dept.link}
                className={`flex flex-col p-6 rounded-xl border ${dept.border} bg-white shadow-sm hover:shadow-xl transition-all duration-300 group hover:-translate-y-1`}
              >
                <div className="flex items-center gap-4 mb-4">
                  <div className={`p-3 rounded-full ${dept.bg} ${dept.text}`}>
                    <dept.icon size={28} />
                  </div>
                  <h2 className="font-bold text-xl text-[#003366] group-hover:text-[#D4AF37] transition-colors">{dept.name}</h2>
                </div>
                <p className="text-gray-500 text-sm leading-relaxed mb-6 flex-grow">{dept.description}</p>
                <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-50">
                  <span className="text-sm font-bold text-[#003366] group-hover:underline">Explorar Produtos</span>
                  <div className="w-8 h-8 rounded-full bg-[#003366] text-white flex items-center justify-center group-hover:bg-[#D4AF37] transition-colors">
                    <ChevronRight size={16} />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default Departamentos;
