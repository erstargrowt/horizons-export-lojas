
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Search, Package, Truck, CheckCircle, Clock } from 'lucide-react';
import Breadcrumb from '@/components/Breadcrumb';

const OrderTracking = () => {
  const [orderId, setOrderId] = useState('');
  const [status, setStatus] = useState(null);

  const handleTrack = (e) => {
    e.preventDefault();
    if(orderId) {
       setStatus('enviado'); // Simulating state
    }
  };

  const steps = [
     { id: 'confirmado', label: 'Confirmado', icon: CheckCircle, date: '10/01 14:00' },
     { id: 'preparando', label: 'Preparando', icon: Package, date: '10/01 16:30' },
     { id: 'enviado', label: 'Em Trânsito', icon: Truck, date: '11/01 09:00' },
     { id: 'entregue', label: 'Entregue', icon: CheckCircle, date: '---' },
  ];

  const currentStepIndex = steps.findIndex(s => s.id === status);

  return (
    <>
      <Helmet><title>Rastreamento | Stargrowth</title></Helmet>
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4 max-w-2xl">
           <Breadcrumb items={[{ label: 'Rastreamento', path: '/rastreamento' }]} />
           
           <h1 className="text-3xl font-bold text-[#003366] mb-8 text-center">Onde está meu pedido?</h1>
           
           <div className="bg-white p-8 rounded-2xl shadow-lg mb-8">
              <form onSubmit={handleTrack} className="flex gap-4">
                 <input 
                   type="text" 
                   value={orderId} 
                   onChange={e => setOrderId(e.target.value)}
                   placeholder="Digite o número do pedido (ex: #PED123)"
                   className="flex-1 border border-gray-300 rounded-lg px-4 py-3 focus:ring-[#003366] focus:border-[#003366] outline-none"
                 />
                 <button type="submit" className="bg-[#003366] text-white px-6 py-3 rounded-lg font-bold">Rastrear</button>
              </form>
           </div>

           {status && (
              <div className="bg-white p-8 rounded-2xl shadow-lg">
                 <h2 className="text-xl font-bold text-[#003366] mb-6">Status: {status.toUpperCase()}</h2>
                 <div className="space-y-8 relative">
                    <div className="absolute left-6 top-2 bottom-2 w-0.5 bg-gray-200"></div>
                    {steps.map((step, index) => {
                       const Icon = step.icon;
                       const isActive = index <= currentStepIndex;
                       return (
                          <div key={step.id} className="relative flex items-center gap-6">
                             <div className={`w-12 h-12 rounded-full flex items-center justify-center z-10 border-4 border-white ${isActive ? 'bg-[#D4AF37] text-white shadow-lg' : 'bg-gray-200 text-gray-400'}`}>
                                <Icon size={20} />
                             </div>
                             <div>
                                <h4 className={`font-bold ${isActive ? 'text-[#003366]' : 'text-gray-400'}`}>{step.label}</h4>
                                <p className="text-xs text-gray-500">{isActive ? step.date : ''}</p>
                             </div>
                          </div>
                       );
                    })}
                 </div>
              </div>
           )}
        </div>
      </div>
    </>
  );
};

export default OrderTracking;
