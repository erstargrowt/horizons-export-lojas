
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCustomerAuth } from '@/context/CustomerAuthContext';
import { Helmet } from 'react-helmet';
import { useToast } from '@/components/ui/use-toast';

const CustomerLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { login, recoverPassword } = useCustomerAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    const result = login(email, password);
    if (result.success) {
      toast({ title: 'Bem-vindo de volta!', className: "bg-green-50 text-green-800 border-green-200" });
      navigate('/minha-conta');
    } else {
      toast({ title: 'Erro de Login', description: result.message, variant: 'destructive' });
    }
  };

  const handleForgotPassword = () => {
    if (!email) {
      toast({ title: 'Email necessário', description: 'Por favor, digite seu email primeiro.', variant: 'destructive' });
      return;
    }
    const result = recoverPassword(email);
    if (result.success) {
      toast({ title: 'Verifique seu email', description: result.message, className: "bg-blue-50 text-blue-800 border-blue-200" });
    } else {
      toast({ title: 'Erro', description: result.message, variant: 'destructive' });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <Helmet><title>Login | Stargrowth</title></Helmet>
      <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md border border-gray-100">
        <h1 className="text-2xl font-bold text-[#003366] mb-6 text-center font-montserrat">Acesse sua Conta</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input 
              type="email" 
              value={email} 
              onChange={e => setEmail(e.target.value)} 
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003366] focus:border-transparent outline-none transition-all"
              required 
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Senha</label>
            <input 
              type="password" 
              value={password} 
              onChange={e => setPassword(e.target.value)} 
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#003366] focus:border-transparent outline-none transition-all"
              required 
            />
            <button type="button" onClick={handleForgotPassword} className="text-xs text-gray-500 hover:text-[#D4AF37] mt-1 float-right">
              Esqueceu sua senha?
            </button>
          </div>
          <button type="submit" className="w-full bg-[#003366] text-white font-bold py-3 rounded-lg hover:bg-[#004d99] hover:shadow-lg transition-all mt-6">
            Entrar
          </button>
        </form>
        <div className="mt-6 text-center text-sm text-gray-600">
          Não tem uma conta? <Link to="/cadastro" className="text-[#D4AF37] font-bold hover:underline">Cadastre-se</Link>
        </div>
      </div>
    </div>
  );
};

export default CustomerLogin;
