
import React from 'react';
import { useInstagram } from '@/context/InstagramContext';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Heart, MessageCircle, Instagram } from 'lucide-react';

const InstagramFeed = () => {
  const { instagramState } = useInstagram();

  return (
    <>
      <Helmet>
        <title>Galeria Instagram | Stargrowth</title>
      </Helmet>
      
      <div className="bg-gray-50 min-h-screen py-12">
        <div className="container mx-auto px-4">
           <div className="text-center mb-12">
              <h1 className="text-4xl font-montserrat font-bold text-[#003366] mb-4">Nossa Galeria</h1>
              <p className="text-gray-600">Acompanhe nosso dia a dia e novidades exclusivas.</p>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {instagramState.posts.map((post, index) => (
                 <motion.div
                    key={post.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.05 }}
                    className="bg-white rounded-2xl shadow-lg overflow-hidden group hover:shadow-2xl transition-all duration-300"
                 >
                    <div className="relative aspect-square overflow-hidden">
                       <img src={post.image} alt="Post" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                       <div className="absolute top-4 right-4 bg-white/90 backdrop-blur rounded-full p-2 text-pink-600 shadow-sm">
                          <Instagram size={20} />
                       </div>
                    </div>
                    
                    <div className="p-6">
                       <p className="text-gray-600 text-sm mb-4 line-clamp-3">{post.caption}</p>
                       
                       <div className="flex justify-between items-center text-gray-500 text-sm border-t border-gray-100 pt-4">
                          <div className="flex gap-4">
                             <span className="flex items-center gap-1 group-hover:text-red-500 transition-colors">
                                <Heart size={18} /> {post.likes}
                             </span>
                             <span className="flex items-center gap-1 group-hover:text-blue-500 transition-colors">
                                <MessageCircle size={18} /> {post.comments}
                             </span>
                          </div>
                          <span className="text-xs">{new Date(post.date).toLocaleDateString()}</span>
                       </div>
                    </div>
                 </motion.div>
              ))}
           </div>
        </div>
      </div>
    </>
  );
};

export default InstagramFeed;
