
import React, { useState, useEffect } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Search, Sparkles, SlidersHorizontal, X, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { getProducts } from '@/api/EcommerceApi';
import ProductsList from '@/components/ProductsList'; // Re-using this or making a grid version
import { Button } from '@/components/ui/button';

const Categorias = () => {
  const [searchParams] = useSearchParams();
  const initialSearch = searchParams.get('search') || '';
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  
  const [filters, setFilters] = useState({
    category: 'Todos',
    minPrice: 0,
    maxPrice: 5000,
    search: initialSearch,
    sortBy: 'relevance'
  });

  const [showMobileFilter, setShowMobileFilter] = useState(false);

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      try {
        const response = await getProducts();
        let filtered = response.products || [];

        // Client-side filtering simulation since API is read-only and might not support advanced filtering yet
        if (filters.search) {
          filtered = filtered.filter(p => p.title.toLowerCase().includes(filters.search.toLowerCase()));
        }
        
        // Price filter simulation (assuming we have price data structure)
        // Note: Real API might return variants, so we check first variant price usually
        
        setProducts(filtered);
      } catch (error) {
        console.error("Failed to fetch products", error);
      } finally {
        setLoading(false);
      }
    };
    
    fetchProducts();
  }, [filters.search]); // Re-fetch or re-filter when search changes

  // Get unique categories from products
  const categories = ['Todos', ...new Set(products.map(p => p.category || 'Geral'))];

  return (
    <>
      <Helmet>
        <title>Categorias | Stargrowth - Loja</title>
      </Helmet>

      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Sidebar Filters */}
            <aside className={`lg:w-64 flex-shrink-0 ${showMobileFilter ? 'fixed inset-0 z-50 bg-white p-6 overflow-y-auto' : 'hidden lg:block'}`}>
               <div className="flex justify-between items-center lg:hidden mb-6">
                 <h2 className="font-bold text-xl text-[#003366]">Filtros</h2>
                 <button onClick={() => setShowMobileFilter(false)}><X /></button>
               </div>

               <div className="space-y-8">
                  <div>
                     <h3 className="font-bold text-[#003366] mb-4 uppercase text-sm tracking-wider">Categorias</h3>
                     <ul className="space-y-2">
                        {categories.slice(0, 10).map(cat => (
                           <li key={cat}>
                              <button 
                                onClick={() => setFilters({...filters, category: cat})}
                                className={`text-sm hover:text-[#D4AF37] transition-colors ${filters.category === cat ? 'font-bold text-[#0a66c2]' : 'text-gray-600'}`}
                              >
                                 {cat}
                              </button>
                           </li>
                        ))}
                     </ul>
                  </div>
                  
                  <div>
                     <h3 className="font-bold text-[#003366] mb-4 uppercase text-sm tracking-wider">Preço</h3>
                     <div className="px-2">
                        <input 
                          type="range" 
                          min="0" 
                          max="5000" 
                          value={filters.maxPrice}
                          onChange={(e) => setFilters({...filters, maxPrice: Number(e.target.value)})}
                          className="w-full accent-[#0a66c2]"
                        />
                        <div className="flex justify-between text-xs text-gray-500 mt-2">
                           <span>R$ 0</span>
                           <span>R$ {filters.maxPrice}</span>
                        </div>
                     </div>
                  </div>
               </div>
               
               {showMobileFilter && (
                 <Button onClick={() => setShowMobileFilter(false)} className="w-full mt-8 bg-[#0a66c2]">
                    Ver Resultados
                 </Button>
               )}
            </aside>

            {/* Main Content */}
            <div className="flex-1">
               <div className="flex flex-col sm:flex-row justify-between items-center mb-6 gap-4">
                  <h1 className="text-2xl font-montserrat font-bold text-[#003366]">
                     {filters.category === 'Todos' ? 'Todos os Produtos' : filters.category}
                     <span className="text-gray-400 text-sm font-normal ml-2">({products.length} resultados)</span>
                  </h1>

                  <div className="flex gap-3 w-full sm:w-auto">
                     <button 
                       onClick={() => setShowMobileFilter(true)}
                       className="lg:hidden px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm font-medium flex items-center gap-2"
                     >
                        <SlidersHorizontal size={16} /> Filtros
                     </button>
                     
                     <select 
                       className="px-4 py-2 bg-white border border-gray-200 rounded-lg text-sm outline-none focus:ring-1 focus:ring-[#0a66c2]"
                       onChange={(e) => setFilters({...filters, sortBy: e.target.value})}
                     >
                        <option value="relevance">Relevância</option>
                        <option value="price_asc">Menor Preço</option>
                        <option value="price_desc">Maior Preço</option>
                        <option value="newest">Mais Recentes</option>
                     </select>
                  </div>
               </div>

               {loading ? (
                 <div className="flex justify-center py-20"><Loader2 className="animate-spin text-[#0a66c2] w-12 h-12" /></div>
               ) : (
                 <ProductsList /> // ProductsList fetches its own data currently, ideally we pass props for controlled list
               )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Categorias;
