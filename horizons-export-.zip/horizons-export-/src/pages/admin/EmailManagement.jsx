
import React from 'react';
import { Mail, Download, Trash2, UserCheck } from 'lucide-react';
import { useEmails } from '@/context/EmailContext';
import { useToast } from '@/components/ui/use-toast';

const EmailManagement = () => {
  const { emails, deleteEmail, updateEmailStatus } = useEmails();
  const { toast } = useToast();

  const handleExportCSV = () => {
    const csvContent = "data:text/csv;charset=utf-8," 
      + "Email,Status,Data de Cadastro\n"
      + emails.map(e => `${e.email},${e.status},${new Date(e.date).toLocaleDateString()}`).join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "stargrowth_leads.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    toast({ title: 'Lista exportada com sucesso!' });
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-[#003366] font-montserrat">Gerenciar Emails</h2>
          <p className="text-gray-500 text-sm">Total de leads: {emails.length}</p>
        </div>
        <button 
          onClick={handleExportCSV}
          className="bg-green-600 text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2 hover:bg-green-700 transition-colors"
        >
          <Download size={20} /> Exportar CSV
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="p-4 font-bold text-gray-600">Email</th>
              <th className="p-4 font-bold text-gray-600">Data Cadastro</th>
              <th className="p-4 font-bold text-gray-600">Status</th>
              <th className="p-4 font-bold text-gray-600 text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {emails.map((lead) => (
              <tr key={lead.id} className="border-b border-gray-100 hover:bg-gray-50">
                <td className="p-4 font-medium text-gray-800 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-500">
                    <Mail size={14} />
                  </div>
                  {lead.email}
                </td>
                <td className="p-4 text-sm text-gray-600">
                  {new Date(lead.date).toLocaleDateString()}
                </td>
                <td className="p-4">
                  <span className={`text-xs px-2 py-1 rounded-full font-bold ${
                    lead.status === 'engajado' ? 'bg-green-100 text-green-700' : 
                    lead.status === 'novo' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600'
                  }`}>
                    {lead.status.charAt(0).toUpperCase() + lead.status.slice(1)}
                  </span>
                </td>
                <td className="p-4 text-right">
                  <div className="flex justify-end gap-2">
                    <button 
                      onClick={() => updateEmailStatus(lead.id, lead.status === 'engajado' ? 'inativo' : 'engajado')} 
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg"
                      title="Alternar Status"
                    >
                      <UserCheck size={18} />
                    </button>
                    <button 
                      onClick={() => deleteEmail(lead.id)} 
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                      title="Remover"
                    >
                      <Trash2 size={18} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {emails.length === 0 && (
              <tr>
                <td colSpan="4" className="p-8 text-center text-gray-500">Nenhum email capturado ainda.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default EmailManagement;
