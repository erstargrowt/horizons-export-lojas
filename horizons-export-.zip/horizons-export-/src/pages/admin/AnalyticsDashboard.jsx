
import React from 'react';
import { useAnalytics } from '@/context/AnalyticsContext';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as ReTooltip, ResponsiveContainer, AreaChart, Area 
} from 'recharts';
import { Download, FileText } from 'lucide-react';
import jsPDF from 'jspdf';
import { useToast } from '@/components/ui/use-toast';

const AnalyticsDashboard = () => {
  const { getDailyVisits } = useAnalytics();
  const { toast } = useToast();
  const data = getDailyVisits(30);

  const generatePDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(20);
    doc.text("Relatório Analytics - Stargrowth", 20, 20);
    doc.setFontSize(12);
    doc.text(`Data: ${new Date().toLocaleDateString()}`, 20, 30);
    doc.text("Resumo de 30 dias de atividade.", 20, 40);
    doc.save("relatorio_stargrowth.pdf");
    toast({ title: 'PDF gerado com sucesso!' });
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-[#003366] font-montserrat">Analytics Detalhado</h2>
        <div className="flex gap-2">
           <button 
             onClick={generatePDF}
             className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg font-bold flex items-center gap-2 hover:bg-gray-200"
           >
             <FileText size={18} /> PDF
           </button>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Visitors Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
           <h3 className="text-lg font-bold text-[#003366] mb-6">Visitantes (30 dias)</h3>
           <div className="h-64">
             <ResponsiveContainer width="100%" height="100%">
               <AreaChart data={data}>
                 <defs>
                   <linearGradient id="colorVisits" x1="0" y1="0" x2="0" y2="1">
                     <stop offset="5%" stopColor="#D4AF37" stopOpacity={0.8}/>
                     <stop offset="95%" stopColor="#D4AF37" stopOpacity={0}/>
                   </linearGradient>
                 </defs>
                 <CartesianGrid strokeDasharray="3 3" vertical={false} />
                 <XAxis dataKey="date" fontSize={10} tickLine={false} axisLine={false} />
                 <YAxis fontSize={10} tickLine={false} axisLine={false} />
                 <ReTooltip />
                 <Area type="monotone" dataKey="visitors" stroke="#D4AF37" fillOpacity={1} fill="url(#colorVisits)" />
               </AreaChart>
             </ResponsiveContainer>
           </div>
        </div>

        {/* Funnel Chart Mockup */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
           <h3 className="text-lg font-bold text-[#003366] mb-6">Funil de Conversão</h3>
           <div className="space-y-4">
              {[
                { label: 'Visitantes', val: '100%', color: 'bg-blue-100 text-blue-800', width: '100%' },
                { label: 'Visualizaram Produto', val: '65%', color: 'bg-purple-100 text-purple-800', width: '65%' },
                { label: 'Adicionaram ao Carrinho', val: '25%', color: 'bg-yellow-100 text-yellow-800', width: '25%' },
                { label: 'Iniciaram Checkout', val: '10%', color: 'bg-orange-100 text-orange-800', width: '10%' },
                { label: 'Compra Finalizada', val: '2.4%', color: 'bg-green-100 text-green-800', width: '5%' }, // adjusted width for visibility
              ].map((step, i) => (
                <div key={i} className="relative">
                   <div className="flex justify-between text-xs font-bold mb-1">
                      <span>{step.label}</span>
                      <span>{step.val}</span>
                   </div>
                   <div className="h-8 bg-gray-50 rounded-lg overflow-hidden">
                      <div 
                        className={`h-full rounded-lg ${step.color} flex items-center px-3 text-xs font-bold transition-all duration-1000 ease-out`}
                        style={{ width: step.width }}
                      >
                      </div>
                   </div>
                </div>
              ))}
           </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsDashboard;
