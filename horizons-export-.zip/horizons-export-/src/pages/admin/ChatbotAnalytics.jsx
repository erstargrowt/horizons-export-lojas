
import React from 'react';
import { useChatbot } from '@/context/ChatbotContext';
import { motion } from 'framer-motion';
import { BarChart3, PieChart, Users, Clock, ThumbsUp } from 'lucide-react';
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

const ChatbotAnalytics = () => {
  const { getAnalytics } = useChatbot();
  const stats = getAnalytics();

  // Mock data for charts since we don't have deep historical data structure in this demo
  const mockChartData = [
     { name: 'Seg', resolved: 12, manual: 4 },
     { name: 'Ter', resolved: 19, manual: 3 },
     { name: 'Qua', resolved: 15, manual: 5 },
     { name: 'Qui', resolved: 22, manual: 2 },
     { name: 'Sex', resolved: 25, manual: 6 },
     { name: 'Sáb', resolved: 10, manual: 1 },
     { name: 'Dom', resolved: 8, manual: 0 },
  ];

  return (
    <div className="max-w-6xl mx-auto">
       <div className="flex items-center gap-3 mb-8">
        <div className="p-3 bg-gradient-to-br from-[#003366] to-[#004d99] rounded-xl text-white shadow-lg">
          <PieChart size={32} />
        </div>
        <div>
          <h1 className="text-3xl font-montserrat font-bold text-[#003366]">Analytics IA</h1>
          <p className="text-gray-600">Métricas de performance do seu assistente virtual.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
         <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.1 }} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <div className="flex items-center gap-4 mb-2">
               <div className="p-2 bg-blue-100 text-blue-600 rounded-lg"><Users size={24} /></div>
               <span className="text-gray-500 font-medium">Total de Conversas</span>
            </div>
            <h3 className="text-4xl font-bold text-[#003366]">{stats.totalConversations}</h3>
            <p className="text-xs text-green-500 font-bold mt-2">+12% vs semana anterior</p>
         </motion.div>

         <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.2 }} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <div className="flex items-center gap-4 mb-2">
               <div className="p-2 bg-green-100 text-green-600 rounded-lg"><BarChart3 size={24} /></div>
               <span className="text-gray-500 font-medium">Taxa de Resolução</span>
            </div>
            <h3 className="text-4xl font-bold text-[#003366]">{stats.resolutionRate}%</h3>
            <p className="text-xs text-green-500 font-bold mt-2">IA resolvendo maioria dos casos</p>
         </motion.div>

         <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.3 }} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <div className="flex items-center gap-4 mb-2">
               <div className="p-2 bg-yellow-100 text-yellow-600 rounded-lg"><ThumbsUp size={24} /></div>
               <span className="text-gray-500 font-medium">Satisfação</span>
            </div>
            <h3 className="text-4xl font-bold text-[#003366]">{stats.satisfactionRate}%</h3>
            <p className="text-xs text-gray-400 font-bold mt-2">Baseado em feedback de usuários</p>
         </motion.div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
         <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h3 className="font-bold text-lg text-[#003366] mb-6">Volume de Atendimentos</h3>
            <div className="h-[300px]">
               <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={mockChartData}>
                     <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee" />
                     <XAxis dataKey="name" axisLine={false} tickLine={false} />
                     <YAxis axisLine={false} tickLine={false} />
                     <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
                     <Bar dataKey="resolved" name="Resolvido por IA" fill="#003366" radius={[4, 4, 0, 0]} />
                     <Bar dataKey="manual" name="Transferido p/ Humano" fill="#D4AF37" radius={[4, 4, 0, 0]} />
                  </BarChart>
               </ResponsiveContainer>
            </div>
         </div>

         <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h3 className="font-bold text-lg text-[#003366] mb-6">Tópicos Mais Frequentes</h3>
            <div className="space-y-4">
               {[
                  { topic: 'Prazo de Entrega', count: 45, pct: 80 },
                  { topic: 'Formas de Pagamento', count: 32, pct: 65 },
                  { topic: 'Trocas e Devoluções', count: 28, pct: 50 },
                  { topic: 'Rastreamento', count: 15, pct: 30 },
               ].map((item, i) => (
                  <div key={i}>
                     <div className="flex justify-between text-sm font-bold text-gray-700 mb-1">
                        <span>{item.topic}</span>
                        <span>{item.count}</span>
                     </div>
                     <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                        <motion.div 
                           initial={{ width: 0 }} 
                           animate={{ width: `${item.pct}%` }} 
                           transition={{ duration: 1, delay: i * 0.1 }}
                           className="h-full bg-[#003366] rounded-full" 
                        />
                     </div>
                  </div>
               ))}
            </div>
         </div>
      </div>
    </div>
  );
};

export default ChatbotAnalytics;
