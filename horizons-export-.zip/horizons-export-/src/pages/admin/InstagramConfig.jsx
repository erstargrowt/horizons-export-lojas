
import React, { useState } from 'react';
import { useInstagram } from '@/context/InstagramContext';
import TextInput from '@/components/edit/TextInput';
import TextArea from '@/components/edit/TextArea';
import { Save, RefreshCw, Instagram } from 'lucide-react';

const InstagramConfig = () => {
  const { instagramState, saveConfig, updateDisplay, refreshFeed } = useInstagram();
  const [localConfig, setLocalConfig] = useState(instagramState.config);
  const [localDisplay, setLocalDisplay] = useState(instagramState.display);

  const handleSave = () => {
    saveConfig(localConfig);
    updateDisplay(localDisplay);
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-[#003366] mb-6 font-montserrat">Configuração do Instagram</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
           <h3 className="font-bold text-lg mb-4 text-[#003366] flex items-center gap-2">
              <Instagram /> Conexão API
           </h3>
           <TextInput 
              label="Business Account ID" 
              value={localConfig.businessId} 
              onChange={v => setLocalConfig({...localConfig, businessId: v})} 
           />
           <TextInput 
              label="Access Token" 
              type="password"
              value={localConfig.accessToken} 
              onChange={v => setLocalConfig({...localConfig, accessToken: v})} 
           />
           <button className="w-full mt-2 border border-gray-300 text-gray-700 py-2 rounded-lg font-bold hover:bg-gray-50">
              Testar Conexão
           </button>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
           <h3 className="font-bold text-lg mb-4 text-[#003366]">Exibição</h3>
           
           <div className="flex items-center justify-between mb-4">
            <span className="font-medium">Mostrar Feed na Home</span>
            <label className="relative inline-flex items-center cursor-pointer">
              <input 
                type="checkbox" 
                checked={localDisplay.showOnHome} 
                onChange={e => setLocalDisplay({...localDisplay, showOnHome: e.target.checked})} 
                className="sr-only peer" 
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#003366]"></div>
            </label>
          </div>

          <TextInput 
              label="Quantidade de Posts" 
              type="number"
              value={localDisplay.count} 
              onChange={v => setLocalDisplay({...localDisplay, count: Number(v)})} 
           />
           
           <TextArea 
              label="Texto do Widget"
              value={localDisplay.sectionText}
              onChange={v => setLocalDisplay({...localDisplay, sectionText: v})}
              rows={2}
           />
        </div>
      </div>

      <div className="mt-8 flex justify-between items-center bg-gray-50 p-6 rounded-xl border border-gray-200">
         <div>
            <p className="font-bold text-gray-700">Status do Feed</p>
            <p className="text-sm text-gray-500">Última atualização: {new Date(instagramState.lastUpdated).toLocaleString()}</p>
            <p className="text-sm text-gray-500">Posts em cache: {instagramState.posts.length}</p>
         </div>
         <div className="flex gap-4">
            <button onClick={refreshFeed} className="flex items-center gap-2 text-[#003366] font-bold hover:bg-white px-4 py-2 rounded-lg transition-colors">
               <RefreshCw size={18} /> Atualizar Agora
            </button>
            <button onClick={handleSave} className="bg-[#003366] text-white px-6 py-2 rounded-lg font-bold flex items-center gap-2 hover:bg-[#004d99]">
               <Save size={18} /> Salvar Configurações
            </button>
         </div>
      </div>
    </div>
  );
};

export default InstagramConfig;
