
import React, { useState } from 'react';
import { useChat } from '@/context/ChatContext';
import TextInput from '@/components/edit/TextInput';
import TextArea from '@/components/edit/TextArea';
import { Save, Plus, Trash2, Edit } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const ChatConfig = () => {
  const { chatState, updateConfig, addAgent, removeAgent } = useChat();
  const [localConfig, setLocalConfig] = useState(chatState.config);
  const [newAgent, setNewAgent] = useState({ name: '', email: '' });
  
  const handleSave = () => {
    updateConfig(localConfig);
  };

  const handleAddAgent = () => {
    if (newAgent.name && newAgent.email) {
      addAgent(newAgent);
      setNewAgent({ name: '', email: '' });
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold text-[#003366] mb-6 font-montserrat">Configuração de Chat</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="font-bold text-lg mb-4 text-[#003366]">Geral</h3>
          <div className="flex items-center justify-between mb-4">
            <span className="font-medium">Chat Ativo</span>
            <label className="relative inline-flex items-center cursor-pointer">
              <input 
                type="checkbox" 
                checked={localConfig.active} 
                onChange={e => setLocalConfig({...localConfig, active: e.target.checked})} 
                className="sr-only peer" 
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#003366]"></div>
            </label>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
             <TextInput 
               label="Horário Início" 
               type="time" 
               value={localConfig.startTime} 
               onChange={v => setLocalConfig({...localConfig, startTime: v})} 
             />
             <TextInput 
               label="Horário Fim" 
               type="time" 
               value={localConfig.endTime} 
               onChange={v => setLocalConfig({...localConfig, endTime: v})} 
             />
          </div>
          
          <TextInput 
             label="Tempo de Resposta (min)" 
             value={localConfig.responseTime} 
             onChange={v => setLocalConfig({...localConfig, responseTime: v})} 
          />
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="font-bold text-lg mb-4 text-[#003366]">Mensagens Automáticas</h3>
          <TextArea 
             label="Boas-vindas" 
             value={localConfig.welcomeMessage} 
             onChange={v => setLocalConfig({...localConfig, welcomeMessage: v})} 
             rows={2}
          />
          <TextArea 
             label="Mensagem Offline" 
             value={localConfig.offlineMessage} 
             onChange={v => setLocalConfig({...localConfig, offlineMessage: v})} 
             rows={2}
          />
          <button onClick={handleSave} className="w-full mt-2 bg-[#003366] text-white py-2 rounded-lg font-bold">
            Salvar Configurações
          </button>
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 mb-8">
         <h3 className="font-bold text-lg mb-4 text-[#003366]">Agentes de Suporte</h3>
         
         <div className="flex gap-4 mb-6 items-end">
            <div className="flex-1">
               <TextInput label="Nome" value={newAgent.name} onChange={v => setNewAgent({...newAgent, name: v})} placeholder="Nome do Agente" className="mb-0" />
            </div>
            <div className="flex-1">
               <TextInput label="Email" value={newAgent.email} onChange={v => setNewAgent({...newAgent, email: v})} placeholder="email@stargrowth.com" className="mb-0" />
            </div>
            <button onClick={handleAddAgent} className="bg-[#D4AF37] text-[#003366] px-4 py-2 rounded-lg font-bold flex items-center gap-2 h-[42px]">
               <Plus size={18} /> Adicionar
            </button>
         </div>

         <table className="w-full text-left">
            <thead className="bg-gray-50 border-b">
               <tr>
                  <th className="p-3 font-bold text-gray-600">Nome</th>
                  <th className="p-3 font-bold text-gray-600">Email</th>
                  <th className="p-3 font-bold text-gray-600">Status</th>
                  <th className="p-3 font-bold text-gray-600 text-right">Ação</th>
               </tr>
            </thead>
            <tbody>
               {chatState.agents.map(agent => (
                  <tr key={agent.id} className="border-b">
                     <td className="p-3">{agent.name}</td>
                     <td className="p-3 text-gray-500">{agent.email}</td>
                     <td className="p-3">
                        <span className={`text-xs px-2 py-1 rounded-full ${agent.status === 'online' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>
                           {agent.status}
                        </span>
                     </td>
                     <td className="p-3 text-right">
                        <button onClick={() => removeAgent(agent.id)} className="text-red-500 hover:bg-red-50 p-2 rounded">
                           <Trash2 size={16} />
                        </button>
                     </td>
                  </tr>
               ))}
            </tbody>
         </table>
      </div>
    </div>
  );
};

export default ChatConfig;
