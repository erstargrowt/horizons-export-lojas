
import React from 'react';
import { motion } from 'framer-motion';
import { Users, ShoppingBag, DollarSign, TrendingUp, ArrowUpRight } from 'lucide-react';
import { useAnalytics } from '@/context/AnalyticsContext';
import { useEmails } from '@/context/EmailContext';

const AdminDashboard = () => {
  const { events } = useAnalytics();
  const { emails } = useEmails();

  const totalRevenue = 14500.00; // Mock value
  const totalOrders = 85; // Mock value
  const conversionRate = 2.4; // Mock value

  const stats = [
    { label: 'Receita Total', value: `R$ ${totalRevenue.toLocaleString()}`, icon: DollarSign, color: 'text-green-600', bg: 'bg-green-100' },
    { label: 'Total de Pedidos', value: totalOrders, icon: ShoppingBag, color: 'text-blue-600', bg: 'bg-blue-100' },
    { label: 'Leads Capturados', value: emails.length, icon: Users, color: 'text-purple-600', bg: 'bg-purple-100' },
    { label: 'Taxa de Conversão', value: `${conversionRate}%`, icon: TrendingUp, color: 'text-[#D4AF37]', bg: 'bg-yellow-100' },
  ];

  return (
    <div>
      <h2 className="text-2xl font-bold text-[#003366] mb-6 font-montserrat">Dashboard Geral</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white p-6 rounded-xl shadow-sm border border-gray-100"
          >
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-full ${stat.bg}`}>
                <stat.icon className={`w-6 h-6 ${stat.color}`} />
              </div>
              <span className="flex items-center text-green-500 text-xs font-bold bg-green-50 px-2 py-1 rounded-full">
                +12% <ArrowUpRight size={12} />
              </span>
            </div>
            <h3 className="text-gray-500 text-sm font-medium">{stat.label}</h3>
            <p className="text-2xl font-bold text-gray-800 mt-1">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold text-[#003366] mb-4">Atividade Recente</h3>
          <div className="space-y-4">
             {events.slice(-5).reverse().map((event, i) => (
               <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                 <div>
                    <p className="text-sm font-bold text-gray-700 capitalize">{event.type.replace('_', ' ')}</p>
                    <p className="text-xs text-gray-500">{new Date(event.timestamp).toLocaleString()}</p>
                 </div>
                 <span className="text-xs font-mono text-gray-400">{event.id.toString().substring(0,8)}</span>
               </div>
             ))}
             {events.length === 0 && <p className="text-gray-500">Nenhuma atividade recente.</p>}
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
          <h3 className="text-lg font-bold text-[#003366] mb-4">Últimos Leads</h3>
          <div className="space-y-4">
             {emails.slice(-5).reverse().map((lead, i) => (
               <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                 <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-[#003366] text-white flex items-center justify-center font-bold text-xs">
                       {lead.email.charAt(0).toUpperCase()}
                    </div>
                    <div>
                       <p className="text-sm font-bold text-gray-700">{lead.email}</p>
                       <p className="text-xs text-gray-500">{new Date(lead.date).toLocaleDateString()}</p>
                    </div>
                 </div>
                 <span className={`text-xs px-2 py-1 rounded-full font-bold ${lead.status === 'engajado' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'}`}>
                    {lead.status}
                 </span>
               </div>
             ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
