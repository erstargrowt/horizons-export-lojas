
import React, { useState } from 'react';
import { Megaphone, Plus, Send, MoreVertical, Trash2 } from 'lucide-react';
import { useEmails } from '@/context/EmailContext';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';

const CampaignManagement = () => {
  const { campaigns, createCampaign, deleteCampaign } = useEmails();
  const { toast } = useToast();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    subject: '',
    body: '',
    segment: 'todos'
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    createCampaign(formData);
    setFormData({ name: '', subject: '', body: '', segment: 'todos' });
    setIsModalOpen(false);
    toast({ title: 'Campanha criada e agendada!', className: 'bg-green-50 text-green-800' });
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-[#003366] font-montserrat">Campanhas de Email</h2>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-[#D4AF37] text-[#003366] px-4 py-2 rounded-lg font-bold flex items-center gap-2 hover:bg-[#c4a030] transition-colors"
        >
          <Plus size={20} /> Nova Campanha
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {campaigns.map((campaign) => (
          <div key={campaign.id} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 flex flex-col h-full">
            <div className="flex justify-between items-start mb-4">
               <div className="bg-blue-50 p-3 rounded-lg text-blue-600">
                  <Megaphone size={24} />
               </div>
               <button onClick={() => deleteCampaign(campaign.id)} className="text-gray-400 hover:text-red-500">
                  <Trash2 size={18} />
               </button>
            </div>
            
            <h3 className="font-bold text-[#003366] text-lg mb-1">{campaign.name}</h3>
            <p className="text-sm text-gray-500 mb-4 truncate">Assunto: {campaign.subject}</p>
            
            <div className="grid grid-cols-3 gap-2 py-4 border-t border-b border-gray-100 mb-4">
               <div className="text-center">
                  <p className="text-xs text-gray-400">Envios</p>
                  <p className="font-bold text-gray-800">{campaign.sent}</p>
               </div>
               <div className="text-center border-l border-gray-100">
                  <p className="text-xs text-gray-400">Abertura</p>
                  <p className="font-bold text-gray-800">{campaign.openRate}%</p>
               </div>
               <div className="text-center border-l border-gray-100">
                  <p className="text-xs text-gray-400">Cliques</p>
                  <p className="font-bold text-gray-800">{campaign.clickRate}%</p>
               </div>
            </div>

            <div className="mt-auto flex justify-between items-center">
               <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full font-bold uppercase">
                  {campaign.status}
               </span>
               <button className="text-sm font-bold text-[#003366] hover:underline">
                  Ver Relatório
               </button>
            </div>
          </div>
        ))}

        {/* Create Card */}
        <button 
          onClick={() => setIsModalOpen(true)}
          className="border-2 border-dashed border-gray-200 rounded-xl p-6 flex flex-col items-center justify-center text-gray-400 hover:border-[#D4AF37] hover:text-[#D4AF37] transition-all min-h-[200px]"
        >
           <Plus size={40} className="mb-2" />
           <span className="font-bold">Criar Nova Campanha</span>
        </button>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div 
             initial={{ opacity: 0, scale: 0.95 }}
             animate={{ opacity: 1, scale: 1 }}
             className="bg-white rounded-2xl w-full max-w-2xl p-6 shadow-2xl overflow-y-auto max-h-[90vh]"
          >
            <h3 className="text-xl font-bold text-[#003366] mb-6">Criar Nova Campanha</h3>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Nome da Campanha</label>
                <input 
                  type="text" 
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  placeholder="Ex: Promoção de Verão"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Assunto do Email</label>
                <input 
                  type="text" 
                  value={formData.subject}
                  onChange={(e) => setFormData({...formData, subject: e.target.value})}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  placeholder="Ex: Você não pode perder isso..."
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Segmento</label>
                <select 
                  value={formData.segment}
                  onChange={(e) => setFormData({...formData, segment: e.target.value})}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                >
                   <option value="todos">Todos os Contatos</option>
                   <option value="novos">Novos Inscritos</option>
                   <option value="engajados">Engajados</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Conteúdo do Email</label>
                <textarea 
                  value={formData.body}
                  onChange={(e) => setFormData({...formData, body: e.target.value})}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 h-40"
                  placeholder="Escreva sua mensagem aqui..."
                  required
                ></textarea>
              </div>

              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => setIsModalOpen(false)} className="flex-1 py-3 border border-gray-300 rounded-lg font-bold">
                  Cancelar
                </button>
                <button type="submit" className="flex-1 py-3 bg-[#003366] text-white rounded-lg font-bold flex items-center justify-center gap-2">
                   <Send size={18} /> Agendar Envio
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default CampaignManagement;
