
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Trash2, Edit, RefreshCw, X, Check } from 'lucide-react';
import { useCoupons } from '@/context/CouponContext';
import { useToast } from '@/components/ui/use-toast';

const CouponManagement = () => {
  const { coupons, addCoupon, deleteCoupon, updateCoupon } = useCoupons();
  const { toast } = useToast();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState(null);
  
  // Form State
  const [formData, setFormData] = useState({
    code: '',
    type: 'percentage',
    value: '',
    expiration: '',
    maxUses: '',
    description: ''
  });

  const handleOpenModal = (coupon = null) => {
    if (coupon) {
      setEditingCoupon(coupon);
      setFormData(coupon);
    } else {
      setEditingCoupon(null);
      setFormData({ code: '', type: 'percentage', value: '', expiration: '', maxUses: '', description: '' });
    }
    setIsModalOpen(true);
  };

  const generateCode = () => {
    const prefixes = ['PROMO', 'DESCONTO', 'OFERTA', 'VIP'];
    const randomPrefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const randomNum = Math.floor(10 + Math.random() * 90);
    setFormData({ ...formData, code: `${randomPrefix}${randomNum}` });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const couponData = {
      ...formData,
      value: Number(formData.value),
      maxUses: Number(formData.maxUses)
    };

    if (editingCoupon) {
      updateCoupon(editingCoupon.id, couponData);
      toast({ title: 'Cupom atualizado', className: 'bg-green-50 text-green-800' });
    } else {
      addCoupon(couponData);
      toast({ title: 'Cupom criado com sucesso', className: 'bg-green-50 text-green-800' });
    }
    setIsModalOpen(false);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-[#003366] font-montserrat">Gerenciar Cupons</h2>
        <button 
          onClick={() => handleOpenModal()}
          className="bg-[#D4AF37] text-[#003366] px-4 py-2 rounded-lg font-bold flex items-center gap-2 hover:bg-[#c4a030] transition-colors"
        >
          <Plus size={20} /> Novo Cupom
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="p-4 font-bold text-gray-600">Código</th>
              <th className="p-4 font-bold text-gray-600">Desconto</th>
              <th className="p-4 font-bold text-gray-600">Expiração</th>
              <th className="p-4 font-bold text-gray-600">Usos</th>
              <th className="p-4 font-bold text-gray-600">Status</th>
              <th className="p-4 font-bold text-gray-600 text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {coupons.map((coupon) => (
              <tr key={coupon.id} className="border-b border-gray-100 hover:bg-gray-50">
                <td className="p-4 font-mono font-bold text-[#003366]">{coupon.code}</td>
                <td className="p-4">
                  {coupon.type === 'percentage' ? `${coupon.value}%` : `R$ ${coupon.value}`}
                </td>
                <td className="p-4 text-sm text-gray-600">
                  {new Date(coupon.expiration).toLocaleDateString()}
                </td>
                <td className="p-4 text-sm text-gray-600">
                  {coupon.used} / {coupon.maxUses}
                </td>
                <td className="p-4">
                  <span className={`text-xs px-2 py-1 rounded-full font-bold ${coupon.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                    {coupon.status === 'active' ? 'Ativo' : 'Inativo'}
                  </span>
                </td>
                <td className="p-4 text-right">
                  <div className="flex justify-end gap-2">
                    <button onClick={() => handleOpenModal(coupon)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg">
                      <Edit size={18} />
                    </button>
                    <button onClick={() => deleteCoupon(coupon.id)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg">
                      <Trash2 size={18} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
            {coupons.length === 0 && (
              <tr>
                <td colSpan="6" className="p-8 text-center text-gray-500">Nenhum cupom encontrado.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-2xl w-full max-w-lg p-6 shadow-2xl"
          >
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-[#003366]">
                {editingCoupon ? 'Editar Cupom' : 'Criar Novo Cupom'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                <X size={24} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="flex gap-4">
                <div className="flex-1">
                  <label className="block text-sm font-bold text-gray-700 mb-1">Código</label>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      value={formData.code}
                      onChange={(e) => setFormData({...formData, code: e.target.value.toUpperCase()})}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 uppercase"
                      required
                    />
                    <button type="button" onClick={generateCode} className="bg-gray-100 p-2 rounded-lg hover:bg-gray-200">
                      <RefreshCw size={20} className="text-gray-600" />
                    </button>
                  </div>
                </div>
                <div className="w-1/3">
                  <label className="block text-sm font-bold text-gray-700 mb-1">Tipo</label>
                  <select 
                    value={formData.type}
                    onChange={(e) => setFormData({...formData, type: e.target.value})}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  >
                    <option value="percentage">Percentual (%)</option>
                    <option value="fixed">Fixo (R$)</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-1">
                  <label className="block text-sm font-bold text-gray-700 mb-1">Valor do Desconto</label>
                  <input 
                    type="number" 
                    value={formData.value}
                    onChange={(e) => setFormData({...formData, value: e.target.value})}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    required
                  />
                </div>
                <div className="flex-1">
                  <label className="block text-sm font-bold text-gray-700 mb-1">Expiração</label>
                  <input 
                    type="date" 
                    value={formData.expiration}
                    onChange={(e) => setFormData({...formData, expiration: e.target.value})}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Limite de Usos</label>
                <input 
                  type="number" 
                  value={formData.maxUses}
                  onChange={(e) => setFormData({...formData, maxUses: e.target.value})}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-700 mb-1">Descrição (Interna)</label>
                <textarea 
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  rows="3"
                ></textarea>
              </div>

              <div className="pt-4 flex gap-4">
                <button 
                  type="button" 
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-3 border border-gray-300 rounded-lg font-bold text-gray-600 hover:bg-gray-50"
                >
                  Cancelar
                </button>
                <button 
                  type="submit"
                  className="flex-1 py-3 bg-[#003366] text-white rounded-lg font-bold hover:bg-[#004d99] flex items-center justify-center gap-2"
                >
                  <Check size={20} /> Salvar Cupom
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default CouponManagement;
