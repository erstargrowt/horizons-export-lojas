
import React, { useState } from 'react';
import { useChatbot } from '@/context/ChatbotContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, MessageCircle, CheckCircle, X, User, Bot } from 'lucide-react';

const ChatbotHistory = () => {
  const { history } = useChatbot();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedConversation, setSelectedConversation] = useState(null);

  const filteredHistory = history.filter(h => 
    h.clientName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-6xl mx-auto">
       <div className="flex items-center gap-3 mb-8">
        <div className="p-3 bg-gradient-to-br from-[#003366] to-[#004d99] rounded-xl text-white shadow-lg">
          <MessageCircle size={32} />
        </div>
        <div>
          <h1 className="text-3xl font-montserrat font-bold text-[#003366]">Histórico de Conversas</h1>
          <p className="text-gray-600">Monitore as interações dos clientes com a Inteligência Artificial.</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 mb-8">
         <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
            <input 
               type="text" 
               placeholder="Buscar por cliente..." 
               value={searchTerm}
               onChange={e => setSearchTerm(e.target.value)}
               className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#003366]"
            />
         </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
         <table className="w-full text-left">
            <thead className="bg-gray-50 border-b">
               <tr>
                  <th className="p-4 font-bold text-gray-600">Cliente</th>
                  <th className="p-4 font-bold text-gray-600">Início</th>
                  <th className="p-4 font-bold text-gray-600">Status</th>
                  <th className="p-4 font-bold text-gray-600">Mensagens</th>
                  <th className="p-4 font-bold text-gray-600 text-right">Ação</th>
               </tr>
            </thead>
            <tbody>
               {filteredHistory.map(conv => (
                  <tr key={conv.id} className="border-b hover:bg-gray-50">
                     <td className="p-4 font-bold text-[#003366]">{conv.clientName}</td>
                     <td className="p-4 text-sm text-gray-500">{new Date(conv.startTime).toLocaleString()}</td>
                     <td className="p-4">
                        <span className={`px-2 py-1 rounded-full text-xs font-bold ${conv.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>
                           {conv.status === 'active' ? 'Ativo' : 'Finalizado'}
                        </span>
                     </td>
                     <td className="p-4 text-sm">{conv.messages.length} msgs</td>
                     <td className="p-4 text-right">
                        <button 
                           onClick={() => setSelectedConversation(conv)}
                           className="text-[#003366] font-bold text-sm hover:underline"
                        >
                           Ver Detalhes
                        </button>
                     </td>
                  </tr>
               ))}
               {filteredHistory.length === 0 && (
                  <tr>
                     <td colSpan="5" className="p-8 text-center text-gray-500">Nenhuma conversa encontrada.</td>
                  </tr>
               )}
            </tbody>
         </table>
      </div>

      <AnimatePresence>
         {selectedConversation && (
            <motion.div 
               initial={{ opacity: 0 }} 
               animate={{ opacity: 1 }} 
               exit={{ opacity: 0 }}
               className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4"
               onClick={() => setSelectedConversation(null)}
            >
               <motion.div 
                  initial={{ scale: 0.9, y: 20 }} 
                  animate={{ scale: 1, y: 0 }} 
                  exit={{ scale: 0.9, y: 20 }}
                  className="bg-white w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden max-h-[80vh] flex flex-col"
                  onClick={e => e.stopPropagation()}
               >
                  <div className="p-4 border-b flex justify-between items-center bg-[#003366] text-white">
                     <div>
                        <h3 className="font-bold">{selectedConversation.clientName}</h3>
                        <p className="text-xs opacity-80">{new Date(selectedConversation.startTime).toLocaleString()}</p>
                     </div>
                     <button onClick={() => setSelectedConversation(null)} className="hover:bg-white/20 p-1 rounded-full"><X /></button>
                  </div>
                  
                  <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50">
                     {selectedConversation.messages.map((msg, idx) => (
                        <div key={idx} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                           <div className={`flex gap-3 max-w-[80%] ${msg.sender === 'user' ? 'flex-row-reverse' : ''}`}>
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${msg.sender === 'user' ? 'bg-gray-200' : 'bg-[#D4AF37]'}`}>
                                 {msg.sender === 'user' ? <User size={16} /> : <Bot size={16} className="text-[#003366]" />}
                              </div>
                              <div className={`p-3 rounded-xl shadow-sm text-sm ${msg.sender === 'user' ? 'bg-[#003366] text-white rounded-tr-none' : 'bg-white text-gray-800 rounded-tl-none'}`}>
                                 {msg.text}
                              </div>
                           </div>
                        </div>
                     ))}
                  </div>

                  <div className="p-4 border-t bg-white flex justify-end gap-2">
                     <button className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-bold hover:bg-gray-50">Marcar como Pendente</button>
                     <button className="px-4 py-2 bg-green-500 text-white rounded-lg text-sm font-bold hover:bg-green-600 flex items-center gap-2">
                        <CheckCircle size={16} /> Resolver Conversa
                     </button>
                  </div>
               </motion.div>
            </motion.div>
         )}
      </AnimatePresence>
    </div>
  );
};

export default ChatbotHistory;
