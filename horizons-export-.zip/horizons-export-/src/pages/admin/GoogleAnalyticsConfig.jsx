
import React, { useState } from 'react';
import { useGoogleAnalytics } from '@/context/GoogleAnalyticsContext';
import TextInput from '@/components/edit/TextInput';
import { motion } from 'framer-motion';
import { Save, BarChart3, Activity, CheckCircle, AlertCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const GoogleAnalyticsConfig = () => {
  const { config, saveConfig, testConnection } = useGoogleAnalytics();
  const { toast } = useToast();
  const [localConfig, setLocalConfig] = useState(config);
  const [isTesting, setIsTesting] = useState(false);

  const handleSave = () => {
    saveConfig(localConfig);
  };

  const handleTest = async () => {
    setIsTesting(true);
    try {
      await testConnection();
      toast({ 
        title: "Conexão Validada", 
        description: "O ID de rastreamento parece válido e pronto para uso.",
        className: "bg-green-50 text-green-800 border-green-200"
      });
    } catch (error) {
      toast({ 
        title: "Erro na Conexão", 
        description: "Verifique se o Tracking ID está no formato correto (G-XXXXXXXXXX).",
        variant: "destructive"
      });
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-4xl mx-auto"
    >
      <div className="flex items-center gap-3 mb-8">
        <div className="p-3 bg-gradient-to-br from-[#003366] to-[#004d99] rounded-xl text-white shadow-lg">
          <BarChart3 size={32} />
        </div>
        <div>
          <h1 className="text-3xl font-montserrat font-bold text-[#003366]">Google Analytics 4</h1>
          <p className="text-gray-600">Configure o rastreamento avançado da sua loja.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h3 className="font-bold text-xl text-[#003366] mb-6 flex items-center gap-2">
              <Activity className="text-[#D4AF37]" /> Configuração Principal
            </h3>
            
            <div className="mb-6 flex items-center justify-between p-4 bg-gray-50 rounded-xl">
              <span className="font-medium text-gray-700">Ativar Rastreamento</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={localConfig.enabled} 
                  onChange={e => setLocalConfig({...localConfig, enabled: e.target.checked})} 
                  className="sr-only peer" 
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#003366]"></div>
              </label>
            </div>

            <TextInput 
              label="Tracking ID (G-XXXXXXXXXX)" 
              value={localConfig.trackingId} 
              onChange={v => setLocalConfig({...localConfig, trackingId: v})}
              placeholder="Ex: G-A1B2C3D4E5"
            />
            
            <TextInput 
              label="Property ID (Opcional)" 
              value={localConfig.propertyId} 
              onChange={v => setLocalConfig({...localConfig, propertyId: v})}
              placeholder="Ex: 123456789"
            />

            <button 
              onClick={handleTest}
              disabled={isTesting}
              className="w-full mt-4 py-3 border-2 border-[#003366] text-[#003366] rounded-xl font-bold hover:bg-[#003366] hover:text-white transition-all flex items-center justify-center gap-2"
            >
              {isTesting ? 'Verificando...' : 'Testar Conexão'}
            </button>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h3 className="font-bold text-xl text-[#003366] mb-6">Opções de Rastreamento</h3>
            
            <div className="space-y-4">
              <label className="flex items-center gap-3 p-4 border border-gray-100 rounded-xl cursor-pointer hover:border-[#D4AF37] transition-colors">
                <input 
                  type="checkbox" 
                  checked={localConfig.customEvents} 
                  onChange={e => setLocalConfig({...localConfig, customEvents: e.target.checked})}
                  className="w-5 h-5 text-[#003366] rounded focus:ring-[#D4AF37]"
                />
                <div>
                  <span className="font-bold text-gray-800 block">Eventos Customizados</span>
                  <span className="text-sm text-gray-500">Cliques, visualizações, interações</span>
                </div>
              </label>

              <label className="flex items-center gap-3 p-4 border border-gray-100 rounded-xl cursor-pointer hover:border-[#D4AF37] transition-colors">
                <input 
                  type="checkbox" 
                  checked={localConfig.conversions} 
                  onChange={e => setLocalConfig({...localConfig, conversions: e.target.checked})}
                  className="w-5 h-5 text-[#003366] rounded focus:ring-[#D4AF37]"
                />
                <div>
                  <span className="font-bold text-gray-800 block">E-commerce / Conversões</span>
                  <span className="text-sm text-gray-500">Vendas, checkout, valor de receita</span>
                </div>
              </label>

              <label className="flex items-center gap-3 p-4 border border-gray-100 rounded-xl cursor-pointer hover:border-[#D4AF37] transition-colors">
                <input 
                  type="checkbox" 
                  checked={localConfig.userBehavior} 
                  onChange={e => setLocalConfig({...localConfig, userBehavior: e.target.checked})}
                  className="w-5 h-5 text-[#003366] rounded focus:ring-[#D4AF37]"
                />
                <div>
                  <span className="font-bold text-gray-800 block">Comportamento de Usuário</span>
                  <span className="text-sm text-gray-500">Tempo na página, scroll, cliques em links</span>
                </div>
              </label>
            </div>
          </div>

          <div className="bg-[#003366] p-6 rounded-2xl text-white shadow-lg">
            <h4 className="font-bold mb-2 flex items-center gap-2"><CheckCircle size={20} className="text-[#D4AF37]" /> Status do Serviço</h4>
            <p className="text-sm opacity-90 mb-4">
              O rastreamento está {localConfig.enabled ? 'ATIVO' : 'INATIVO'}. {localConfig.enabled ? 'Os dados estão sendo enviados para o Google Analytics.' : 'Nenhum dado está sendo coletado.'}
            </p>
            <button 
              onClick={handleSave}
              className="w-full bg-[#D4AF37] text-[#003366] font-bold py-3 rounded-xl hover:bg-white transition-colors flex items-center justify-center gap-2"
            >
              <Save size={20} /> Salvar Configurações
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default GoogleAnalyticsConfig;
