
import React, { useState } from 'react';
import { useChatbot } from '@/context/ChatbotContext';
import TextInput from '@/components/edit/TextInput';
import TextArea from '@/components/edit/TextArea';
import { motion } from 'framer-motion';
import { Save, Bot, MessageSquare, Trash2, Plus, Zap } from 'lucide-react';

const ChatbotConfig = () => {
  const { config, saveConfig, addFaq, deleteFaq } = useChatbot();
  const [localConfig, setLocalConfig] = useState(config);
  const [newFaq, setNewFaq] = useState({ question: '', answer: '' });

  const handleSave = () => {
    saveConfig(localConfig);
  };

  const handleAddFaq = () => {
    if (newFaq.question && newFaq.answer) {
      addFaq(newFaq.question, newFaq.answer);
      setNewFaq({ question: '', answer: '' });
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="max-w-6xl mx-auto"
    >
      <div className="flex items-center gap-3 mb-8">
        <div className="p-3 bg-gradient-to-br from-[#003366] to-[#004d99] rounded-xl text-white shadow-lg">
          <Bot size={32} />
        </div>
        <div>
          <h1 className="text-3xl font-montserrat font-bold text-[#003366]">Configuração do Chatbot IA</h1>
          <p className="text-gray-600">Personalize o comportamento e conhecimento do seu assistente virtual.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Settings */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h3 className="font-bold text-xl text-[#003366] mb-6 flex items-center gap-2">
              <Zap className="text-[#D4AF37]" /> Parâmetros da IA
            </h3>

            <div className="mb-6 flex items-center justify-between p-4 bg-gray-50 rounded-xl">
              <span className="font-medium text-gray-700">Chatbot Ativo</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input 
                  type="checkbox" 
                  checked={localConfig.enabled} 
                  onChange={e => setLocalConfig({...localConfig, enabled: e.target.checked})} 
                  className="sr-only peer" 
                />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#003366]"></div>
              </label>
            </div>

            <TextInput 
              label="OpenAI API Key" 
              type="password"
              value={localConfig.apiKey} 
              onChange={v => setLocalConfig({...localConfig, apiKey: v})}
              placeholder="sk-..."
            />

            <div className="mb-4">
               <label className="block text-sm font-bold text-gray-700 mb-1">Modelo</label>
               <select 
                  value={localConfig.model}
                  onChange={e => setLocalConfig({...localConfig, model: e.target.value})}
                  className="w-full border border-gray-300 rounded-lg p-3 bg-white"
               >
                  <option value="gpt-3.5-turbo">GPT-3.5 Turbo (Rápido)</option>
                  <option value="gpt-4">GPT-4 (Mais Inteligente)</option>
               </select>
            </div>

            <div className="mb-6">
               <label className="block text-sm font-bold text-gray-700 mb-2 flex justify-between">
                 Criatividade (Temperatura) <span>{localConfig.temperature}</span>
               </label>
               <input 
                  type="range"
                  min="0"
                  max="1"
                  step="0.1"
                  value={localConfig.temperature}
                  onChange={(e) => setLocalConfig({...localConfig, temperature: parseFloat(e.target.value)})}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-[#003366]"
               />
            </div>

            <div className="mb-6">
               <label className="block text-sm font-bold text-gray-700 mb-2 flex justify-between">
                 Tamanho da Resposta (Tokens) <span>{localConfig.maxTokens}</span>
               </label>
               <input 
                  type="range"
                  min="0"
                  max="500"
                  step="10"
                  value={localConfig.maxTokens}
                  onChange={(e) => setLocalConfig({...localConfig, maxTokens: parseInt(e.target.value)})}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-[#003366]"
               />
            </div>

            <TextArea 
               label="Contexto do Sistema" 
               value={localConfig.systemContext} 
               onChange={v => setLocalConfig({...localConfig, systemContext: v})}
               rows={4}
               placeholder="Instruções de como o bot deve se comportar..."
            />

            <button 
              onClick={handleSave}
              className="w-full mt-4 bg-[#003366] text-white font-bold py-3 rounded-xl hover:bg-[#004d99] transition-colors flex items-center justify-center gap-2"
            >
              <Save size={20} /> Salvar Configurações
            </button>
          </div>
        </div>

        {/* Knowledge Base */}
        <div className="lg:col-span-2 space-y-6">
           <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
              <h3 className="font-bold text-xl text-[#003366] mb-6 flex items-center gap-2">
                 <MessageSquare className="text-[#D4AF37]" /> Base de Conhecimento (FAQs)
              </h3>

              <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 mb-6">
                 <h4 className="font-bold text-sm text-gray-600 mb-3 uppercase">Adicionar Nova Pergunta</h4>
                 <div className="grid grid-cols-1 gap-4">
                    <TextInput 
                       value={newFaq.question} 
                       onChange={v => setNewFaq({...newFaq, question: v})} 
                       placeholder="Ex: Qual o horário de atendimento?"
                    />
                    <TextArea 
                       value={newFaq.answer} 
                       onChange={v => setNewFaq({...newFaq, answer: v})} 
                       placeholder="Ex: Funcionamos de Seg a Sex, das 9h às 18h."
                       rows={2}
                    />
                    <button 
                       onClick={handleAddFaq}
                       className="bg-[#D4AF37] text-[#003366] font-bold py-2 rounded-lg hover:bg-[#bfa030] transition-colors flex items-center justify-center gap-2"
                    >
                       <Plus size={18} /> Adicionar à Base
                    </button>
                 </div>
              </div>

              <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
                 {config.faqs.map(faq => (
                    <div key={faq.id} className="p-4 border border-gray-100 rounded-xl hover:shadow-md transition-shadow bg-white group">
                       <div className="flex justify-between items-start mb-2">
                          <h5 className="font-bold text-[#003366]">{faq.question}</h5>
                          <button 
                             onClick={() => deleteFaq(faq.id)} 
                             className="text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                             <Trash2 size={18} />
                          </button>
                       </div>
                       <p className="text-gray-600 text-sm">{faq.answer}</p>
                    </div>
                 ))}
                 {config.faqs.length === 0 && (
                    <p className="text-center text-gray-500 py-8">Nenhuma FAQ cadastrada.</p>
                 )}
              </div>
           </div>
        </div>
      </div>
    </motion.div>
  );
};

export default ChatbotConfig;
