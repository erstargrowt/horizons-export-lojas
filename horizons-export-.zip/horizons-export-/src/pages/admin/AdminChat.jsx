
import React, { useState } from 'react';
import { useChat } from '@/context/ChatContext';
import { Search, Send, CheckCircle, XCircle, User, Clock, MoreVertical, MessageSquare } from 'lucide-react';

const AdminChat = () => {
  const { chatState, addMessage } = useChat();
  const [selectedChat, setSelectedChat] = useState(null);
  const [messageInput, setMessageInput] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredConversations = chatState.conversations.filter(c => 
    c.clientName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (messageInput.trim() && selectedChat) {
      addMessage(selectedChat.id, messageInput, 'agent');
      setMessageInput('');
    }
  };

  const getActiveChat = () => chatState.conversations.find(c => c.id === selectedChat?.id);

  return (
    <div className="flex h-[calc(100vh-140px)] bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
      {/* Sidebar */}
      <div className="w-80 border-r border-gray-200 flex flex-col bg-gray-50">
        <div className="p-4 border-b border-gray-200">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            <input
              type="text"
              placeholder="Buscar cliente..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#003366]"
            />
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto">
           {filteredConversations.map(chat => (
             <div 
               key={chat.id} 
               onClick={() => setSelectedChat(chat)}
               className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-white transition-colors ${selectedChat?.id === chat.id ? 'bg-white border-l-4 border-l-[#003366]' : ''}`}
             >
                <div className="flex justify-between mb-1">
                   <h4 className="font-bold text-gray-800">{chat.clientName}</h4>
                   <span className="text-xs text-gray-500">{new Date(chat.lastMessageAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                </div>
                <p className="text-sm text-gray-500 truncate">{chat.messages[chat.messages.length - 1]?.text || 'Nova conversa'}</p>
                <div className="mt-2 flex gap-2">
                   {chat.status === 'aguardando' && <span className="text-[10px] bg-red-100 text-red-700 px-2 py-0.5 rounded-full font-bold">Aguardando</span>}
                   {chat.status === 'aberta' && <span className="text-[10px] bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-bold">Aberta</span>}
                </div>
             </div>
           ))}
        </div>
      </div>

      {/* Main Chat Area */}
      {selectedChat ? (
        <div className="flex-1 flex flex-col">
           {/* Header */}
           <div className="h-16 border-b border-gray-200 flex items-center justify-between px-6 bg-white">
              <div className="flex items-center gap-3">
                 <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center text-gray-600">
                    <User size={20} />
                 </div>
                 <div>
                    <h3 className="font-bold text-gray-800">{getActiveChat()?.clientName}</h3>
                    <p className="text-xs text-gray-500">{getActiveChat()?.clientEmail}</p>
                 </div>
              </div>
              <div className="flex items-center gap-3">
                 <button className="text-gray-400 hover:text-[#003366]"><Clock size={20} /></button>
                 <button className="text-gray-400 hover:text-[#003366]"><MoreVertical size={20} /></button>
                 <button className="bg-green-500 text-white px-4 py-1.5 rounded-lg text-sm font-bold">Resolver</button>
              </div>
           </div>

           {/* Messages */}
           <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-gray-50">
              {getActiveChat()?.messages.map(msg => (
                 <div key={msg.id} className={`flex ${msg.sender === 'agent' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[70%] p-3 rounded-xl shadow-sm ${msg.sender === 'agent' ? 'bg-[#003366] text-white rounded-tr-none' : 'bg-white text-gray-800 rounded-tl-none'}`}>
                       <p className="text-sm">{msg.text}</p>
                       <p className={`text-[10px] mt-1 text-right ${msg.sender === 'agent' ? 'text-blue-200' : 'text-gray-400'}`}>
                          {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                       </p>
                    </div>
                 </div>
              ))}
           </div>

           {/* Input */}
           <div className="p-4 bg-white border-t border-gray-200">
              <form onSubmit={handleSendMessage} className="flex gap-4">
                 <input 
                    type="text" 
                    value={messageInput}
                    onChange={e => setMessageInput(e.target.value)}
                    placeholder="Digite sua resposta..."
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#003366]"
                 />
                 <button type="submit" className="bg-[#003366] text-white p-2 rounded-lg hover:bg-[#004d99]">
                    <Send size={20} />
                 </button>
              </form>
           </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center text-gray-400">
           <MessageSquare size={48} className="mb-4 opacity-20" />
           <p>Selecione uma conversa para iniciar</p>
        </div>
      )}
    </div>
  );
};

export default AdminChat;
