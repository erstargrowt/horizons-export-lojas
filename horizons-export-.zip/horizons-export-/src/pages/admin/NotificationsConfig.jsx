
import React, { useState } from 'react';
import { useNotifications } from '@/context/NotificationContext';
import TextInput from '@/components/edit/TextInput';
import TextArea from '@/components/edit/TextArea';
import { Save, Send, Trash2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { motion, AnimatePresence } from 'framer-motion';

const NotificationsConfig = () => {
  const { config, saveNotificationConfig, updateTemplate, deleteNotificationLog } = useNotifications();
  const { toast } = useToast();
  
  const [localConfig, setLocalConfig] = useState(config);
  const [activeTab, setActiveTab] = useState('channels');

  const handleSaveSettings = () => {
    saveNotificationConfig(localConfig);
  };

  const handleTestConnection = (channel) => {
    toast({ title: `Testando conexão com ${channel}...` });
    setTimeout(() => {
      toast({ title: "Conexão estabelecida com sucesso!", className: "bg-green-500 text-white" });
    }, 1500);
  };

  const tabs = [
    { id: 'channels', label: 'Canais & Credenciais' },
    { id: 'templates', label: 'Templates de Mensagens' },
    { id: 'logs', label: 'Log de Envios' },
  ];

  return (
    <div>
      <h2 className="text-2xl font-bold text-[#003366] mb-6 font-montserrat">Configuração de Notificações</h2>
      
      {/* Custom Tabs */}
      <div className="flex space-x-1 bg-gray-100 p-1 rounded-xl mb-6 w-fit">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`
              relative px-4 py-2 rounded-lg text-sm font-bold transition-colors
              ${activeTab === tab.id ? 'text-[#003366]' : 'text-gray-500 hover:text-gray-700'}
            `}
          >
            {activeTab === tab.id && (
              <motion.div
                layoutId="activeTab"
                className="absolute inset-0 bg-white shadow-sm rounded-lg"
                transition={{ type: "spring", stiffness: 500, damping: 30 }}
              />
            )}
            <span className="relative z-10">{tab.label}</span>
          </button>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.2 }}
        >
          {activeTab === 'channels' && (
            <div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* WhatsApp Config */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-lg flex items-center gap-2">
                      <span className="text-green-500">WhatsApp API</span>
                    </h3>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={localConfig.channels.whatsapp} 
                        onChange={e => setLocalConfig(prev => ({...prev, channels: {...prev.channels, whatsapp: e.target.checked}}))} 
                        className="sr-only peer" 
                      />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-500"></div>
                    </label>
                  </div>
                  <TextInput 
                    label="WhatsApp Business API Key" 
                    value={localConfig.credentials.whatsappApiKey} 
                    onChange={v => setLocalConfig(prev => ({...prev, credentials: {...prev.credentials, whatsappApiKey: v}}))}
                    type="password"
                  />
                  <TextInput 
                    label="Phone Number ID" 
                    value={localConfig.credentials.whatsappPhoneId} 
                    onChange={v => setLocalConfig(prev => ({...prev, credentials: {...prev.credentials, whatsappPhoneId: v}}))}
                  />
                  <TextInput 
                    label="Número de Envio" 
                    value={localConfig.credentials.whatsappNumber} 
                    onChange={v => setLocalConfig(prev => ({...prev, credentials: {...prev.credentials, whatsappNumber: v}}))}
                  />
                  <button 
                    onClick={() => handleTestConnection('WhatsApp')}
                    className="mt-2 w-full border border-green-500 text-green-600 py-2 rounded-lg hover:bg-green-50 transition-colors font-medium"
                  >
                    Testar Conexão WhatsApp
                  </button>
                </div>

                {/* SMS Config */}
                <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="font-bold text-lg flex items-center gap-2">
                      <span className="text-blue-500">SMS Gateway</span>
                    </h3>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={localConfig.channels.sms} 
                        onChange={e => setLocalConfig(prev => ({...prev, channels: {...prev.channels, sms: e.target.checked}}))} 
                        className="sr-only peer" 
                      />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                    </label>
                  </div>
                  <TextInput 
                    label="Account SID" 
                    value={localConfig.credentials.smsAccountSid} 
                    onChange={v => setLocalConfig(prev => ({...prev, credentials: {...prev.credentials, smsAccountSid: v}}))}
                  />
                  <TextInput 
                    label="Auth Token" 
                    value={localConfig.credentials.smsAuthToken} 
                    onChange={v => setLocalConfig(prev => ({...prev, credentials: {...prev.credentials, smsAuthToken: v}}))}
                    type="password"
                  />
                   <TextInput 
                    label="Número de Envio" 
                    value={localConfig.credentials.smsNumber} 
                    onChange={v => setLocalConfig(prev => ({...prev, credentials: {...prev.credentials, smsNumber: v}}))}
                  />
                  <button 
                    onClick={() => handleTestConnection('SMS')}
                    className="mt-2 w-full border border-blue-500 text-blue-600 py-2 rounded-lg hover:bg-blue-50 transition-colors font-medium"
                  >
                    Testar Conexão SMS
                  </button>
                </div>
              </div>
              
              <div className="mt-6 flex justify-end">
                <button onClick={handleSaveSettings} className="bg-[#003366] text-white px-6 py-3 rounded-lg flex items-center gap-2 font-bold hover:bg-[#004d99]">
                  <Save size={18} /> Salvar Configurações
                </button>
              </div>
            </div>
          )}

          {activeTab === 'templates' && (
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
               <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="md:col-span-1 space-y-2 border-r pr-4">
                     {Object.keys(config.templates).map(key => (
                        <button 
                          key={key}
                          className="w-full text-left p-3 rounded-lg hover:bg-gray-50 focus:bg-blue-50 focus:text-[#003366] font-medium capitalize transition-colors"
                        >
                           {key.replace('_', ' ')}
                        </button>
                     ))}
                  </div>
                  <div className="md:col-span-2">
                     <h3 className="font-bold mb-2 text-[#003366]">Editar Template: Nova Venda</h3>
                     <TextArea 
                        rows={5} 
                        value={config.templates.nova_venda}
                        onChange={(v) => updateTemplate('nova_venda', v)} 
                     />
                     <div className="mt-2 text-sm text-gray-500">
                        Variáveis: <span className="bg-gray-100 px-1 rounded">{'{cliente_nome}'}</span>, <span className="bg-gray-100 px-1 rounded">{'{pedido_id}'}</span>, <span className="bg-gray-100 px-1 rounded">{'{valor}'}</span>
                     </div>
                     
                     <div className="mt-4 p-4 bg-gray-50 rounded-lg border border-gray-200">
                        <h4 className="text-xs font-bold text-gray-400 uppercase mb-2">Preview</h4>
                        <p className="text-gray-800 text-sm">
                           {config.templates.nova_venda
                              .replace('{cliente_nome}', 'Maria Silva')
                              .replace('{pedido_id}', '#12345')
                              .replace('{valor}', '150.00')}
                        </p>
                     </div>
                     
                     <div className="mt-4 flex gap-3">
                        <button className="bg-[#003366] text-white px-4 py-2 rounded-lg font-bold text-sm">Salvar Template</button>
                        <button className="border border-gray-300 text-gray-600 px-4 py-2 rounded-lg font-bold text-sm flex items-center gap-2">
                           <Send size={14} /> Enviar Teste
                        </button>
                     </div>
                  </div>
               </div>
            </div>
          )}

          {activeTab === 'logs' && (
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
               <table className="w-full text-left">
                  <thead className="bg-gray-50 border-b">
                     <tr>
                        <th className="p-4 font-bold text-gray-600">Data</th>
                        <th className="p-4 font-bold text-gray-600">Tipo</th>
                        <th className="p-4 font-bold text-gray-600">Cliente</th>
                        <th className="p-4 font-bold text-gray-600">Ação</th>
                        <th className="p-4 font-bold text-gray-600">Status</th>
                        <th className="p-4 font-bold text-gray-600 text-right">Opções</th>
                     </tr>
                  </thead>
                  <tbody>
                     {config.history.map(log => (
                        <tr key={log.id} className="border-b hover:bg-gray-50">
                           <td className="p-4 text-sm">{new Date(log.date).toLocaleString()}</td>
                           <td className="p-4"><span className="uppercase text-xs font-bold bg-gray-100 px-2 py-1 rounded">{log.type}</span></td>
                           <td className="p-4 font-medium">{log.client}</td>
                           <td className="p-4 text-sm">{log.action}</td>
                           <td className="p-4">
                              <span className={`text-xs font-bold px-2 py-1 rounded-full ${log.status === 'enviado' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                                 {log.status}
                              </span>
                           </td>
                           <td className="p-4 text-right">
                              <button onClick={() => deleteNotificationLog(log.id)} className="text-red-500 hover:bg-red-50 p-2 rounded">
                                 <Trash2 size={16} />
                              </button>
                           </td>
                        </tr>
                     ))}
                  </tbody>
               </table>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

export default NotificationsConfig;
