
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Plus, Minus, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Breadcrumb from '@/components/Breadcrumb';

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const faqs = [
    { q: 'Qual o prazo de entrega?', a: 'O prazo varia de 3 a 10 dias úteis dependendo da sua região.' },
    { q: 'Como faço para rastrear?', a: 'Você receberá um código por email assim que o pedido for despachado.' },
    { q: 'Aceitam devolução?', a: 'Sim, você tem 30 dias para devolução gratuita.' },
    { q: 'Quais as formas de pagamento?', a: 'Cartão de crédito em até 12x, PIX e Boleto.' }
  ];

  const filtered = faqs.filter(f => f.q.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <>
      <Helmet><title>FAQ | Stargrowth</title></Helmet>
      <div className="min-h-screen bg-gray-50 py-12">
         <div className="container mx-auto px-4 max-w-3xl">
            <Breadcrumb items={[{ label: 'FAQ', path: '/faq' }]} />
            <h1 className="text-3xl font-bold text-[#003366] mb-8 text-center">Perguntas Frequentes</h1>
            
            <div className="bg-white p-6 rounded-xl shadow-sm mb-8">
               <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input 
                     type="text" 
                     placeholder="Buscar dúvida..." 
                     className="w-full pl-10 p-3 border rounded-lg outline-none focus:border-[#003366]"
                     onChange={e => setSearchTerm(e.target.value)}
                  />
               </div>
            </div>

            <div className="space-y-4">
               {filtered.map((faq, i) => (
                  <div key={i} className="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100">
                     <button 
                        onClick={() => setOpenIndex(openIndex === i ? null : i)}
                        className="w-full p-6 text-left font-bold flex justify-between items-center hover:bg-gray-50 transition-colors"
                     >
                        {faq.q}
                        {openIndex === i ? <Minus size={20} /> : <Plus size={20} />}
                     </button>
                     <AnimatePresence>
                        {openIndex === i && (
                           <motion.div 
                              initial={{ height: 0 }} 
                              animate={{ height: 'auto' }} 
                              exit={{ height: 0 }}
                              className="overflow-hidden bg-gray-50"
                           >
                              <div className="p-6 pt-0 text-gray-600">{faq.a}</div>
                           </motion.div>
                        )}
                     </AnimatePresence>
                  </div>
               ))}
            </div>
         </div>
      </div>
    </>
  );
};

export default FAQ;
