
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Facebook, Instagram, Linkedin, Twitter, Award, Users, Star, TrendingUp, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';

const QuemSomos = () => {
  const team = [
    {
      name: 'Mara Mendonça',
      role: 'CFO - Diretora Financeira',
      description: 'Especialista em finanças corporativas com foco em crescimento sustentável e gestão de recursos.',
      image: 'https://images.unsplash.com/photo-1573496359-7013cdddb2ca'
    },
    {
      name: 'Vanessa Nogueira',
      role: 'PMDC - Diretora de Marketing',
      description: 'Visionária em estratégias de marketing digital e posicionamento de marca no mercado global.',
      image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956'
    },
    {
      name: 'Thalles Nogueira',
      role: 'CPO - Diretor de Produtos',
      description: 'Apaixonado por inovação e desenvolvimento de produtos que resolvem problemas reais dos clientes.',
      image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7'
    },
    {
      name: 'Brendon Nogueira',
      role: 'DCCDS - Diretor de Sucesso do Cliente',
      description: 'Dedicado a garantir a melhor experiência possível em cada ponto de contato com a Stargrowth.',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e'
    }
  ];

  return (
    <>
      <Helmet>
        <title>Quem Somos - Stargrowth</title>
        <meta name="description" content="Conheça a história da Stargrowth, nossa equipe de liderança e nossos valores fundamentais." />
      </Helmet>

      <div className="min-h-screen bg-white">
        {/* Founder Section */}
        <section className="relative bg-[#003366] text-white py-24 overflow-hidden">
          <div className="absolute top-0 right-0 w-1/2 h-full bg-[#004488]/30 skew-x-12 transform origin-top-right"></div>
          <div className="container mx-auto px-4 relative z-10">
            <div className="flex flex-col md:flex-row items-center gap-12">
              <motion.div 
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
                className="w-full md:w-1/2"
              >
                <div className="relative">
                  <div className="absolute inset-0 bg-[#D4AF37] rounded-2xl transform translate-x-4 translate-y-4"></div>
                  <img 
                    src="https://images.unsplash.com/photo-1493882552576-fce827c6161e" 
                    alt="Natan Ribeiro - Fundador" 
                    className="relative rounded-2xl shadow-2xl w-full h-[500px] object-cover grayscale hover:grayscale-0 transition-all duration-500"
                  />
                </div>
              </motion.div>
              
              <motion.div 
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="w-full md:w-1/2"
              >
                <div className="inline-block bg-[#D4AF37] text-[#003366] font-bold px-4 py-1 rounded-full text-sm mb-6">
                  Fundador & CEO
                </div>
                <h1 className="text-4xl md:text-5xl font-montserrat font-bold mb-6">Natan Ribeiro</h1>
                <p className="text-xl text-gray-300 font-light mb-8 leading-relaxed">
                  "Acredito que o verdadeiro sucesso de um negócio é medido pelo impacto positivo que ele gera na vida das pessoas."
                </p>
                <div className="space-y-4 text-gray-300 font-poppins">
                  <p>
                    Especialista com mais de <strong className="text-white">25 anos em vendas</strong> e <strong className="text-white">10 anos em marketing de relacionamento</strong>.
                  </p>
                  <p>
                    Residente em <strong className="text-white">Vila Velha-ES</strong>, cristão e focado em qualidade de vida, Natan fundou a Stargrowth com o propósito de elevar o padrão do e-commerce brasileiro, unindo produtos de excelência com um atendimento humanizado.
                  </p>
                </div>
                
                <div className="flex gap-4 mt-8">
                  <a href="#" className="bg-white/10 p-3 rounded-full hover:bg-[#D4AF37] hover:text-[#003366] transition-all"><Linkedin size={20} /></a>
                  <a href="#" className="bg-white/10 p-3 rounded-full hover:bg-[#D4AF37] hover:text-[#003366] transition-all"><Instagram size={20} /></a>
                  <a href="#" className="bg-white/10 p-3 rounded-full hover:bg-[#D4AF37] hover:text-[#003366] transition-all"><Twitter size={20} /></a>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Values Section */}
        <section className="py-20 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-montserrat font-bold text-[#003366]">Nossos Valores</h2>
              <p className="text-gray-500 mt-4">Os pilares que sustentam cada decisão que tomamos</p>
            </div>
            
            <div className="grid md:grid-cols-4 gap-8">
              {[
                { icon: Award, title: "Qualidade", desc: "Produtos selecionados com rigorosos critérios de excelência." },
                { icon: Users, title: "Confiança", desc: "Transparência total em todas as relações com clientes e parceiros." },
                { icon: TrendingUp, title: "Inovação", desc: "Busca constante por soluções que facilitem a vida do consumidor." },
                { icon: Heart, title: "Excelência", desc: "Atendimento humanizado que supera expectativas." }
              ].map((val, index) => (
                <motion.div 
                  key={index}
                  whileHover={{ y: -10 }}
                  className="bg-white p-8 rounded-xl shadow-lg border-b-4 border-[#D4AF37] text-center"
                >
                  <div className="w-16 h-16 bg-blue-50 text-[#003366] rounded-full flex items-center justify-center mx-auto mb-6">
                    <val.icon size={32} />
                  </div>
                  <h3 className="font-bold text-xl text-[#003366] mb-3">{val.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{val.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-24 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-montserrat font-bold text-[#003366]">Nossa Diretoria</h2>
              <p className="text-gray-500 mt-4">Mentes brilhantes por trás da Stargrowth</p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {team.map((member, index) => (
                <div key={index} className="group relative">
                  <div className="overflow-hidden rounded-xl h-80 mb-6 bg-gray-100 relative shadow-lg">
                    <img 
                      src={member.image} 
                      alt={member.name} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 grayscale group-hover:grayscale-0"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[#003366] to-transparent opacity-60 group-hover:opacity-40 transition-opacity"></div>
                    <div className="absolute bottom-4 left-4 text-white">
                      <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity transform translate-y-4 group-hover:translate-y-0 duration-300">
                        <a href="#" className="hover:text-[#D4AF37]"><Linkedin size={18} /></a>
                        <a href="#" className="hover:text-[#D4AF37]"><Instagram size={18} /></a>
                      </div>
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-[#003366]">{member.name}</h3>
                  <p className="text-[#D4AF37] font-bold text-sm mb-2 uppercase tracking-wide">{member.role}</p>
                  <p className="text-gray-600 text-sm leading-relaxed">{member.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Timeline Section */}
        <section className="py-20 bg-[#003366] text-white overflow-hidden">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-montserrat font-bold text-center mb-16">Nossa Jornada</h2>
            
            <div className="relative">
              {/* Line */}
              <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-[#D4AF37]/30 hidden md:block"></div>
              
              <div className="space-y-12 md:space-y-24">
                {[
                  { year: '2015', title: 'O Início', desc: 'Natan Ribeiro inicia o projeto com a visão de criar um e-commerce diferenciado.' },
                  { year: '2018', title: 'Expansão Nacional', desc: 'Alcançamos a marca de 10.000 clientes em todo o Brasil.' },
                  { year: '2021', title: 'Nova Sede', desc: 'Inauguração da sede própria em Vila Velha-ES e expansão da equipe.' },
                  { year: '2024', title: 'Stargrowth 2.0', desc: 'Lançamento da nova plataforma com tecnologia de ponta e novas categorias.' }
                ].map((item, index) => (
                  <div key={index} className={`flex flex-col md:flex-row items-center justify-between gap-8 ${index % 2 !== 0 ? 'md:flex-row-reverse' : ''}`}>
                    <div className="w-full md:w-5/12 text-center md:text-right">
                      <div className={`${index % 2 !== 0 ? 'md:text-left' : ''}`}>
                        <h3 className="text-2xl font-bold text-[#D4AF37] mb-2">{item.title}</h3>
                        <p className="text-gray-300">{item.desc}</p>
                      </div>
                    </div>
                    
                    <div className="relative flex items-center justify-center w-12 h-12 bg-[#D4AF37] rounded-full text-[#003366] font-bold z-10 shadow-[0_0_15px_rgba(212,175,55,0.5)]">
                      <div className="absolute w-16 h-16 bg-[#D4AF37]/30 rounded-full animate-pulse"></div>
                    </div>
                    
                    <div className="w-full md:w-5/12 text-center md:text-left">
                       <span className={`text-4xl font-black text-white/10 ${index % 2 !== 0 ? 'md:text-right block' : ''}`}>{item.year}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="py-20 bg-gray-50 text-center">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-[#003366] mb-6">Faça Parte da Nossa História</h2>
            <p className="text-gray-600 max-w-2xl mx-auto mb-8">
              Junte-se a milhares de clientes satisfeitos que escolheram a Stargrowth como sua loja de confiança.
            </p>
            <Link to="/" className="bg-[#003366] hover:bg-[#004488] text-white font-bold py-4 px-10 rounded-full shadow-lg transition-all inline-flex items-center gap-2">
              Começar a Comprar <Star size={20} fill="white" />
            </Link>
          </div>
        </section>
      </div>
    </>
  );
};

export default QuemSomos;
