
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { useCart } from '@/hooks/useCart';
import { initializeCheckout } from '@/api/EcommerceApi';
import { useCustomerAuth } from '@/context/CustomerAuthContext';
import { useToast } from '@/components/ui/use-toast';
import { ShieldCheck, Truck, CreditCard, CheckCircle, Lock, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';

const Checkout = () => {
  const navigate = useNavigate();
  const { cartItems, getCartTotal, clearCart } = useCart();
  const { currentUser } = useCustomerAuth();
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: currentUser?.name || '',
    email: currentUser?.email || '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zip: '',
    paymentMethod: 'card'
  });

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handlePlaceOrder = async (e) => {
    e.preventDefault();
    if (cartItems.length === 0) {
      toast({ title: "Carrinho vazio", variant: "destructive" });
      return;
    }

    setLoading(true);
    try {
      const items = cartItems.map(item => ({
        variant_id: item.variant.id,
        quantity: item.quantity,
      }));

      const successUrl = `${window.location.origin}/order-success`;
      const cancelUrl = window.location.href;

      // In a real scenario, we might pass customer data here too
      const { url } = await initializeCheckout({ items, successUrl, cancelUrl });

      // If we get a URL, redirect
      if (url) {
        window.location.href = url;
      } else {
        // Fallback for demo if API doesn't return URL (simulate success)
        clearCart();
        navigate('/order-success');
      }
    } catch (error) {
      toast({
        title: 'Erro no Checkout',
        description: 'Não foi possível processar o pedido. Tente novamente.',
        variant: 'destructive',
      });
      setLoading(false);
    }
  };

  if (cartItems.length === 0) {
     return <div className="min-h-screen flex items-center justify-center text-xl font-bold text-gray-500">Seu carrinho está vazio.</div>;
  }

  return (
    <>
      <Helmet><title>Checkout Seguro | Stargrowth</title></Helmet>
      <div className="min-h-screen bg-gray-50 py-10">
        <div className="container mx-auto px-4 max-w-6xl">
          <h1 className="text-3xl font-montserrat font-bold text-[#003366] mb-8 flex items-center gap-3">
             <Lock className="w-8 h-8" /> Checkout Seguro
          </h1>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Form Area */}
            <div className="lg:col-span-2 space-y-6">
              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
                <h2 className="text-xl font-bold text-[#003366] mb-6 flex items-center gap-2 border-b pb-4">
                  <div className="w-8 h-8 rounded-full bg-[#0a66c2] text-white flex items-center justify-center text-sm">1</div>
                  Informações de Entrega
                </h2>
                <form className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Nome Completo</label>
                    <input type="text" name="name" value={formData.name} onChange={handleInputChange} className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#0a66c2] outline-none" required />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <input type="email" name="email" value={formData.email} onChange={handleInputChange} className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#0a66c2] outline-none" required />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Telefone</label>
                    <input type="tel" name="phone" value={formData.phone} onChange={handleInputChange} className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#0a66c2] outline-none" required />
                  </div>
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Endereço</label>
                    <input type="text" name="address" value={formData.address} onChange={handleInputChange} className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#0a66c2] outline-none" required />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Cidade</label>
                    <input type="text" name="city" value={formData.city} onChange={handleInputChange} className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#0a66c2] outline-none" required />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Estado</label>
                        <input type="text" name="state" value={formData.state} onChange={handleInputChange} className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#0a66c2] outline-none" required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">CEP</label>
                        <input type="text" name="zip" value={formData.zip} onChange={handleInputChange} className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#0a66c2] outline-none" required />
                    </div>
                  </div>
                </form>
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
                <h2 className="text-xl font-bold text-[#003366] mb-6 flex items-center gap-2 border-b pb-4">
                   <div className="w-8 h-8 rounded-full bg-[#0a66c2] text-white flex items-center justify-center text-sm">2</div>
                   Pagamento
                </h2>
                <div className="space-y-3">
                    <label className={`flex items-center gap-4 p-4 border rounded-xl cursor-pointer transition-all ${formData.paymentMethod === 'card' ? 'border-[#0a66c2] bg-blue-50 ring-1 ring-[#0a66c2]' : 'hover:border-gray-300'}`}>
                      <input type="radio" name="paymentMethod" value="card" checked={formData.paymentMethod === 'card'} onChange={handleInputChange} className="w-5 h-5 text-[#0a66c2]" />
                      <div className="flex-1">
                         <span className="font-bold text-gray-800 block">Cartão de Crédito</span>
                         <span className="text-sm text-gray-500">Pagamento seguro via Stripe/Gateway</span>
                      </div>
                      <CreditCard className="text-gray-400" />
                    </label>

                    <label className={`flex items-center gap-4 p-4 border rounded-xl cursor-pointer transition-all ${formData.paymentMethod === 'pix' ? 'border-[#0a66c2] bg-blue-50 ring-1 ring-[#0a66c2]' : 'hover:border-gray-300'}`}>
                      <input type="radio" name="paymentMethod" value="pix" checked={formData.paymentMethod === 'pix'} onChange={handleInputChange} className="w-5 h-5 text-[#0a66c2]" />
                      <div className="flex-1">
                         <span className="font-bold text-gray-800 block">PIX</span>
                         <span className="text-sm text-gray-500">Aprovação imediata - 5% de desconto</span>
                      </div>
                      <div className="text-xs font-bold bg-green-100 text-green-700 px-2 py-1 rounded">-5% OFF</div>
                    </label>
                </div>
              </motion.div>
            </div>

            {/* Summary */}
            <div className="lg:col-span-1">
               <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 sticky top-24">
                  <h3 className="font-bold text-gray-800 mb-4 pb-2 border-b">Resumo do Pedido</h3>
                  <div className="space-y-3 mb-6 max-h-60 overflow-y-auto pr-2 custom-scrollbar">
                      {cartItems.map((item, idx) => (
                        <div key={idx} className="flex gap-3 text-sm">
                            <div className="w-12 h-12 bg-gray-100 rounded-md flex-shrink-0 overflow-hidden">
                               <img src={item.product.image} alt="" className="w-full h-full object-cover" />
                            </div>
                            <div className="flex-1">
                                <p className="font-medium text-gray-800 line-clamp-1">{item.product.title}</p>
                                <p className="text-gray-500 text-xs">{item.variant.title} (x{item.quantity})</p>
                            </div>
                            <div className="font-bold text-gray-700">
                                {item.variant.sale_price_formatted}
                            </div>
                        </div>
                      ))}
                  </div>
                  
                  <div className="space-y-2 pt-4 border-t text-sm mb-6">
                      <div className="flex justify-between text-gray-600">
                          <span>Subtotal</span>
                          <span>{getCartTotal()}</span>
                      </div>
                      <div className="flex justify-between text-gray-600">
                          <span>Frete</span>
                          <span className="text-green-600 font-bold">Grátis</span>
                      </div>
                      <div className="flex justify-between text-xl font-bold text-[#003366] mt-4 pt-4 border-t border-dashed">
                          <span>Total</span>
                          <span>{getCartTotal()}</span>
                      </div>
                  </div>

                  <button 
                    onClick={handlePlaceOrder}
                    disabled={loading}
                    className="w-full bg-[#0a66c2] hover:bg-[#004182] text-white font-bold py-4 rounded-xl shadow-lg hover:shadow-xl transition-all disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    {loading ? <Loader2 className="animate-spin" /> : <Lock size={18} />}
                    {loading ? 'Processando...' : 'Finalizar Pagamento'}
                  </button>
                  
                  <div className="mt-4 flex items-center justify-center gap-2 text-xs text-gray-500">
                     <ShieldCheck size={14} className="text-green-600" /> Ambiente Criptografado e Seguro
                  </div>
               </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Checkout;
