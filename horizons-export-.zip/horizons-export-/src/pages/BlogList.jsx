
import React, { useState, useMemo } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Search, Clock, Calendar, ChevronRight, User } from 'lucide-react';
import { blogPosts, blogCategories } from '@/data/blog';
import { useGoogleAnalytics } from '@/context/GoogleAnalyticsContext';

const BlogList = () => {
  const navigate = useNavigate();
  const { trackEvent } = useGoogleAnalytics();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('Todos');
  const [sortBy, setSortBy] = useState('newest');
  const [currentPage, setCurrentPage] = useState(1);
  const postsPerPage = 6;

  const handlePostClick = (slug) => {
    trackEvent('select_content', {
      content_type: 'blog_post',
      item_id: slug
    });
    navigate(`/blog/${slug}`);
  };

  const filteredPosts = useMemo(() => {
    let posts = blogPosts;

    // Filter by Category
    if (selectedCategory !== 'Todos') {
      posts = posts.filter(post => post.category === selectedCategory);
    }

    // Filter by Search
    if (searchTerm) {
      posts = posts.filter(post => 
        post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        post.description.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Sort
    if (sortBy === 'newest') {
      posts = [...posts].sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt));
    } else if (sortBy === 'oldest') {
      posts = [...posts].sort((a, b) => new Date(a.publishedAt) - new Date(b.publishedAt));
    }

    return posts;
  }, [selectedCategory, searchTerm, sortBy]);

  // Pagination Logic
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const currentPosts = filteredPosts.slice(indexOfFirstPost, indexOfLastPost);
  const totalPages = Math.ceil(filteredPosts.length / postsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <>
      <Helmet>
        <title>Blog Stargrowth - Dicas, Tendências e Estilo de Vida</title>
        <meta name="description" content="Explore nosso blog com artigos sobre tecnologia, moda, bem-estar e muito mais para transformar sua rotina." />
      </Helmet>

      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          
          {/* Header */}
          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-montserrat font-bold text-[#003366] mb-4">
              Blog Stargrowth
            </h1>
            <p className="text-gray-600 font-poppins max-w-2xl mx-auto">
              Conteúdo exclusivo para inspirar seu dia a dia, com dicas de especialistas e as últimas tendências do mercado.
            </p>
          </div>

          {/* Filters & Search */}
          <div className="bg-white rounded-2xl shadow-md p-6 mb-12 border border-gray-100">
            <div className="flex flex-col lg:flex-row gap-6 justify-between items-center">
              
              {/* Category Buttons */}
              <div className="flex flex-wrap gap-2 justify-center lg:justify-start w-full lg:w-auto">
                {blogCategories.map(category => (
                  <button
                    key={category}
                    onClick={() => { setSelectedCategory(category); setCurrentPage(1); }}
                    className={`px-4 py-2 rounded-full text-sm font-bold transition-all ${
                      selectedCategory === category
                        ? 'bg-[#003366] text-white shadow-md'
                        : 'bg-gray-100 text-gray-600 hover:bg-[#D4AF37] hover:text-white'
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>

              {/* Search & Sort */}
              <div className="flex flex-col sm:flex-row gap-4 w-full lg:w-auto">
                <div className="relative flex-grow">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Buscar artigos..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#D4AF37] text-sm"
                  />
                </div>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#D4AF37] text-sm bg-white text-gray-700"
                >
                  <option value="newest">Mais Recentes</option>
                  <option value="oldest">Mais Antigos</option>
                </select>
              </div>
            </div>
          </div>

          {/* Blog Grid */}
          {filteredPosts.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {currentPosts.map((post, index) => (
                <motion.div
                  key={post.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ y: -10 }}
                  className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all border border-gray-100 group cursor-pointer flex flex-col h-full"
                  onClick={() => handlePostClick(post.slug)}
                >
                  <div className="relative overflow-hidden aspect-video">
                    <img 
                      src={post.image} 
                      alt={post.title} 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    />
                    <div className="absolute top-4 left-4 bg-[#D4AF37] text-[#003366] text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-sm">
                      {post.category}
                    </div>
                  </div>
                  
                  <div className="p-6 flex flex-col flex-grow">
                    <div className="flex items-center gap-4 text-xs text-gray-500 mb-3 font-medium">
                      <span className="flex items-center gap-1">
                        <Calendar size={12} className="text-[#D4AF37]" />
                        {new Date(post.publishedAt).toLocaleDateString('pt-BR')}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock size={12} className="text-[#D4AF37]" />
                        {post.readTime}
                      </span>
                    </div>

                    <h2 className="text-xl font-montserrat font-bold text-[#003366] mb-3 line-clamp-2 group-hover:text-[#D4AF37] transition-colors">
                      {post.title}
                    </h2>
                    
                    <p className="text-gray-600 font-poppins text-sm mb-4 line-clamp-3 leading-relaxed flex-grow">
                      {post.description}
                    </p>

                    <div className="flex items-center justify-between mt-auto pt-4 border-t border-gray-100">
                      <div className="flex items-center gap-2 text-xs font-bold text-gray-500">
                        <div className="w-6 h-6 rounded-full bg-gray-200 flex items-center justify-center text-[#003366]">
                           <User size={12} />
                        </div>
                        {post.author}
                      </div>
                      <span className="text-[#003366] text-sm font-bold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                        Ler Artigo <ChevronRight size={16} />
                      </span>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <p className="text-xl text-gray-500 font-poppins">Nenhum artigo encontrado com esses critérios.</p>
              <button 
                onClick={() => { setSearchTerm(''); setSelectedCategory('Todos'); }}
                className="mt-4 text-[#003366] font-bold hover:underline"
              >
                Limpar filtros
              </button>
            </div>
          )}

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center mt-12 gap-2">
              {[...Array(totalPages)].map((_, i) => (
                <button
                  key={i}
                  onClick={() => handlePageChange(i + 1)}
                  className={`w-10 h-10 rounded-full font-bold transition-all ${
                    currentPage === i + 1
                      ? 'bg-[#003366] text-white shadow-lg scale-110'
                      : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-100'
                  }`}
                >
                  {i + 1}
                </button>
              ))}
            </div>
          )}

        </div>
      </div>
    </>
  );
};

export default BlogList;
