
import React from 'react';
import { useCustomerAuth } from '@/context/CustomerAuthContext';
import { Helmet } from 'react-helmet';
import { User, Package, MapPin, Heart, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const CustomerDashboard = () => {
  const { currentUser, logout } = useCustomerAuth();
  const navigate = useNavigate();

  if (!currentUser) {
     navigate('/login');
     return null;
  }

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <>
      <Helmet><title>Minha Conta | Stargrowth</title></Helmet>
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4">
           <h1 className="text-3xl font-bold text-[#003366] mb-8">Olá, {currentUser.name}</h1>
           
           <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {/* Sidebar */}
              <div className="bg-white p-6 rounded-2xl shadow-sm h-fit">
                 <nav className="space-y-2">
                    <button className="w-full flex items-center gap-3 p-3 bg-blue-50 text-[#003366] font-bold rounded-lg"><User size={20} /> Perfil</button>
                    <button className="w-full flex items-center gap-3 p-3 text-gray-600 hover:bg-gray-50 rounded-lg"><Package size={20} /> Pedidos</button>
                    <button className="w-full flex items-center gap-3 p-3 text-gray-600 hover:bg-gray-50 rounded-lg"><MapPin size={20} /> Endereços</button>
                    <button className="w-full flex items-center gap-3 p-3 text-gray-600 hover:bg-gray-50 rounded-lg"><Heart size={20} /> Favoritos</button>
                    <button onClick={handleLogout} className="w-full flex items-center gap-3 p-3 text-red-600 hover:bg-red-50 rounded-lg mt-4"><LogOut size={20} /> Sair</button>
                 </nav>
              </div>

              {/* Content */}
              <div className="md:col-span-3">
                 <div className="bg-white p-8 rounded-2xl shadow-sm mb-6">
                    <h2 className="text-xl font-bold text-gray-800 mb-4">Meus Dados</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                       <div className="p-4 bg-gray-50 rounded-lg">
                          <p className="text-sm text-gray-500">Nome</p>
                          <p className="font-bold text-gray-800">{currentUser.name}</p>
                       </div>
                       <div className="p-4 bg-gray-50 rounded-lg">
                          <p className="text-sm text-gray-500">Email</p>
                          <p className="font-bold text-gray-800">{currentUser.email}</p>
                       </div>
                    </div>
                 </div>

                 <div className="bg-white p-8 rounded-2xl shadow-sm">
                    <h2 className="text-xl font-bold text-gray-800 mb-4">Últimos Pedidos</h2>
                    <div className="text-center py-10 text-gray-500 bg-gray-50 rounded-xl border border-dashed border-gray-300">
                       <Package size={40} className="mx-auto mb-2 text-gray-300" />
                       <p>Você ainda não fez nenhum pedido.</p>
                       <button onClick={() => navigate('/')} className="mt-4 text-[#003366] font-bold hover:underline">Começar a comprar</button>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      </div>
    </>
  );
};

export default CustomerDashboard;
