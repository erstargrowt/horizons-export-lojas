
import React from 'react';
import { Helmet } from 'react-helmet';
import TopBar from '@/components/TopBar';
import PromoBannerCarousel from '@/components/PromoBannerCarousel';
import CategoryCarousel from '@/components/home/CategoryCarousel';
import ProductsList from '@/components/ProductsList';
import BestSellersCarousel from '@/components/home/BestSellersCarousel';
import NewProductsCarousel from '@/components/home/NewProductsCarousel';
import DepartmentsSection from '@/components/home/DepartmentsSection';
import TrustSection from '@/components/home/TrustSection';
import { motion } from 'framer-motion';

const Home = () => {
  return (
    <>
      <Helmet>
        <title>Stargrowth | Loja Online de Produtos Premium</title>
        <meta name="description" content="Encontre os melhores produtos com frete grátis, pagamento seguro e entrega rápida. Eletrônicos, Relógios, Cosméticos e muito mais." />
        <meta name="keywords" content="ecommerce, loja online, eletrônicos, relógios, cosméticos, stargrowth, compras" />
      </Helmet>

      <div className="flex flex-col min-h-screen">
        <TopBar />
        {/* Header is included in ClientLayout in App.jsx */}
        
        <main className="flex-grow">
          <PromoBannerCarousel />
          <CategoryCarousel />
          
          <section className="container mx-auto px-4 py-16">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-10"
            >
              <h2 className="text-3xl font-montserrat font-bold text-[#003366] mb-4">
                Destaques da Loja
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Explore nossa seleção exclusiva de produtos de alta qualidade, escolhidos especialmente para você.
              </p>
            </motion.div>
            <ProductsList />
          </section>

          <DepartmentsSection />
          <BestSellersCarousel />
          <NewProductsCarousel />
          <TrustSection />
        </main>
      </div>
    </>
  );
};

export default Home;
