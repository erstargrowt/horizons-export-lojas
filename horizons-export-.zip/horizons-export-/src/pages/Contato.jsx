
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { Mail, Phone, MapPin, Clock, Send, CheckCircle, Home, ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';

const Contato = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);

    // Simulate API call
    setTimeout(() => {
      setLoading(false);
      toast({
        title: "Mensagem Enviada!",
        description: "Agradecemos seu contato. Responderemos em breve.",
        className: "bg-green-50 border-green-200",
      });
      setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
    }, 1500);
  };

  return (
    <>
      <Helmet>
        <title>Stargrowth | Fale Conosco</title>
        <meta name="description" content="Entre em contato com a equipe Stargrowth via email, telefone ou WhatsApp. Estamos prontos para atender você." />
      </Helmet>

      <div className="bg-gray-50 min-h-screen py-8">
        <div className="container mx-auto px-4">
          
          {/* Breadcrumb */}
          <div className="flex items-center gap-2 text-sm text-gray-500 mb-8">
            <Link to="/" className="hover:text-[#003366] flex items-center gap-1"><Home size={14} /> Home</Link>
            <ChevronRight size={14} />
            <span className="text-[#003366] font-bold">Contato</span>
          </div>

          <div className="text-center mb-16">
             <h1 className="text-3xl md:text-4xl font-montserrat font-bold text-[#003366] mb-4">Fale Conosco</h1>
             <p className="text-gray-600 max-w-xl mx-auto">Tem alguma dúvida, sugestão ou precisa de ajuda com um pedido? Nossa equipe está pronta para te atender.</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Contact Info */}
            <div className="lg:col-span-1 space-y-6">
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-white p-8 rounded-xl shadow-md border-t-4 border-[#D4AF37]"
              >
                <h2 className="font-bold text-xl text-[#003366] mb-6">Informações de Contato</h2>
                
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="bg-blue-50 p-3 rounded-full text-[#003366]">
                      <Phone size={20} />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 font-bold uppercase mb-1">Telefone / WhatsApp</p>
                      <p className="text-[#003366] font-medium text-lg">(27) 99999-9999</p>
                      <p className="text-gray-400 text-sm">Segunda a Sexta, 9h às 18h</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-blue-50 p-3 rounded-full text-[#003366]">
                      <Mail size={20} />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 font-bold uppercase mb-1">Email</p>
                      <p className="text-[#003366] font-medium text-lg">contato@stargrowth.com.br</p>
                      <p className="text-gray-400 text-sm">Respondemos em até 24h</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-blue-50 p-3 rounded-full text-[#003366]">
                      <MapPin size={20} />
                    </div>
                    <div>
                      <p className="text-sm text-gray-500 font-bold uppercase mb-1">Endereço</p>
                      <p className="text-[#003366] font-medium">Av. da Praia, 1000</p>
                      <p className="text-[#003366]">Praia da Costa, Vila Velha - ES</p>
                      <p className="text-[#003366]">CEP: 29100-000</p>
                    </div>
                  </div>
                </div>

                {/* Map Placeholder */}
                <div className="mt-8 rounded-lg overflow-hidden h-48 bg-gray-200 w-full relative">
                  <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3741.153215892543!2d-40.28636952498263!3d-20.33528818114611!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xb8163812c6c2cd%3A0x6e7526f4aa7771b3!2sPraia%20da%20Costa%2C%20Vila%20Velha%20-%20ES!5e0!3m2!1spt-BR!2sbr!4v1704987654321!5m2!1spt-BR!2sbr" 
                    width="100%" 
                    height="100%" 
                    style={{ border: 0 }} 
                    allowFullScreen="" 
                    loading="lazy" 
                    referrerPolicy="no-referrer-when-downgrade"
                  ></iframe>
                </div>
              </motion.div>
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-2">
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="bg-white p-8 rounded-xl shadow-md h-full"
              >
                <h2 className="font-bold text-xl text-[#003366] mb-6">Envie uma Mensagem</h2>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-gray-700">Seu Nome</label>
                      <input 
                        type="text" 
                        name="name"
                        required
                        value={formData.name}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#003366] focus:ring-1 focus:ring-[#003366] outline-none transition-all"
                        placeholder="Nome completo"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-gray-700">Seu Email</label>
                      <input 
                        type="email" 
                        name="email"
                        required
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#003366] focus:ring-1 focus:ring-[#003366] outline-none transition-all"
                        placeholder="exemplo@email.com"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-gray-700">Telefone</label>
                      <input 
                        type="tel" 
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#003366] focus:ring-1 focus:ring-[#003366] outline-none transition-all"
                        placeholder="(DD) 99999-9999"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-gray-700">Assunto</label>
                      <select 
                        name="subject"
                        value={formData.subject}
                        onChange={handleChange}
                        className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#003366] focus:ring-1 focus:ring-[#003366] outline-none transition-all bg-white"
                      >
                        <option value="">Selecione um assunto</option>
                        <option value="duvida">Dúvida sobre produto</option>
                        <option value="pedido">Status do Pedido</option>
                        <option value="suporte">Suporte Técnico</option>
                        <option value="troca">Troca ou Devolução</option>
                        <option value="outro">Outro</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-700">Mensagem</label>
                    <textarea 
                      name="message"
                      required
                      value={formData.message}
                      onChange={handleChange}
                      rows="6"
                      className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:border-[#003366] focus:ring-1 focus:ring-[#003366] outline-none transition-all resize-none"
                      placeholder="Como podemos ajudar você hoje?"
                    ></textarea>
                  </div>

                  <button 
                    type="submit" 
                    disabled={loading}
                    className="w-full bg-[#003366] hover:bg-[#004488] text-white font-bold py-4 rounded-lg shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
                  >
                    {loading ? (
                      <span className="flex items-center gap-2">Enviando...</span>
                    ) : (
                      <span className="flex items-center gap-2"><Send size={20} /> Enviar Mensagem</span>
                    )}
                  </button>
                </form>
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Contato;
