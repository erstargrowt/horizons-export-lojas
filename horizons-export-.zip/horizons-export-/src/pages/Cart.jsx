
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Trash2, Plus, Minus, ShoppingBag, ArrowRight, ShieldCheck, Tag } from 'lucide-react';
import { useCart } from '@/hooks/useCart';
import { Button } from '@/components/ui/button';

const Cart = () => {
  const navigate = useNavigate();
  const { cartItems, removeFromCart, updateQuantity, getCartTotal } = useCart();
  const [couponCode, setCouponCode] = useState('');

  if (cartItems.length === 0) {
    return (
      <>
        <Helmet><title>Carrinho Vazio | Stargrowth</title></Helmet>
        <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center p-4">
           <div className="bg-white p-8 rounded-full shadow-sm mb-6">
              <ShoppingBag size={64} className="text-gray-300" />
           </div>
           <h1 className="text-2xl font-bold text-[#003366] mb-2">Seu carrinho está vazio</h1>
           <p className="text-gray-500 mb-8">Parece que você ainda não adicionou nenhum item.</p>
           <Link to="/">
              <Button className="bg-[#0a66c2] text-white px-8 py-6 rounded-xl text-lg hover:bg-[#004182]">
                 Começar a Comprar
              </Button>
           </Link>
        </div>
      </>
    );
  }

  return (
    <>
      <Helmet><title>Meu Carrinho | Stargrowth</title></Helmet>
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4 max-w-6xl">
           <h1 className="text-3xl font-montserrat font-bold text-[#003366] mb-8 flex items-center gap-3">
              <ShoppingBag /> Carrinho de Compras
           </h1>

           <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Cart Items List */}
              <div className="lg:col-span-2 space-y-4">
                 {cartItems.map((item) => (
                    <motion.div 
                      layout
                      key={item.variant.id} 
                      className="bg-white p-4 sm:p-6 rounded-2xl shadow-sm border border-gray-100 flex gap-4 sm:gap-6"
                    >
                       <div className="w-24 h-24 sm:w-32 sm:h-32 bg-gray-100 rounded-xl overflow-hidden flex-shrink-0">
                          <img src={item.product.image} alt={item.product.title} className="w-full h-full object-cover" />
                       </div>
                       
                       <div className="flex-1 flex flex-col justify-between">
                          <div>
                             <div className="flex justify-between items-start">
                                <h3 className="font-bold text-gray-800 text-lg line-clamp-2">{item.product.title}</h3>
                                <button 
                                  onClick={() => removeFromCart(item.variant.id)}
                                  className="text-gray-400 hover:text-red-500 transition-colors"
                                >
                                   <Trash2 size={20} />
                                </button>
                             </div>
                             <p className="text-sm text-gray-500 mt-1">{item.variant.title}</p>
                          </div>
                          
                          <div className="flex flex-wrap items-end justify-between gap-4 mt-4">
                             <div className="flex items-center border border-gray-200 rounded-lg">
                                <button onClick={() => updateQuantity(item.variant.id, item.quantity - 1)} className="p-2 hover:bg-gray-50 text-gray-600"><Minus size={16} /></button>
                                <span className="w-10 text-center font-bold text-gray-800">{item.quantity}</span>
                                <button onClick={() => updateQuantity(item.variant.id, item.quantity + 1)} className="p-2 hover:bg-gray-50 text-gray-600"><Plus size={16} /></button>
                             </div>
                             <div className="text-xl font-bold text-[#003366]">
                                {item.variant.sale_price_formatted}
                             </div>
                          </div>
                       </div>
                    </motion.div>
                 ))}
              </div>

              {/* Summary */}
              <div className="lg:col-span-1">
                 <div className="bg-white p-6 rounded-2xl shadow-lg border border-gray-100 sticky top-24">
                    <h2 className="text-xl font-bold text-[#003366] mb-6 pb-4 border-b">Resumo</h2>
                    
                    <div className="space-y-4 mb-6">
                       <div className="flex justify-between text-gray-600">
                          <span>Subtotal</span>
                          <span>{getCartTotal()}</span>
                       </div>
                       <div className="flex justify-between text-gray-600">
                          <span>Frete</span>
                          <span className="text-green-600 font-bold">Grátis</span>
                       </div>
                       
                       <div className="pt-4 mt-2 border-t border-dashed">
                          <div className="flex justify-between items-end">
                             <span className="font-bold text-gray-800">Total</span>
                             <span className="text-2xl font-bold text-[#003366]">{getCartTotal()}</span>
                          </div>
                          <p className="text-xs text-gray-400 mt-1 text-right">ou em até 10x sem juros</p>
                       </div>
                    </div>

                    <div className="mb-6">
                       <div className="relative">
                          <Tag className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
                          <input 
                            type="text" 
                            placeholder="Cupom de desconto" 
                            className="w-full pl-9 pr-24 py-3 border border-gray-200 rounded-lg text-sm focus:ring-[#0a66c2] focus:border-[#0a66c2] outline-none"
                            value={couponCode}
                            onChange={(e) => setCouponCode(e.target.value)}
                          />
                          <button className="absolute right-1 top-1 bottom-1 bg-gray-100 text-gray-600 hover:bg-gray-200 px-4 rounded-md text-xs font-bold transition-colors">
                             Aplicar
                          </button>
                       </div>
                    </div>

                    <div className="space-y-3">
                       <Button 
                         onClick={() => navigate('/checkout')}
                         className="w-full bg-[#0a66c2] hover:bg-[#004182] text-white py-6 rounded-xl text-lg font-bold shadow-lg hover:shadow-xl transition-all"
                       >
                          Finalizar Compra
                       </Button>
                       <Link to="/">
                          <Button variant="outline" className="w-full py-6 rounded-xl text-gray-600 hover:text-[#003366] border-gray-200">
                             Continuar Comprando
                          </Button>
                       </Link>
                    </div>

                    <div className="mt-6 flex items-center justify-center gap-2 text-xs text-gray-500 bg-gray-50 p-2 rounded-lg">
                       <ShieldCheck size={14} className="text-green-600" /> Compra 100% Segura
                    </div>
                 </div>
              </div>
           </div>
        </div>
      </div>
    </>
  );
};

export default Cart;
