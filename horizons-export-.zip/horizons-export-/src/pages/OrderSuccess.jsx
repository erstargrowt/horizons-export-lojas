
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { CheckCircle, Package, ArrowRight, ShoppingBag } from 'lucide-react';
import { motion } from 'framer-motion';
import confetti from 'canvas-confetti';

const OrderSuccess = () => {
  const navigate = useNavigate();
  const orderNumber = Math.floor(100000 + Math.random() * 900000);
  const deliveryDate = new Date();
  deliveryDate.setDate(deliveryDate.getDate() + 5);

  useEffect(() => {
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 },
      colors: ['#0a66c2', '#D4AF37', '#ffffff']
    });
  }, []);

  return (
    <>
      <Helmet><title>Pedido Confirmado | Stargrowth</title></Helmet>
      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex items-center justify-center p-4">
        <motion.div 
           initial={{ scale: 0.8, opacity: 0 }}
           animate={{ scale: 1, opacity: 1 }}
           className="bg-white max-w-lg w-full p-8 rounded-3xl shadow-2xl text-center border border-gray-100"
        >
           <motion.div 
             initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.2, type: "spring" }}
             className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-inner"
           >
              <CheckCircle size={48} />
           </motion.div>
           
           <h1 className="text-3xl font-montserrat font-bold text-[#003366] mb-2">Pagamento Confirmado!</h1>
           <p className="text-gray-600 mb-8 font-medium">Obrigado por comprar na Stargrowth. Seu pedido está sendo preparado com carinho.</p>
           
           <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100 mb-8 text-left space-y-4">
              <div className="flex justify-between items-center pb-4 border-b border-blue-100">
                 <span className="text-sm text-gray-500 uppercase font-bold">Pedido Nº</span>
                 <span className="text-xl font-mono font-bold text-[#003366]">#{orderNumber}</span>
              </div>
              <div className="flex justify-between items-center">
                 <span className="text-sm text-gray-500 uppercase font-bold">Entrega Estimada</span>
                 <span className="font-bold text-gray-800">{deliveryDate.toLocaleDateString()}</span>
              </div>
           </div>

           <div className="space-y-3">
              <button 
                onClick={() => navigate('/rastreamento')}
                className="w-full bg-[#0a66c2] text-white font-bold py-4 rounded-xl hover:bg-[#004182] flex items-center justify-center gap-2 shadow-lg hover:shadow-xl transition-all"
              >
                 <Package size={20} /> Rastrear Meu Pedido
              </button>
              <button 
                onClick={() => navigate('/')}
                className="w-full bg-white border-2 border-gray-100 text-gray-600 font-bold py-4 rounded-xl hover:border-[#003366] hover:text-[#003366] transition-all flex items-center justify-center gap-2"
              >
                 <ShoppingBag size={20} /> Continuar Comprando
              </button>
           </div>
        </motion.div>
      </div>
    </>
  );
};

export default OrderSuccess;
