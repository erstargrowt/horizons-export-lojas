
import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { getProduct, getProductQuantities } from '@/api/EcommerceApi';
import { Button } from '@/components/ui/button';
import { useCart } from '@/hooks/useCart';
import { useToast } from '@/components/ui/use-toast';
import { ShoppingCart, Loader2, ArrowLeft, CheckCircle, Minus, Plus, XCircle, ChevronLeft, ChevronRight, Star, ShieldCheck } from 'lucide-react';

const placeholderImage = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjMzc0MTUxIi8+CiAgPHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzlDQTNBRiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5vIEltYWdlPC90ZXh0Pgo8L3N2Zz4K";

function ProductDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedVariant, setSelectedVariant] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const { addToCart } = useCart();
  const { toast } = useToast();

  const handleAddToCart = useCallback(async () => {
    if (product && selectedVariant) {
      const availableQuantity = selectedVariant.inventory_quantity;
      try {
        await addToCart(product, selectedVariant, quantity, availableQuantity);
        toast({
          title: "Sucesso! 🛒",
          description: `${quantity} x ${product.title} adicionado ao carrinho.`,
          className: "bg-green-50 text-green-900 border-green-200",
        });
      } catch (error) {
        toast({
          variant: "destructive",
          title: "Erro ao adicionar",
          description: error.message,
        });
      }
    }
  }, [product, selectedVariant, quantity, addToCart, toast]);

  const handleQuantityChange = useCallback((amount) => {
    setQuantity(prevQuantity => {
        const newQuantity = prevQuantity + amount;
        if (newQuantity < 1) return 1;
        return newQuantity;
    });
  }, []);

  const handlePrevImage = useCallback(() => {
    if (product?.images?.length > 1) {
      setCurrentImageIndex(prev => prev === 0 ? product.images.length - 1 : prev - 1);
    }
  }, [product?.images?.length]);

  const handleNextImage = useCallback(() => {
    if (product?.images?.length > 1) {
      setCurrentImageIndex(prev => prev === product.images.length - 1 ? 0 : prev + 1);
    }
  }, [product?.images?.length]);

  const handleVariantSelect = useCallback((variant) => {
    setSelectedVariant(variant);
    if (variant.image_url && product?.images?.length > 0) {
      const imageIndex = product.images.findIndex(image => image.url === variant.image_url);
      if (imageIndex !== -1) {
        setCurrentImageIndex(imageIndex);
      }
    }
  }, [product?.images]);

  useEffect(() => {
    const fetchProductData = async () => {
      try {
        setLoading(true);
        setError(null);
        const fetchedProduct = await getProduct(id);

        try {
          const quantitiesResponse = await getProductQuantities({
            fields: 'inventory_quantity',
            product_ids: [fetchedProduct.id]
          });

          const variantQuantityMap = new Map();
          quantitiesResponse.variants.forEach(variant => {
            variantQuantityMap.set(variant.id, variant.inventory_quantity);
          });

          const productWithQuantities = {
            ...fetchedProduct,
            variants: fetchedProduct.variants.map(variant => ({
              ...variant,
              inventory_quantity: variantQuantityMap.get(variant.id) ?? variant.inventory_quantity
            }))
          };

          setProduct(productWithQuantities);
          if (productWithQuantities.variants && productWithQuantities.variants.length > 0) {
            setSelectedVariant(productWithQuantities.variants[0]);
          }
        } catch (quantityError) {
          throw quantityError;
        }
      } catch (err) {
        setError(err.message || 'Falha ao carregar produto');
      } finally {
        setLoading(false);
      }
    };
    fetchProductData();
  }, [id, navigate]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[60vh] bg-white">
        <Loader2 className="h-16 w-16 text-[#0a66c2] animate-spin" />
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="max-w-5xl mx-auto py-12 px-4">
        <Link to="/" className="inline-flex items-center gap-2 text-[#0a66c2] hover:text-[#D4AF37] transition-colors mb-6 font-bold">
          <ArrowLeft size={16} /> Voltar para Loja
        </Link>
        <div className="text-center text-red-500 p-8 bg-red-50 rounded-2xl border border-red-100">
          <XCircle className="mx-auto h-16 w-16 mb-4" />
          <p className="mb-6 font-bold">Erro: {error}</p>
        </div>
      </div>
    );
  }

  const price = selectedVariant?.sale_price_formatted ?? selectedVariant?.price_formatted;
  const originalPrice = selectedVariant?.price_formatted;
  const availableStock = selectedVariant ? selectedVariant.inventory_quantity : 0;
  const isStockManaged = selectedVariant?.manage_inventory ?? false;
  const canAddToCart = !isStockManaged || quantity <= availableStock;
  const currentImage = product.images[currentImageIndex];
  const hasMultipleImages = product.images.length > 1;

  return (
    <>
      <Helmet>
        <title>{product.title} - Stargrowth</title>
        <meta name="description" content={product.description?.substring(0, 160) || product.title} />
      </Helmet>
      
      <div className="bg-gray-50 min-h-screen py-10">
        <div className="container mx-auto px-4 max-w-6xl">
          <Link to="/" className="inline-flex items-center gap-2 text-[#0a66c2] hover:text-[#D4AF37] transition-colors mb-6 font-semibold">
            <ArrowLeft size={16} /> Voltar para Loja
          </Link>
          
          <div className="grid md:grid-cols-2 gap-8 bg-white p-8 rounded-3xl shadow-xl border border-gray-100">
            
            {/* Image Section */}
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5 }} className="relative">
              <div className="relative overflow-hidden rounded-2xl shadow-sm border border-gray-100 aspect-square">
                <img
                  src={!currentImage?.url ? placeholderImage : currentImage.url}
                  alt={product.title}
                  className="w-full h-full object-cover transition-transform hover:scale-105 duration-700"
                />

                {hasMultipleImages && (
                  <>
                    <button
                      onClick={handlePrevImage}
                      className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-[#0a66c2] p-3 rounded-full shadow-lg transition-all"
                    >
                      <ChevronLeft size={24} />
                    </button>
                    <button
                      onClick={handleNextImage}
                      className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/80 hover:bg-white text-[#0a66c2] p-3 rounded-full shadow-lg transition-all"
                    >
                      <ChevronRight size={24} />
                    </button>
                  </>
                )}

                {product.ribbon_text && (
                  <div className="absolute top-4 left-4 bg-[#D4AF37] text-white text-sm font-bold px-4 py-2 rounded-full shadow-lg">
                    {product.ribbon_text}
                  </div>
                )}
              </div>

              {hasMultipleImages && (
                <div className="flex gap-2 mt-4 overflow-x-auto pb-2">
                  {product.images.map((image, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentImageIndex(index)}
                      className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-all ${
                        index === currentImageIndex ? 'border-[#0a66c2] ring-2 ring-offset-2 ring-[#0a66c2]' : 'border-gray-200 hover:border-[#D4AF37]'
                      }`}
                    >
                      <img
                        src={!image.url ? placeholderImage : image.url}
                        alt={`${product.title} ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </button>
                  ))}
                </div>
              )}
            </motion.div>

            {/* Product Info Section */}
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.2 }} className="flex flex-col">
              <div className="mb-4">
                 <span className="bg-[#0a66c2]/10 text-[#0a66c2] px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">
                   Novo
                 </span>
              </div>
              
              <h1 className="text-3xl md:text-4xl font-montserrat font-bold text-[#003366] mb-2">{product.title}</h1>
              <p className="text-lg text-gray-500 mb-6">{product.subtitle}</p>
              
              <div className="flex items-center gap-2 mb-6">
                 <div className="flex text-yellow-400">
                    <Star className="fill-current w-5 h-5" />
                    <Star className="fill-current w-5 h-5" />
                    <Star className="fill-current w-5 h-5" />
                    <Star className="fill-current w-5 h-5" />
                    <Star className="fill-current w-5 h-5" />
                 </div>
                 <span className="text-gray-400 text-sm">(12 avaliações)</span>
              </div>

              <div className="bg-gray-50 p-6 rounded-2xl border border-gray-100 mb-8">
                <div className="flex items-baseline gap-4 mb-2">
                  <span className="text-4xl font-bold text-[#0a66c2]">{price}</span>
                  {selectedVariant?.sale_price_in_cents && (
                    <span className="text-xl text-gray-400 line-through">{originalPrice}</span>
                  )}
                </div>
                {selectedVariant?.sale_price_in_cents && (
                   <p className="text-green-600 font-bold text-sm flex items-center gap-1">
                      <CheckCircle size={14} /> Preço promocional por tempo limitado
                   </p>
                )}
              </div>

              <div className="prose prose-sm text-gray-600 mb-8 max-w-none" dangerouslySetInnerHTML={{ __html: product.description }} />

              {product.variants.length > 1 && (
                <div className="mb-6">
                  <h3 className="text-sm font-bold text-[#003366] mb-3 uppercase tracking-wider">Opções</h3>
                  <div className="flex flex-wrap gap-3">
                    {product.variants.map(variant => (
                      <Button
                        key={variant.id}
                        variant="outline"
                        onClick={() => handleVariantSelect(variant)}
                        className={`transition-all h-auto py-2 px-4 border-2 ${selectedVariant?.id === variant.id ? 'border-[#0a66c2] bg-blue-50 text-[#0a66c2] font-bold' : 'border-gray-200 text-gray-600 hover:border-[#D4AF37]'}`}
                      >
                        {variant.title}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex items-center gap-6 mb-8">
                <div className="flex items-center border-2 border-gray-200 rounded-lg bg-white">
                  <Button onClick={() => handleQuantityChange(-1)} variant="ghost" size="icon" className="h-12 w-12 text-gray-600 hover:text-[#0a66c2]"><Minus size={18} /></Button>
                  <span className="w-12 text-center text-lg font-bold text-[#003366]">{quantity}</span>
                  <Button onClick={() => handleQuantityChange(1)} variant="ghost" size="icon" className="h-12 w-12 text-gray-600 hover:text-[#0a66c2]"><Plus size={18} /></Button>
                </div>
                
                <div className="flex-1">
                   {isStockManaged && canAddToCart && product.purchasable && (
                    <p className="text-xs text-green-600 mb-2 font-bold flex items-center gap-1">
                      <CheckCircle size={12} /> {availableStock} unidades disponíveis
                    </p>
                  )}
                  {isStockManaged && !canAddToCart && product.purchasable && (
                     <p className="text-xs text-red-500 mb-2 font-bold flex items-center gap-1">
                      <XCircle size={12} /> Estoque insuficiente
                    </p>
                  )}
                </div>
              </div>

              <div className="mt-auto space-y-4">
                <Button 
                  onClick={handleAddToCart} 
                  className="w-full bg-[#0a66c2] hover:bg-[#004182] text-white font-bold py-6 text-lg rounded-xl shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
                  disabled={!canAddToCart || !product.purchasable}
                >
                  <ShoppingCart className="h-6 w-6" /> Adicionar ao Carrinho
                </Button>
                
                <div className="flex items-center justify-center gap-2 text-sm text-gray-500 bg-gray-50 py-3 rounded-lg">
                   <ShieldCheck size={16} className="text-[#D4AF37]" /> Garantia de 30 dias | Compra Segura
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </>
  );
}

export default ProductDetailPage;
