
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Star, ShoppingCart, Minus, Plus, Truck, ShieldCheck, Eye, Clock, Instagram, CheckCircle } from 'lucide-react';
import { products } from '@/data/products';
import { useCart } from '@/context/CartContext';
import { useToast } from '@/components/ui/use-toast';
import ProductCard from '@/components/ProductCard';
import RatingDistribution from '@/components/RatingDistribution';
import ReviewForm from '@/components/ReviewForm';
import ReviewList from '@/components/ReviewList';
import Breadcrumb from '@/components/Breadcrumb';

const ProductDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [quantity, setQuantity] = useState(1);
  const [reviews, setReviews] = useState([]);
  const [viewers, setViewers] = useState(0);
  const [timeLeft, setTimeLeft] = useState(900); // 15 minutes in seconds

  const product = products.find(p => p.id === parseInt(id));

  useEffect(() => {
    if (product) {
      const savedReviews = JSON.parse(localStorage.getItem(`stargrowth_reviews_${product.id}`)) || [];
      if (savedReviews.length === 0) {
        // Mock reviews
        const mockReviews = [
           { id: 1, productId: product.id, rating: 5, title: 'Incrível!', comment: 'Superou expectativas.', author: 'Carlos', date: '2023-12-01', verified: true },
           { id: 2, productId: product.id, rating: 5, title: 'Recomendo', comment: 'Chegou muito rápido.', author: 'Ana', date: '2023-11-20', verified: true }
        ];
        setReviews(mockReviews);
      } else {
        setReviews(savedReviews);
      }
    }
    setViewers(Math.floor(Math.random() * 15) + 5);
    
    const timer = setInterval(() => {
       setTimeLeft(prev => (prev > 0 ? prev - 1 : 900));
    }, 1000);
    return () => clearInterval(timer);
  }, [product]);

  if (!product) {
    return <div className="min-h-screen flex items-center justify-center">Produto não encontrado</div>;
  }

  const relatedProducts = products.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4);

  const handleAddToCart = () => {
    addToCart(product, quantity);
    toast({ title: 'Sucesso!', description: `${quantity}x ${product.name} adicionado ao carrinho.` });
  };

  const formatTime = (seconds) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const schema = {
    "@context": "https://schema.org/",
    "@type": "Product",
    "name": product.name,
    "image": product.image,
    "description": product.description,
    "sku": product.id,
    "offers": {
      "@type": "Offer",
      "url": window.location.href,
      "priceCurrency": "BRL",
      "price": product.discountPrice,
      "availability": product.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
      "itemCondition": "https://schema.org/NewCondition"
    },
    "aggregateRating": {
      "@type": "AggregateRating",
      "ratingValue": product.rating,
      "reviewCount": product.reviews
    }
  };

  const breadcrumbItems = [
    { label: 'Categorias', path: '/categorias' },
    { label: product.category, path: `/categorias/${product.category}` },
    { label: product.name, path: `/produto/${product.id}` }
  ];

  return (
    <>
      <Helmet>
        <title>{product.name} | Stargrowth - Loja Online Premium</title>
        <meta name="description" content={product.description} />
        <script type="application/ld+json">{JSON.stringify(schema)}</script>
      </Helmet>

      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <Breadcrumb items={breadcrumbItems} />

          <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-12 border border-gray-100">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 p-8">
              {/* Image */}
              <motion.div initial={{ opacity: 0, x: -30 }} animate={{ opacity: 1, x: 0 }} className="relative aspect-square rounded-xl overflow-hidden group">
                <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                {product.discount > 0 && (
                  <div className="absolute top-4 right-4 bg-gradient-to-r from-red-600 to-red-500 text-white px-4 py-2 rounded-full text-lg font-bold shadow-lg animate-pulse">
                    -{product.discount}% OFF
                  </div>
                )}
                {product.stock < 5 && (
                   <div className="absolute top-4 left-4 bg-red-600 text-white px-4 py-2 rounded-full font-bold shadow-lg flex items-center gap-2 animate-pulse">
                      <Clock size={18} /> Restam {product.stock} unidades
                   </div>
                )}
              </motion.div>

              {/* Info */}
              <motion.div initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} className="flex flex-col">
                <div className="flex justify-between items-start mb-2">
                   <span className="bg-[#003366]/10 text-[#003366] text-xs font-bold px-2 py-1 rounded-full uppercase tracking-wider">{product.category}</span>
                   <div className="flex items-center gap-2 text-red-600 font-bold text-sm bg-red-50 px-3 py-1 rounded-lg border border-red-100">
                      <Clock size={14} /> Oferta acaba em {formatTime(timeLeft)}
                   </div>
                </div>

                <h1 className="text-3xl md:text-4xl font-montserrat font-bold text-[#003366] mb-4 leading-tight">{product.name}</h1>

                <div className="flex flex-wrap items-center gap-4 mb-6 text-sm">
                  <div className="flex items-center gap-1 text-yellow-400">
                    {[...Array(5)].map((_, i) => <Star key={i} className={`w-5 h-5 ${i < Math.floor(product.rating) ? 'fill-current' : 'text-gray-300'}`} />)}
                    <span className="text-gray-600 font-bold ml-1">{product.rating}</span>
                  </div>
                  <span className="text-gray-400">|</span>
                  <span className="text-[#003366] font-semibold flex items-center gap-1">
                     <Eye size={16} /> {viewers} pessoas vendo agora
                  </span>
                </div>

                <div className="mb-6 p-6 bg-gradient-to-br from-gray-50 to-white rounded-xl border border-gray-100 shadow-inner">
                  <div className="flex items-end gap-3 mb-2">
                    <p className="text-5xl font-bold text-[#003366]">R$ {product.discountPrice.toFixed(2)}</p>
                    {product.originalPrice > product.discountPrice && (
                       <p className="text-lg text-gray-400 line-through mb-2">R$ {product.originalPrice.toFixed(2)}</p>
                    )}
                  </div>
                  <p className="text-green-600 text-sm font-bold flex items-center gap-1">
                    <CheckCircle size={14} /> Economize R$ {(product.originalPrice - product.discountPrice).toFixed(2)}
                  </p>
                  
                  {product.discountPrice > 100 && (
                     <div className="mt-4 bg-green-100 text-green-800 px-4 py-2 rounded-lg font-bold text-sm flex items-center gap-2 border border-green-200">
                        <Truck size={18} /> Frete Grátis disponível para este produto
                     </div>
                  )}
                </div>

                <p className="text-gray-700 font-poppins leading-relaxed mb-8">{product.description}</p>

                <div className="flex flex-col sm:flex-row gap-4 mb-8">
                  <div className="flex items-center gap-4 bg-gray-100 rounded-lg px-4 py-2 w-fit">
                    <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="p-1 hover:text-[#003366]"><Minus className="w-5 h-5" /></button>
                    <span className="text-xl font-bold w-8 text-center">{quantity}</span>
                    <button onClick={() => setQuantity(quantity + 1)} className="p-1 hover:text-[#003366]"><Plus className="w-5 h-5" /></button>
                  </div>
                  
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={handleAddToCart}
                    className="flex-1 bg-gradient-to-r from-[#003366] to-[#004d99] text-white font-montserrat font-bold text-lg py-4 px-8 rounded-xl shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
                  >
                    <ShoppingCart className="w-6 h-6" /> Comprar Agora
                  </motion.button>
                </div>
                
                <div className="flex gap-4 mb-8">
                   <a href="https://instagram.com" target="_blank" className="flex items-center gap-2 text-purple-600 font-bold hover:underline">
                      <Instagram size={18} /> Seguir no Instagram
                   </a>
                </div>

                <div className="bg-blue-50 border border-blue-100 rounded-xl p-6">
                   <h3 className="font-bold text-[#003366] flex items-center gap-2 mb-2">
                      <ShieldCheck className="text-[#D4AF37]" /> Garantia de Satisfação
                   </h3>
                   <p className="text-sm text-gray-600">
                      Não amou? Devolva em até 30 dias e receba seu dinheiro de volta. Sem perguntas, sem complicações.
                   </p>
                </div>
              </motion.div>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100 mb-12">
             <h2 className="text-2xl font-montserrat font-bold text-[#003366] mb-6">Avaliações de Clientes</h2>
             <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
               <div className="lg:col-span-1">
                 <RatingDistribution reviews={reviews} />
                 <ReviewForm productId={product.id} onReviewSubmit={(r) => { setReviews([r, ...reviews]); }} />
               </div>
               <div className="lg:col-span-2">
                 <ReviewList reviews={reviews} />
               </div>
             </div>
          </div>

          {relatedProducts.length > 0 && (
            <section>
              <h2 className="text-2xl md:text-3xl font-montserrat font-bold text-[#003366] mb-6">Você também pode gostar</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {relatedProducts.map(p => <ProductCard key={p.id} product={p} />)}
              </div>
            </section>
          )}
        </div>
      </div>
    </>
  );
};

export default ProductDetails;
