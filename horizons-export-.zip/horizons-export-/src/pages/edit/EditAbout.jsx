
import React, { useState } from 'react';
import { useEditableContent } from '@/context/EditableContentContext';
import TextInput from '@/components/edit/TextInput';
import TextArea from '@/components/edit/TextArea';
import ImageUpload from '@/components/edit/ImageUpload';
import TagInput from '@/components/edit/TagInput';
import DragDropList from '@/components/edit/DragDropList';
import { Save, Plus } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const EditAbout = () => {
  const { about, updateContent } = useEditableContent();
  const { toast } = useToast();
  const [formData, setFormData] = useState(about);
  const [isTeamModalOpen, setIsTeamModalOpen] = useState(false);
  const [editingTeamMember, setEditingTeamMember] = useState(null);

  const handleSave = () => {
    updateContent('about', formData);
    toast({ title: 'Página Sobre atualizada!' });
  };

  const updateFounder = (field, value) => {
    setFormData(prev => ({ ...prev, founder: { ...prev.founder, [field]: value } }));
  };

  // Team handling
  const handleTeamSave = (member) => {
    let updatedTeam;
    if (editingTeamMember) {
      updatedTeam = formData.team.map(m => m.id === member.id ? member : m);
    } else {
      updatedTeam = [...formData.team, { ...member, id: Date.now() }];
    }
    setFormData(prev => ({ ...prev, team: updatedTeam }));
    setIsTeamModalOpen(false);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-[#003366]">Editar Página "Quem Somos"</h2>
        <button onClick={handleSave} className="bg-[#003366] text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2">
          <Save size={18} /> Salvar Alterações
        </button>
      </div>

      <Tabs defaultValue="founder">
        <TabsList>
          <TabsTrigger value="founder">Fundador</TabsTrigger>
          <TabsTrigger value="team">Equipe</TabsTrigger>
          <TabsTrigger value="mission">Missão & Valores</TabsTrigger>
        </TabsList>

        <TabsContent value="founder" className="bg-white p-6 rounded-xl border mt-4">
          <h3 className="font-bold text-lg mb-4">Perfil do Fundador</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <TextInput label="Nome" value={formData.founder.name} onChange={v => updateFounder('name', v)} />
              <TextInput label="Cargo" value={formData.founder.title} onChange={v => updateFounder('title', v)} />
              <TextInput label="Anos de Experiência" value={formData.founder.experience} onChange={v => updateFounder('experience', v)} />
              <TextArea label="Biografia" value={formData.founder.bio} onChange={v => updateFounder('bio', v)} />
            </div>
            <div>
              <ImageUpload label="Foto" value={formData.founder.photo} onChange={v => updateFounder('photo', v)} />
              <TagInput label="Especialidades" value={formData.founder.specialties} onChange={v => updateFounder('specialties', v)} />
            </div>
          </div>
        </TabsContent>

        <TabsContent value="team" className="mt-4">
           <div className="flex justify-between mb-4">
             <h3 className="font-bold text-lg">Membros da Equipe</h3>
             <button 
               onClick={() => { setEditingTeamMember(null); setIsTeamModalOpen(true); }}
               className="bg-[#D4AF37] text-[#003366] px-3 py-1 rounded font-bold text-sm flex items-center gap-1"
             >
               <Plus size={16} /> Adicionar
             </button>
           </div>
           
           <DragDropList 
             items={formData.team}
             onReorder={newOrder => setFormData(prev => ({ ...prev, team: newOrder }))}
             onEdit={member => { setEditingTeamMember(member); setIsTeamModalOpen(true); }}
             onDelete={member => setFormData(prev => ({ ...prev, team: prev.team.filter(m => m.id !== member.id) }))}
             renderItem={member => (
               <div className="flex items-center gap-3">
                 <img src={member.photo} alt="" className="w-10 h-10 rounded-full object-cover" />
                 <div>
                   <p className="font-bold">{member.name}</p>
                   <p className="text-xs text-gray-500">{member.position}</p>
                 </div>
               </div>
             )}
           />
        </TabsContent>

        <TabsContent value="mission" className="bg-white p-6 rounded-xl border mt-4">
          <TextArea label="Missão" value={formData.mission} onChange={v => setFormData(prev => ({ ...prev, mission: v }))} />
          <TextArea label="Visão" value={formData.vision} onChange={v => setFormData(prev => ({ ...prev, vision: v }))} />
          
          <h4 className="font-bold mt-4 mb-2">Valores</h4>
          {formData.values.map((val, idx) => (
            <div key={idx} className="flex gap-2 mb-2">
              <input 
                className="border p-2 rounded flex-1" 
                value={val.title} 
                onChange={e => {
                  const newValues = [...formData.values];
                  newValues[idx].title = e.target.value;
                  setFormData(prev => ({ ...prev, values: newValues }));
                }} 
              />
              <input 
                className="border p-2 rounded flex-[2]" 
                value={val.desc} 
                onChange={e => {
                  const newValues = [...formData.values];
                  newValues[idx].desc = e.target.value;
                  setFormData(prev => ({ ...prev, values: newValues }));
                }} 
              />
            </div>
          ))}
        </TabsContent>
      </Tabs>
      
      {isTeamModalOpen && (
        <TeamMemberModal 
          member={editingTeamMember} 
          onSave={handleTeamSave} 
          onClose={() => setIsTeamModalOpen(false)} 
        />
      )}
    </div>
  );
};

const TeamMemberModal = ({ member, onSave, onClose }) => {
  const [data, setData] = useState(member || { name: '', position: '', description: '', photo: '' });
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl w-full max-w-md p-6">
        <h3 className="font-bold text-lg mb-4">{member ? 'Editar' : 'Novo'} Membro</h3>
        <TextInput label="Nome" value={data.name} onChange={v => setData({...data, name: v})} />
        <TextInput label="Cargo" value={data.position} onChange={v => setData({...data, position: v})} />
        <TextArea label="Descrição" value={data.description} onChange={v => setData({...data, description: v})} />
        <ImageUpload label="Foto" value={data.photo} onChange={v => setData({...data, photo: v})} />
        <div className="flex gap-2 mt-4">
          <button onClick={onClose} className="flex-1 border p-2 rounded">Cancelar</button>
          <button onClick={() => onSave(data)} className="flex-1 bg-[#003366] text-white p-2 rounded">Salvar</button>
        </div>
      </div>
    </div>
  );
};

export default EditAbout;
