
import React, { useState } from 'react';
import { useEditableContent } from '@/context/EditableContentContext';
import TextInput from '@/components/edit/TextInput';
import { Plus, Trash2, Edit, Save, X } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const EditCategories = () => {
  const { categories, updateContent } = useEditableContent();
  const { toast } = useToast();
  const [editingIndex, setEditingIndex] = useState(null);
  const [formData, setFormData] = useState({ name: '', icon: 'ShoppingBag', desc: '', color: 'from-blue-500 to-blue-600' });
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleOpenModal = (index = null) => {
    if (index !== null) {
      setEditingIndex(index);
      setFormData(categories[index]);
    } else {
      setEditingIndex(null);
      setFormData({ name: '', icon: 'ShoppingBag', desc: '', color: 'from-blue-500 to-blue-600' });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    let updated;
    if (editingIndex !== null) {
      updated = categories.map((c, i) => i === editingIndex ? formData : c);
    } else {
      updated = [...categories, formData];
    }
    updateContent('categories', updated);
    setIsModalOpen(false);
    toast({ title: 'Categorias atualizadas!' });
  };

  const handleDelete = (index) => {
    if (window.confirm('Excluir esta categoria?')) {
      const updated = categories.filter((_, i) => i !== index);
      updateContent('categories', updated);
      toast({ title: 'Categoria removida.' });
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-[#003366]">Editar Categorias</h2>
        <button onClick={() => handleOpenModal()} className="bg-[#D4AF37] text-[#003366] px-4 py-2 rounded-lg font-bold flex items-center gap-2">
          <Plus size={18} /> Nova Categoria
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {categories.map((cat, index) => (
          <div key={index} className="bg-white p-4 border rounded-lg shadow-sm flex justify-between items-center">
            <div className="flex items-center gap-4">
               <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${cat.color}`} />
               <div>
                  <h4 className="font-bold">{cat.name}</h4>
                  <p className="text-sm text-gray-500">{cat.desc}</p>
               </div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => handleOpenModal(index)} className="p-2 text-blue-600 hover:bg-blue-50 rounded"><Edit size={18} /></button>
              <button onClick={() => handleDelete(index)} className="p-2 text-red-600 hover:bg-red-50 rounded"><Trash2 size={18} /></button>
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl w-full max-w-md p-6">
             <div className="flex justify-between mb-4">
                <h3 className="text-xl font-bold">Categoria</h3>
                <button onClick={() => setIsModalOpen(false)}><X /></button>
             </div>
             <TextInput label="Nome" value={formData.name} onChange={v => setFormData({...formData, name: v})} />
             <TextInput label="Descrição Curta" value={formData.desc} onChange={v => setFormData({...formData, desc: v})} />
             <div className="mb-4">
                <label className="block text-sm font-bold mb-1">Ícone (Lucide Name)</label>
                <select 
                  value={formData.icon} 
                  onChange={e => setFormData({...formData, icon: e.target.value})}
                  className="w-full border p-2 rounded"
                >
                   <option value="ShoppingBag">ShoppingBag</option>
                   <option value="Smartphone">Smartphone</option>
                   <option value="Watch">Watch</option>
                   <option value="Baby">Baby</option>
                   <option value="Sparkles">Sparkles</option>
                   <option value="BookOpen">BookOpen</option>
                   <option value="Zap">Zap</option>
                </select>
             </div>
             <TextInput label="Classes de Cor (Tailwind Gradient)" value={formData.color} onChange={v => setFormData({...formData, color: v})} placeholder="from-blue-500 to-blue-600" />
             
             <button onClick={handleSave} className="w-full bg-[#003366] text-white py-2 rounded-lg font-bold mt-4">Salvar</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default EditCategories;
