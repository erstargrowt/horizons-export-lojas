
import React, { useState } from 'react';
import { useEditableContent } from '@/context/EditableContentContext';
import TextInput from '@/components/edit/TextInput';
import TextArea from '@/components/edit/TextArea';
import IconPicker from '@/components/edit/IconPicker';
import ColorPicker from '@/components/edit/ColorPicker';
import DragDropList from '@/components/edit/DragDropList';
import * as Icons from 'lucide-react';
import { Plus, Save, X } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const EditBenefits = () => {
  const { benefits, updateContent } = useEditableContent();
  const { toast } = useToast();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [formData, setFormData] = useState({ id: '', title: '', description: '', icon: 'Truck', color: 'from-blue-500 to-blue-600' });

  const handleOpenModal = (item = null) => {
    if (item) {
      setEditingItem(item);
      setFormData(item);
    } else {
      setEditingItem(null);
      setFormData({ id: Date.now().toString(), title: '', description: '', icon: 'Truck', color: 'from-blue-500 to-blue-600' });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    let updated;
    if (editingItem) {
      updated = benefits.map(b => b.id === editingItem.id ? formData : b);
    } else {
      updated = [...benefits, formData];
    }
    updateContent('benefits', updated);
    setIsModalOpen(false);
    toast({ title: 'Benefícios atualizados!' });
  };

  const handleDelete = (item) => {
    if (window.confirm('Excluir este benefício?')) {
      const updated = benefits.filter(b => b.id !== item.id);
      updateContent('benefits', updated);
      toast({ title: 'Benefício removido.' });
    }
  };

  const handleReorder = (newOrder) => {
    updateContent('benefits', newOrder);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-[#003366]">Editar Benefícios</h2>
        <button onClick={() => handleOpenModal()} className="bg-[#D4AF37] text-[#003366] px-4 py-2 rounded-lg font-bold flex items-center gap-2">
          <Plus size={18} /> Novo Benefício
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div>
           <h3 className="text-lg font-bold mb-4 text-gray-700">Lista de Benefícios (Arraste para reordenar)</h3>
           <DragDropList 
             items={benefits} 
             onReorder={handleReorder}
             onEdit={handleOpenModal}
             onDelete={handleDelete}
             renderItem={(item) => {
               const Icon = Icons[item.icon] || Icons.HelpCircle;
               return (
                 <div className="flex items-center gap-3">
                   <div className="p-2 bg-gray-100 rounded">
                     <Icon size={20} className="text-[#003366]" />
                   </div>
                   <div>
                     <p className="font-bold text-gray-800">{item.title}</p>
                     <p className="text-xs text-gray-500 truncate max-w-xs">{item.description}</p>
                   </div>
                 </div>
               );
             }}
           />
        </div>

        <div>
           <h3 className="text-lg font-bold mb-4 text-gray-700">Pré-visualização</h3>
           <div className="bg-gray-50 p-6 rounded-xl border border-dashed border-gray-300">
              <div className="grid grid-cols-1 gap-4">
                 {benefits.map(benefit => {
                   const Icon = Icons[benefit.icon] || Icons.HelpCircle;
                   return (
                     <div key={benefit.id} className="bg-white p-4 rounded-xl shadow-sm border flex items-center gap-4">
                        <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${benefit.color} flex items-center justify-center text-white shrink-0`}>
                           <Icon size={24} />
                        </div>
                        <div>
                           <h4 className="font-bold text-[#003366]">{benefit.title}</h4>
                           <p className="text-xs text-gray-600">{benefit.description}</p>
                        </div>
                     </div>
                   );
                 })}
              </div>
           </div>
        </div>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto">
             <div className="flex justify-between mb-4">
                <h3 className="text-xl font-bold">Gerenciar Benefício</h3>
                <button onClick={() => setIsModalOpen(false)}><X /></button>
             </div>
             <TextInput label="Título" value={formData.title} onChange={v => setFormData({...formData, title: v})} />
             <TextArea label="Descrição" value={formData.description} onChange={v => setFormData({...formData, description: v})} />
             <IconPicker label="Ícone" value={formData.icon} onChange={v => setFormData({...formData, icon: v})} />
             <TextInput label="Cor (Classes Tailwind Gradient)" value={formData.color} onChange={v => setFormData({...formData, color: v})} placeholder="from-blue-500 to-blue-600" />
             
             <button onClick={handleSave} className="w-full bg-[#003366] text-white py-3 rounded-lg font-bold mt-4">Salvar Benefício</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default EditBenefits;
