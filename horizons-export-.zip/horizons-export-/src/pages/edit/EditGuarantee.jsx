
import React, { useState } from 'react';
import { useEditableContent } from '@/context/EditableContentContext';
import TextInput from '@/components/edit/TextInput';
import TextArea from '@/components/edit/TextArea';
import ImageUpload from '@/components/edit/ImageUpload';
import TagInput from '@/components/edit/TagInput';
import IconPicker from '@/components/edit/IconPicker';
import { Save } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const EditGuarantee = () => {
  const { guarantee, updateContent } = useEditableContent();
  const { toast } = useToast();
  const [formData, setFormData] = useState(guarantee);

  const handleSave = () => {
    updateContent('guarantee', formData);
    toast({ title: 'Seção de Garantia atualizada!' });
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-[#003366]">Editar Seção de Garantia</h2>
        <button onClick={handleSave} className="bg-[#003366] text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2">
          <Save size={18} /> Salvar Alterações
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
           <div className="bg-white p-6 rounded-xl border">
              <h3 className="font-bold text-lg mb-4">Conteúdo Principal</h3>
              <TextInput label="Título" value={formData.headline} onChange={v => setFormData({...formData, headline: v})} />
              <TextArea label="Descrição" value={formData.description} onChange={v => setFormData({...formData, description: v})} />
              <IconPicker label="Ícone Principal" value={formData.image} onChange={v => setFormData({...formData, image: v})} />
           </div>

           <div className="bg-white p-6 rounded-xl border">
              <h3 className="font-bold text-lg mb-4">Pontos de Destaque</h3>
              <TagInput 
                label="Lista de Benefícios (Pontos)" 
                value={formData.points || []} 
                onChange={v => setFormData({...formData, points: v})} 
                placeholder="Ex: Devolução Fácil"
              />
           </div>
        </div>

        <div>
           <h3 className="font-bold text-lg mb-4 text-gray-700">Pré-visualização Simplificada</h3>
           <div className="bg-[#003366] p-8 rounded-xl text-white text-center">
              <div className="inline-block p-4 bg-white/10 rounded-full mb-4 text-[#D4AF37] border border-[#D4AF37]">
                 Icon: {formData.image}
              </div>
              <h2 className="text-2xl font-bold mb-4">{formData.headline}</h2>
              <p className="text-gray-200 mb-6">{formData.description}</p>
              <ul className="text-left bg-black/20 p-4 rounded-lg space-y-2">
                 {(formData.points || []).map((point, i) => (
                    <li key={i} className="flex items-center gap-2">
                       <span className="text-[#D4AF37]">✓</span> {point}
                    </li>
                 ))}
              </ul>
           </div>
        </div>
      </div>
    </div>
  );
};

export default EditGuarantee;
