
import React, { useState } from 'react';
import { useEditableContent } from '@/context/EditableContentContext';
import TextInput from '@/components/edit/TextInput';
import IconPicker from '@/components/edit/IconPicker';
import ColorPicker from '@/components/edit/ColorPicker';
import { Save, Plus, X, Trash2, Edit } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import * as Icons from 'lucide-react';

const EditCertifications = () => {
  const { certifications, updateContent } = useEditableContent();
  const { toast } = useToast();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [formData, setFormData] = useState({ id: '', label: '', desc: '', icon: 'Shield', color: '#003366' });

  const handleOpenModal = (item = null) => {
    if (item) {
      setEditingItem(item);
      setFormData(item);
    } else {
      setEditingItem(null);
      setFormData({ id: Date.now(), label: '', desc: '', icon: 'Shield', color: '#003366' });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    let updated;
    if (editingItem) {
      updated = certifications.map(c => c.id === editingItem.id ? formData : c);
    } else {
      updated = [...certifications, formData];
    }
    updateContent('certifications', updated);
    setIsModalOpen(false);
    toast({ title: 'Certificações atualizadas!' });
  };

  const handleDelete = (id) => {
    if (window.confirm('Remover?')) {
      updateContent('certifications', certifications.filter(c => c.id !== id));
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-[#003366]">Editar Certificações</h2>
        <button onClick={() => handleOpenModal()} className="bg-[#D4AF37] text-[#003366] px-4 py-2 rounded-lg font-bold flex items-center gap-2">
          <Plus size={18} /> Adicionar
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {certifications.map(cert => {
           const Icon = Icons[cert.icon] || Icons.HelpCircle;
           return (
             <div key={cert.id} className="bg-white p-4 border rounded-lg flex items-center justify-between">
                <div className="flex items-center gap-4">
                   <div className="p-2 bg-gray-100 rounded text-[#003366]">
                      <Icon size={24} />
                   </div>
                   <div>
                      <h4 className="font-bold">{cert.label}</h4>
                      <p className="text-sm text-gray-500">{cert.desc}</p>
                   </div>
                </div>
                <div className="flex gap-2">
                   <button onClick={() => handleOpenModal(cert)} className="p-2 hover:bg-gray-100 rounded text-blue-600"><Edit size={16} /></button>
                   <button onClick={() => handleDelete(cert.id)} className="p-2 hover:bg-gray-100 rounded text-red-600"><Trash2 size={16} /></button>
                </div>
             </div>
           );
        })}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
           <div className="bg-white rounded-xl w-full max-w-md p-6">
              <div className="flex justify-between mb-4">
                 <h3 className="font-bold text-lg">Certificação</h3>
                 <button onClick={() => setIsModalOpen(false)}><X /></button>
              </div>
              <TextInput label="Título (Label)" value={formData.label} onChange={v => setFormData({...formData, label: v})} />
              <TextInput label="Descrição Curta" value={formData.desc} onChange={v => setFormData({...formData, desc: v})} />
              <IconPicker label="Ícone" value={formData.icon} onChange={v => setFormData({...formData, icon: v})} />
              <button onClick={handleSave} className="w-full bg-[#003366] text-white py-2 rounded font-bold mt-4">Salvar</button>
           </div>
        </div>
      )}
    </div>
  );
};

export default EditCertifications;
