
import React, { useState } from 'react';
import { useEditableContent } from '@/context/EditableContentContext';
import TextInput from '@/components/edit/TextInput';
import TextArea from '@/components/edit/TextArea';
import ImageUpload from '@/components/edit/ImageUpload';
import { Plus, Edit, Trash2, X, Star, CheckCircle2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const EditTestimonials = () => {
  const { testimonials, updateContent } = useEditableContent();
  const { toast } = useToast();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [formData, setFormData] = useState({ id: '', name: '', location: '', text: '', rating: 5, image: '', verified: true });

  const handleOpenModal = (item = null) => {
    if (item) {
      setEditingItem(item);
      setFormData(item);
    } else {
      setEditingItem(null);
      setFormData({ id: Date.now(), name: '', location: '', text: '', rating: 5, image: '', verified: true });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    let updated;
    if (editingItem) {
      updated = testimonials.map(t => t.id === editingItem.id ? formData : t);
    } else {
      updated = [...testimonials, formData];
    }
    updateContent('testimonials', updated);
    setIsModalOpen(false);
    toast({ title: 'Depoimentos atualizados!' });
  };

  const handleDelete = (id) => {
    if (window.confirm('Excluir este depoimento?')) {
      const updated = testimonials.filter(t => t.id !== id);
      updateContent('testimonials', updated);
      toast({ title: 'Depoimento removido.' });
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-[#003366]">Editar Depoimentos</h2>
        <button onClick={() => handleOpenModal()} className="bg-[#D4AF37] text-[#003366] px-4 py-2 rounded-lg font-bold flex items-center gap-2">
          <Plus size={18} /> Novo Depoimento
        </button>
      </div>

      <div className="grid grid-cols-1 gap-6 mb-8">
        {testimonials.map((t) => (
          <div key={t.id} className="bg-white p-6 rounded-xl shadow-sm border flex flex-col md:flex-row gap-6 items-start">
             <img src={t.image} alt={t.name} className="w-16 h-16 rounded-full object-cover" />
             <div className="flex-1">
                <div className="flex justify-between items-start">
                   <div>
                      <h4 className="font-bold text-[#003366]">{t.name}</h4>
                      <p className="text-sm text-gray-500">{t.location}</p>
                   </div>
                   <div className="flex gap-2">
                      <button onClick={() => handleOpenModal(t)} className="p-2 text-blue-600 hover:bg-blue-50 rounded"><Edit size={18} /></button>
                      <button onClick={() => handleDelete(t.id)} className="p-2 text-red-600 hover:bg-red-50 rounded"><Trash2 size={18} /></button>
                   </div>
                </div>
                <div className="flex items-center gap-1 text-yellow-400 my-2">
                   {[...Array(5)].map((_, i) => (
                      <Star key={i} size={14} fill={i < t.rating ? "currentColor" : "none"} className={i < t.rating ? "" : "text-gray-300"} />
                   ))}
                </div>
                <p className="text-gray-600 italic">"{t.text}"</p>
                {t.verified && (
                   <div className="flex items-center gap-1 text-[10px] text-green-600 font-bold bg-green-50 w-fit px-2 py-0.5 rounded-full mt-2">
                      <CheckCircle2 size={10} /> Comprador Verificado
                   </div>
                )}
             </div>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl w-full max-w-lg p-6 max-h-[90vh] overflow-y-auto">
             <div className="flex justify-between mb-4">
                <h3 className="text-xl font-bold">Depoimento</h3>
                <button onClick={() => setIsModalOpen(false)}><X /></button>
             </div>
             <TextInput label="Nome do Cliente" value={formData.name} onChange={v => setFormData({...formData, name: v})} />
             <TextInput label="Localização/Profissão" value={formData.location} onChange={v => setFormData({...formData, location: v})} />
             <TextArea label="Depoimento" value={formData.text} onChange={v => setFormData({...formData, text: v})} />
             <div className="mb-4">
                <label className="block text-sm font-bold mb-1">Avaliação (Estrelas)</label>
                <select 
                   value={formData.rating} 
                   onChange={e => setFormData({...formData, rating: Number(e.target.value)})}
                   className="w-full border p-2 rounded"
                >
                   <option value="1">1 Estrela</option>
                   <option value="2">2 Estrelas</option>
                   <option value="3">3 Estrelas</option>
                   <option value="4">4 Estrelas</option>
                   <option value="5">5 Estrelas</option>
                </select>
             </div>
             <ImageUpload label="Foto do Cliente" value={formData.image} onChange={v => setFormData({...formData, image: v})} />
             <div className="flex items-center gap-2 mb-4">
                <input type="checkbox" checked={formData.verified} onChange={e => setFormData({...formData, verified: e.target.checked})} id="verified" />
                <label htmlFor="verified" className="text-sm font-medium">Comprador Verificado</label>
             </div>
             
             <button onClick={handleSave} className="w-full bg-[#003366] text-white py-3 rounded-lg font-bold mt-4">Salvar</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default EditTestimonials;
