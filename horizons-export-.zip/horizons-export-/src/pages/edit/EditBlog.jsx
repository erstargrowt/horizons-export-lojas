
import React, { useState } from 'react';
import { useEditableContent } from '@/context/EditableContentContext';
import TextInput from '@/components/edit/TextInput';
import RichTextEditor from '@/components/edit/RichTextEditor';
import ImageUpload from '@/components/edit/ImageUpload';
import DatePicker from '@/components/edit/DatePicker';
import { Plus, Edit, Trash2, X, Eye } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Link } from 'react-router-dom';

const EditBlog = () => {
  const { blogPosts, updateContent } = useEditableContent();
  const { toast } = useToast();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [formData, setFormData] = useState({ 
    id: '', title: '', slug: '', category: 'Dicas', 
    date: '', readTime: '5 min', image: '', content: '', author: 'Equipe Stargrowth' 
  });

  const handleOpenModal = (item = null) => {
    if (item) {
      setEditingItem(item);
      setFormData(item);
    } else {
      setEditingItem(null);
      setFormData({ 
        id: Date.now(), title: '', slug: '', category: 'Dicas', 
        date: new Date().toISOString(), readTime: '5 min', image: '', content: '', author: 'Equipe Stargrowth' 
      });
    }
    setIsModalOpen(true);
  };

  const handleTitleChange = (val) => {
    setFormData({ 
      ...formData, 
      title: val,
      slug: !editingItem ? val.toLowerCase().replace(/ /g, '-').replace(/[^\w-]+/g, '') : formData.slug 
    });
  };

  const handleSave = () => {
    let updated;
    if (editingItem) {
      updated = blogPosts.map(p => p.id === editingItem.id ? formData : p);
    } else {
      updated = [...blogPosts, formData];
    }
    updateContent('blogPosts', updated);
    setIsModalOpen(false);
    toast({ title: 'Artigo salvo com sucesso!' });
  };

  const handleDelete = (id) => {
    if (window.confirm('Excluir este artigo?')) {
      const updated = blogPosts.filter(p => p.id !== id);
      updateContent('blogPosts', updated);
      toast({ title: 'Artigo removido.' });
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-[#003366]">Gerenciar Blog</h2>
        <button onClick={() => handleOpenModal()} className="bg-[#D4AF37] text-[#003366] px-4 py-2 rounded-lg font-bold flex items-center gap-2">
          <Plus size={18} /> Novo Artigo
        </button>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden shadow-sm">
        <table className="w-full text-left">
          <thead className="bg-gray-50 border-b">
            <tr>
              <th className="p-4 font-bold text-gray-600">Título</th>
              <th className="p-4 font-bold text-gray-600">Categoria</th>
              <th className="p-4 font-bold text-gray-600">Data</th>
              <th className="p-4 font-bold text-gray-600 text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {blogPosts.map(post => (
              <tr key={post.id} className="border-b hover:bg-gray-50">
                <td className="p-4 font-medium">{post.title}</td>
                <td className="p-4"><span className="bg-gray-100 px-2 py-1 rounded text-xs font-bold text-gray-600">{post.category}</span></td>
                <td className="p-4 text-sm text-gray-500">{new Date(post.date).toLocaleDateString()}</td>
                <td className="p-4 text-right flex justify-end gap-2">
                  <Link to={`/blog/${post.slug}`} target="_blank" className="p-2 text-gray-500 hover:bg-gray-100 rounded" title="Ver no site"><Eye size={18} /></Link>
                  <button onClick={() => handleOpenModal(post)} className="p-2 text-blue-600 hover:bg-blue-50 rounded"><Edit size={18} /></button>
                  <button onClick={() => handleDelete(post.id)} className="p-2 text-red-600 hover:bg-red-50 rounded"><Trash2 size={18} /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl w-full max-w-3xl p-6 max-h-[90vh] overflow-y-auto shadow-2xl">
             <div className="flex justify-between mb-4">
                <h3 className="text-xl font-bold">Editar Artigo</h3>
                <button onClick={() => setIsModalOpen(false)}><X /></button>
             </div>
             
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <TextInput label="Título" value={formData.title} onChange={handleTitleChange} />
                <TextInput label="Slug (URL)" value={formData.slug} onChange={v => setFormData({...formData, slug: v})} />
                
                <div className="mb-4">
                   <label className="block text-sm font-bold mb-1">Categoria</label>
                   <select 
                      value={formData.category} 
                      onChange={e => setFormData({...formData, category: e.target.value})}
                      className="w-full border p-2 rounded"
                   >
                      <option>Dicas</option>
                      <option>Tendências</option>
                      <option>Guias</option>
                      <option>Notícias</option>
                   </select>
                </div>
                <DatePicker label="Data de Publicação" value={formData.date} onChange={v => setFormData({...formData, date: v})} />
                <TextInput label="Tempo de Leitura" value={formData.readTime} onChange={v => setFormData({...formData, readTime: v})} />
                <TextInput label="Autor" value={formData.author} onChange={v => setFormData({...formData, author: v})} />
             </div>
             
             <ImageUpload label="Imagem de Capa" value={formData.image} onChange={v => setFormData({...formData, image: v})} />
             <RichTextEditor label="Conteúdo" value={formData.content} onChange={v => setFormData({...formData, content: v})} />
             
             <button onClick={handleSave} className="w-full bg-[#003366] text-white py-3 rounded-lg font-bold mt-4">Salvar Publicação</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default EditBlog;
