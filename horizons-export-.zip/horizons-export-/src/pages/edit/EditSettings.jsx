
import React, { useState } from 'react';
import { useEditableContent } from '@/context/EditableContentContext';
import TextInput from '@/components/edit/TextInput';
import TextArea from '@/components/edit/TextArea';
import ColorPicker from '@/components/edit/ColorPicker';
import { Save } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const EditSettings = () => {
  const { settings, updateContent } = useEditableContent();
  const { toast } = useToast();
  const [formData, setFormData] = useState(settings);

  const handleSave = () => {
    updateContent('settings', formData);
    toast({ title: 'Configurações salvas!' });
  };

  const updateSection = (section, field, value) => {
    setFormData(prev => ({
      ...prev,
      [section]: { ...prev[section], [field]: value }
    }));
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-[#003366]">Configurações Gerais</h2>
        <button onClick={handleSave} className="bg-[#003366] text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2">
          <Save size={18} /> Salvar Tudo
        </button>
      </div>

      <Tabs defaultValue="company" className="w-full">
        <TabsList className="mb-8 w-full justify-start overflow-x-auto">
          <TabsTrigger value="company">Empresa</TabsTrigger>
          <TabsTrigger value="design">Design</TabsTrigger>
          <TabsTrigger value="social">Redes Sociais</TabsTrigger>
          <TabsTrigger value="policies">Políticas</TabsTrigger>
          <TabsTrigger value="shipping">Frete</TabsTrigger>
        </TabsList>

        <TabsContent value="company" className="space-y-4">
          <div className="bg-white p-6 rounded-xl border">
            <h3 className="font-bold text-lg mb-4">Informações da Empresa</h3>
            <TextInput label="Nome da Empresa" value={formData.companyInfo.name} onChange={v => updateSection('companyInfo', 'name', v)} />
            <TextInput label="Email de Contato" value={formData.companyInfo.email} onChange={v => updateSection('companyInfo', 'email', v)} />
            <TextInput label="Telefone / WhatsApp" value={formData.companyInfo.phone} onChange={v => updateSection('companyInfo', 'phone', v)} />
            <TextArea label="Endereço Completo" value={formData.companyInfo.address} onChange={v => updateSection('companyInfo', 'address', v)} rows={2} />
            <TextInput label="Horário de Atendimento" value={formData.companyInfo.businessHours} onChange={v => updateSection('companyInfo', 'businessHours', v)} />
          </div>
        </TabsContent>

        <TabsContent value="design" className="space-y-4">
          <div className="bg-white p-6 rounded-xl border">
            <h3 className="font-bold text-lg mb-4">Cores Principais</h3>
            <ColorPicker label="Cor Primária (Deep Blue)" value={formData.colors.primary} onChange={v => updateSection('colors', 'primary', v)} />
            <ColorPicker label="Cor Secundária (Gold)" value={formData.colors.secondary} onChange={v => updateSection('colors', 'secondary', v)} />
            <ColorPicker label="Cor de Fundo" value={formData.colors.background} onChange={v => updateSection('colors', 'background', v)} />
            <ColorPicker label="Cor do Texto" value={formData.colors.text} onChange={v => updateSection('colors', 'text', v)} />
          </div>
        </TabsContent>

        <TabsContent value="social" className="space-y-4">
          <div className="bg-white p-6 rounded-xl border">
            <h3 className="font-bold text-lg mb-4">Links de Redes Sociais</h3>
            <TextInput label="Facebook" value={formData.social.facebook} onChange={v => updateSection('social', 'facebook', v)} />
            <TextInput label="Instagram" value={formData.social.instagram} onChange={v => updateSection('social', 'instagram', v)} />
            <TextInput label="Twitter" value={formData.social.twitter} onChange={v => updateSection('social', 'twitter', v)} />
            <TextInput label="LinkedIn" value={formData.social.linkedin} onChange={v => updateSection('social', 'linkedin', v)} />
            <TextInput label="YouTube" value={formData.social.youtube} onChange={v => updateSection('social', 'youtube', v)} />
          </div>
        </TabsContent>

        <TabsContent value="policies" className="space-y-4">
          <div className="bg-white p-6 rounded-xl border">
            <h3 className="font-bold text-lg mb-4">Textos Legais</h3>
            <TextArea label="Política de Privacidade" value={formData.policies.privacy} onChange={v => updateSection('policies', 'privacy', v)} />
            <TextArea label="Termos de Uso" value={formData.policies.terms} onChange={v => updateSection('policies', 'terms', v)} />
            <TextArea label="Política de Trocas" value={formData.policies.exchange} onChange={v => updateSection('policies', 'exchange', v)} />
            <TextArea label="Política de Entrega" value={formData.policies.delivery} onChange={v => updateSection('policies', 'delivery', v)} />
          </div>
        </TabsContent>

        <TabsContent value="shipping" className="space-y-4">
          <div className="bg-white p-6 rounded-xl border">
            <h3 className="font-bold text-lg mb-4">Configurações de Frete</h3>
            <TextInput label="Valor Mínimo para Frete Grátis (R$)" type="number" value={formData.shipping.freeShippingThreshold} onChange={v => updateSection('shipping', 'freeShippingThreshold', v)} />
            <TextInput label="Mensagem de Frete Grátis" value={formData.shipping.message} onChange={v => updateSection('shipping', 'message', v)} />
            <TextInput label="Valor Padrão de Frete (R$)" type="number" value={formData.shipping.standardRate} onChange={v => updateSection('shipping', 'standardRate', v)} />
            <TextInput label="Prazo Médio (dias)" type="number" value={formData.shipping.deliveryDays} onChange={v => updateSection('shipping', 'deliveryDays', v)} />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default EditSettings;
