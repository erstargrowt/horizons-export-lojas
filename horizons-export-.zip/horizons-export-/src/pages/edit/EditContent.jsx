
import React from 'react';
import { Navigate } from 'react-router-dom';

const EditContent = () => {
  return <Navigate to="/edit-content/hero" replace />;
};

export default EditContent;
