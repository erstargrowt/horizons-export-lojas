
import React, { useState } from 'react';
import { useEditableContent } from '@/context/EditableContentContext';
import TextInput from '@/components/edit/TextInput';
import IconPicker from '@/components/edit/IconPicker';
import DragDropList from '@/components/edit/DragDropList';
import { Plus, X } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import * as Icons from 'lucide-react';

const EditStores = () => {
  const { stores, updateContent } = useEditableContent();
  const { toast } = useToast();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [formData, setFormData] = useState({ id: '', name: '', description: '', category: '', icon: 'Store', color: '#D4AF37' });

  const handleOpenModal = (item = null) => {
    if (item) {
      setEditingItem(item);
      setFormData(item);
    } else {
      setEditingItem(null);
      setFormData({ id: Date.now(), name: '', description: '', category: '', icon: 'Store', color: '#D4AF37' });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    let updated;
    if (editingItem) {
      updated = stores.map(s => s.id === editingItem.id ? formData : s);
    } else {
      updated = [...stores, formData];
    }
    updateContent('stores', updated);
    setIsModalOpen(false);
    toast({ title: 'Lojas atualizadas!' });
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-[#003366]">Lojas Especializadas</h2>
        <button onClick={() => handleOpenModal()} className="bg-[#D4AF37] text-[#003366] px-4 py-2 rounded-lg font-bold flex items-center gap-2">
          <Plus size={18} /> Nova Loja
        </button>
      </div>

      <DragDropList
        items={stores}
        onReorder={newOrder => updateContent('stores', newOrder)}
        onEdit={handleOpenModal}
        onDelete={item => updateContent('stores', stores.filter(s => s.id !== item.id))}
        renderItem={store => {
           const Icon = Icons[store.icon] || Icons.Store;
           return (
             <div className="flex items-center gap-4">
               <div className="p-2 bg-gray-100 rounded">
                 <Icon size={20} className="text-[#003366]" />
               </div>
               <div>
                 <h4 className="font-bold">{store.name}</h4>
                 <p className="text-xs text-gray-500">{store.description}</p>
               </div>
             </div>
           );
        }}
      />

      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
           <div className="bg-white rounded-xl w-full max-w-md p-6">
              <div className="flex justify-between mb-4">
                 <h3 className="font-bold text-lg">Loja</h3>
                 <button onClick={() => setIsModalOpen(false)}><X /></button>
              </div>
              <TextInput label="Nome da Loja" value={formData.name} onChange={v => setFormData({...formData, name: v})} />
              <TextInput label="Descrição" value={formData.description} onChange={v => setFormData({...formData, description: v})} />
              <TextInput label="Categoria (Link)" value={formData.category} onChange={v => setFormData({...formData, category: v})} />
              <IconPicker label="Ícone" value={formData.icon} onChange={v => setFormData({...formData, icon: v})} />
              <button onClick={handleSave} className="w-full bg-[#003366] text-white py-2 rounded font-bold mt-4">Salvar</button>
           </div>
        </div>
      )}
    </div>
  );
};

export default EditStores;
