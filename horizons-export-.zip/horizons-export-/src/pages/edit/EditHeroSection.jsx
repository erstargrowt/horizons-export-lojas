
import React, { useState, useEffect } from 'react';
import { useEditableContent } from '@/context/EditableContentContext';
import TextInput from '@/components/edit/TextInput';
import ImageUpload from '@/components/edit/ImageUpload';
import { useToast } from '@/components/ui/use-toast';
import { Save } from 'lucide-react';

const EditHeroSection = () => {
  const { hero, updateContent } = useEditableContent();
  const [formData, setFormData] = useState(hero);
  const { toast } = useToast();

  useEffect(() => {
    setFormData(hero);
  }, [hero]);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    updateContent('hero', formData);
    toast({ title: 'Hero section atualizado com sucesso!' });
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-[#003366]">Editar Hero Section</h2>
        <button
          onClick={handleSave}
          className="bg-[#003366] text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-[#004d99]"
        >
          <Save size={18} /> Salvar Alterações
        </button>
      </div>

      <div className="space-y-6">
        <TextInput
          label="Título Principal"
          value={formData.headline}
          onChange={(val) => handleChange('headline', val)}
          placeholder="Ex: Qualidade Premium..."
        />
        <TextInput
          label="Subtítulo"
          value={formData.subheadline}
          onChange={(val) => handleChange('subheadline', val)}
          placeholder="Ex: Frete Grátis..."
        />
        <TextInput
          label="Texto do Botão CTA"
          value={formData.ctaText}
          onChange={(val) => handleChange('ctaText', val)}
          placeholder="Ex: Comprar Agora"
        />
        <ImageUpload
          label="Imagem de Fundo"
          value={formData.backgroundImage}
          onChange={(val) => handleChange('backgroundImage', val)}
        />
        <div>
           <label className="block text-sm font-bold text-gray-700 mb-1">Cor de Fundo (Fallback)</label>
           <input 
              type="color" 
              value={formData.backgroundColor} 
              onChange={(e) => handleChange('backgroundColor', e.target.value)}
              className="h-10 w-20 rounded border border-gray-300"
           />
        </div>

        {/* Preview Area */}
        <div className="mt-8 border-t pt-8">
          <h3 className="text-lg font-bold mb-4 text-gray-500">Pré-visualização</h3>
          <div className="relative h-64 rounded-xl overflow-hidden flex items-center justify-center text-center text-white p-6">
             <div 
                className="absolute inset-0 bg-cover bg-center" 
                style={{ backgroundImage: `url(${formData.backgroundImage})`, backgroundColor: formData.backgroundColor }}
             />
             <div className="absolute inset-0 bg-black/50" />
             <div className="relative z-10 max-w-lg">
                <h2 className="text-2xl font-bold mb-2">{formData.headline}</h2>
                <p className="text-sm mb-4 opacity-90">{formData.subheadline}</p>
                <button className="bg-[#D4AF37] text-[#003366] px-4 py-2 rounded-full font-bold text-sm">
                   {formData.ctaText}
                </button>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EditHeroSection;
