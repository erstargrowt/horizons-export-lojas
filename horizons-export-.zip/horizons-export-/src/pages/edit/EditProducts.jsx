
import React, { useState } from 'react';
import { useEditableContent } from '@/context/EditableContentContext';
import TextInput from '@/components/edit/TextInput';
import TextArea from '@/components/edit/TextArea';
import ImageUpload from '@/components/edit/ImageUpload';
import { useToast } from '@/components/ui/use-toast';
import { Plus, Edit, Trash2, Save, X, Search } from 'lucide-react';

const EditProducts = () => {
  const { products, updateContent } = useEditableContent();
  const { toast } = useToast();
  const [editingId, setEditingId] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const initialFormState = {
    id: null,
    name: '',
    category: 'Eletrônicos',
    originalPrice: '',
    discountPrice: '',
    image: '',
    description: '',
    stock: 0,
    isBestSeller: false,
    isNew: false
  };
  
  const [formData, setFormData] = useState(initialFormState);

  const filteredProducts = products.filter(p => 
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    p.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleOpenModal = (product = null) => {
    if (product) {
      setEditingId(product.id);
      setFormData(product);
    } else {
      setEditingId(null);
      setFormData({ ...initialFormState, id: Date.now() });
    }
    setIsModalOpen(true);
  };

  const handleSave = () => {
    let updatedProducts;
    if (editingId) {
      updatedProducts = products.map(p => p.id === editingId ? { ...formData, id: editingId } : p);
    } else {
      updatedProducts = [...products, { ...formData, id: Date.now() }];
    }
    
    // Recalculate discount percent automatically
    updatedProducts = updatedProducts.map(p => {
        if(p.originalPrice && p.discountPrice) {
            const discount = Math.round(((p.originalPrice - p.discountPrice) / p.originalPrice) * 100);
            return {...p, discount: Math.max(0, discount)};
        }
        return p;
    });

    updateContent('products', updatedProducts);
    setIsModalOpen(false);
    toast({ title: editingId ? 'Produto atualizado!' : 'Produto criado!' });
  };

  const handleDelete = (id) => {
    if (window.confirm('Tem certeza que deseja excluir este produto?')) {
      const updatedProducts = products.filter(p => p.id !== id);
      updateContent('products', updatedProducts);
      toast({ title: 'Produto removido.' });
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-[#003366]">Gerenciar Produtos</h2>
        <button
          onClick={() => handleOpenModal()}
          className="bg-[#D4AF37] text-[#003366] px-4 py-2 rounded-lg flex items-center gap-2 font-bold hover:bg-[#c4a030]"
        >
          <Plus size={18} /> Novo Produto
        </button>
      </div>

      <div className="mb-6 relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
        <input 
          type="text" 
          placeholder="Buscar produtos..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
        />
      </div>

      <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="p-4 font-bold text-gray-600">Produto</th>
              <th className="p-4 font-bold text-gray-600">Categoria</th>
              <th className="p-4 font-bold text-gray-600">Preço</th>
              <th className="p-4 font-bold text-gray-600">Estoque</th>
              <th className="p-4 font-bold text-gray-600 text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {filteredProducts.map(product => (
              <tr key={product.id} className="border-b border-gray-100 hover:bg-gray-50">
                <td className="p-4 flex items-center gap-3">
                  <img src={product.image} alt="" className="w-10 h-10 rounded object-cover bg-gray-100" />
                  <span className="font-medium text-gray-800 line-clamp-1">{product.name}</span>
                </td>
                <td className="p-4 text-sm text-gray-600">{product.category}</td>
                <td className="p-4 font-bold text-[#003366]">R$ {Number(product.discountPrice).toFixed(2)}</td>
                <td className="p-4 text-sm">{product.stock}</td>
                <td className="p-4 text-right">
                  <div className="flex justify-end gap-2">
                    <button onClick={() => handleOpenModal(product)} className="p-2 text-blue-600 hover:bg-blue-50 rounded"><Edit size={18} /></button>
                    <button onClick={() => handleDelete(product.id)} className="p-2 text-red-600 hover:bg-red-50 rounded"><Trash2 size={18} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto p-6 shadow-2xl">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-[#003366]">{editingId ? 'Editar Produto' : 'Novo Produto'}</h3>
              <button onClick={() => setIsModalOpen(false)}><X size={24} className="text-gray-400" /></button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <TextInput label="Nome do Produto" value={formData.name} onChange={(v) => setFormData({...formData, name: v})} required />
              <div className="mb-4">
                 <label className="block text-sm font-bold text-gray-700 mb-1">Categoria</label>
                 <select 
                    value={formData.category} 
                    onChange={(e) => setFormData({...formData, category: e.target.value})}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-white"
                 >
                    <option>Eletrônicos</option>
                    <option>Relógios</option>
                    <option>Kids</option>
                    <option>Cosméticos</option>
                    <option>eBooks</option>
                    <option>Novidades</option>
                 </select>
              </div>
              <TextInput label="Preço Original (R$)" type="number" value={formData.originalPrice} onChange={(v) => setFormData({...formData, originalPrice: Number(v)})} />
              <TextInput label="Preço com Desconto (R$)" type="number" value={formData.discountPrice} onChange={(v) => setFormData({...formData, discountPrice: Number(v)})} required />
              <TextInput label="Estoque" type="number" value={formData.stock} onChange={(v) => setFormData({...formData, stock: Number(v)})} />
              
              <div className="flex flex-col gap-2 pt-6">
                 <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={formData.isBestSeller} onChange={(e) => setFormData({...formData, isBestSeller: e.target.checked})} />
                    <span className="text-sm font-medium">Mais Vendido</span>
                 </label>
                 <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" checked={formData.isNew} onChange={(e) => setFormData({...formData, isNew: e.target.checked})} />
                    <span className="text-sm font-medium">Lançamento</span>
                 </label>
              </div>
            </div>

            <ImageUpload label="Imagem do Produto" value={formData.image} onChange={(v) => setFormData({...formData, image: v})} />
            <TextArea label="Descrição" value={formData.description} onChange={(v) => setFormData({...formData, description: v})} />

            <div className="flex justify-end gap-3 mt-6">
              <button onClick={() => setIsModalOpen(false)} className="px-4 py-2 border border-gray-300 rounded-lg font-bold text-gray-600">Cancelar</button>
              <button onClick={handleSave} className="px-6 py-2 bg-[#003366] text-white rounded-lg font-bold flex items-center gap-2">
                <Save size={18} /> Salvar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EditProducts;
