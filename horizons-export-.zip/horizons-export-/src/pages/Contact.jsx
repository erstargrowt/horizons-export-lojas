
import React from 'react';
import { Helmet } from 'react-helmet';
import { Mail, Phone, MapPin } from 'lucide-react';
import Breadcrumb from '@/components/Breadcrumb';

const Contact = () => {
  return (
    <>
      <Helmet><title>Contato | Stargrowth</title></Helmet>
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="container mx-auto px-4 max-w-4xl">
           <Breadcrumb items={[{ label: 'Contato', path: '/contato' }]} />
           <h1 className="text-3xl font-bold text-[#003366] mb-8 text-center">Fale Conosco</h1>
           
           <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-white p-8 rounded-2xl shadow-lg">
                 <h2 className="text-xl font-bold mb-6">Envie uma mensagem</h2>
                 <form className="space-y-4">
                    <input type="text" placeholder="Nome" className="w-full p-3 border rounded-lg" />
                    <input type="email" placeholder="Email" className="w-full p-3 border rounded-lg" />
                    <textarea placeholder="Mensagem" rows="5" className="w-full p-3 border rounded-lg"></textarea>
                    <button className="w-full bg-[#003366] text-white font-bold py-3 rounded-lg">Enviar</button>
                 </form>
              </div>
              
              <div className="space-y-6">
                 <div className="bg-white p-6 rounded-2xl shadow-lg flex items-center gap-4">
                    <div className="bg-blue-50 p-3 rounded-full text-[#003366]"><Mail /></div>
                    <div>
                       <h3 className="font-bold">Email</h3>
                       <p className="text-gray-600">suporte@stargrowth.com</p>
                    </div>
                 </div>
                 <div className="bg-white p-6 rounded-2xl shadow-lg flex items-center gap-4">
                    <div className="bg-blue-50 p-3 rounded-full text-[#003366]"><Phone /></div>
                    <div>
                       <h3 className="font-bold">Telefone</h3>
                       <p className="text-gray-600">(11) 99999-9999</p>
                    </div>
                 </div>
                 <div className="bg-white p-6 rounded-2xl shadow-lg flex items-center gap-4">
                    <div className="bg-blue-50 p-3 rounded-full text-[#003366]"><MapPin /></div>
                    <div>
                       <h3 className="font-bold">Endereço</h3>
                       <p className="text-gray-600">Av. Paulista, 1000 - SP</p>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      </div>
    </>
  );
};

export default Contact;
