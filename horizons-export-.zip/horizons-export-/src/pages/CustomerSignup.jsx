
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCustomerAuth } from '@/context/CustomerAuthContext';
import { Helmet } from 'react-helmet';
import { useToast } from '@/components/ui/use-toast';

const CustomerSignup = () => {
  const [formData, setFormData] = useState({ name: '', email: '', password: '', confirmPassword: '' });
  const { signup } = useCustomerAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      toast({ title: 'Erro', description: 'Senhas não conferem', variant: 'destructive' });
      return;
    }
    const result = signup({ name: formData.name, email: formData.email, password: formData.password });
    if (result.success) {
      toast({ title: 'Conta criada com sucesso!' });
      navigate('/minha-conta');
    } else {
      toast({ title: 'Erro', description: result.message, variant: 'destructive' });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      <Helmet><title>Cadastro | Stargrowth</title></Helmet>
      <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md">
        <h1 className="text-2xl font-bold text-[#003366] mb-6 text-center">Crie sua Conta</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input 
             type="text" 
             placeholder="Nome Completo"
             value={formData.name} 
             onChange={e => setFormData({...formData, name: e.target.value})} 
             className="w-full p-3 border rounded-lg outline-none focus:border-[#003366]"
             required 
          />
          <input 
             type="email" 
             placeholder="Email"
             value={formData.email} 
             onChange={e => setFormData({...formData, email: e.target.value})} 
             className="w-full p-3 border rounded-lg outline-none focus:border-[#003366]"
             required 
          />
          <input 
             type="password" 
             placeholder="Senha"
             value={formData.password} 
             onChange={e => setFormData({...formData, password: e.target.value})} 
             className="w-full p-3 border rounded-lg outline-none focus:border-[#003366]"
             required 
          />
           <input 
             type="password" 
             placeholder="Confirmar Senha"
             value={formData.confirmPassword} 
             onChange={e => setFormData({...formData, confirmPassword: e.target.value})} 
             className="w-full p-3 border rounded-lg outline-none focus:border-[#003366]"
             required 
          />
          <button type="submit" className="w-full bg-[#003366] text-white font-bold py-3 rounded-lg hover:bg-[#004d99]">Cadastrar</button>
        </form>
        <div className="mt-4 text-center text-sm text-gray-600">
          Já tem conta? <Link to="/login" className="text-[#D4AF37] font-bold hover:underline">Faça Login</Link>
        </div>
      </div>
    </div>
  );
};

export default CustomerSignup;
