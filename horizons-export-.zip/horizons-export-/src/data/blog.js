
export const blogPosts = [
  {
    id: 1,
    slug: 'escolher-relogio-perfeito',
    title: '5 Dicas para Escolher o Relógio Perfeito para Seu Estilo',
    description: 'Encontre o acessório ideal que combina funcionalidade e elegância para elevar seu visual em qualquer ocasião.',
    image: 'https://images.unsplash.com/photo-1659461278684-68963aa3162f',
    publishedAt: '2024-03-15',
    readTime: '5 min',
    category: 'Relógios',
    author: 'Natan Ribeiro',
    content: `
      <p>Um relógio é muito mais do que apenas um instrumento para marcar o tempo. É uma extensão da sua personalidade, um símbolo de estilo e, muitas vezes, uma herança que passa de geração em geração. Mas com tantas opções disponíveis no mercado, como escolher o modelo ideal para você?</p>

      <h3>1. Defina seu Estilo de Vida</h3>
      <p>O primeiro passo é analisar sua rotina. Se você pratica esportes, um modelo robusto, resistente à água e com cronômetro (como nossos modelos táticos) é essencial. Para ambientes corporativos, um relógio analógico clássico com pulseira de couro ou metal transmite profissionalismo e sofisticação.</p>

      <h3>2. O Tamanho Importa</h3>
      <p>A proporção é chave. Pulsos mais finos pedem caixas menores (entre 38mm e 40mm), enquanto pulsos mais largos comportam bem modelos acima de 42mm. Um relógio desproporcional pode comprometer a elegância do visual, independentemente do preço da peça.</p>

      <h3>3. Movimento: Quartzo ou Mecânico?</h3>
      <p>Relógios de quartzo (bateria) são práticos e precisos, ideais para o dia a dia. Já os mecânicos (automáticos ou de corda) são obras de arte da engenharia, valorizados por entusiastas e colecionadores. A escolha depende se você prioriza a praticidade ou a tradição horológica.</p>

      <h3>4. Versatilidade é a Chave</h3>
      <p>Se você pretende ter apenas um bom relógio, opte por cores neutras como prata, preto ou azul marinho. Essas tonalidades transitam bem entre o escritório e o happy hour, garantindo que você esteja sempre bem alinhado.</p>

      <h3>5. Invista em Qualidade</h3>
      <p>Um bom relógio é um investimento. Verifique o material do vidro (safira é o mais resistente a riscos), a qualidade do aço e a resistência à água. Na Stargrowth, selecionamos apenas peças que passam por rigorosos testes de qualidade para garantir durabilidade.</p>
    `,
    recommendedProducts: [6, 7, 8]
  },
  {
    id: 2,
    slug: 'skincare-essencial',
    title: 'Skincare Essencial: Como Cuidar da Sua Pele em Cada Estação',
    description: 'Aprenda a adaptar sua rotina de cuidados com a pele para mantê-la saudável e radiante o ano todo.',
    image: 'https://images.unsplash.com/photo-1561571673-b85b850562c5',
    publishedAt: '2024-03-10',
    readTime: '4 min',
    category: 'Skincare',
    author: 'Dra. Mara Mendonça',
    content: `
      <p>Nossa pele reage diretamente às mudanças climáticas. O que funciona no verão pode não ser suficiente no inverno. Entender essas necessidades é o segredo para uma pele sempre jovem e saudável.</p>

      <h3>Verão: Proteção e Controle de Oleosidade</h3>
      <p>No calor, a produção de sebo aumenta. Aposte em sabonetes de limpeza profunda e hidratantes em gel. E, claro, o protetor solar é inegociável! Reaplique a cada 2 horas para evitar manchas e envelhecimento precoce.</p>

      <h3>Outono: Renovação</h3>
      <p>É a época ideal para tratamentos mais profundos, como peelings e uso de ácidos (sempre com recomendação profissional). A pele começa a pedir mais hidratação conforme a umidade do ar cai.</p>

      <h3>Inverno: Hidratação Intensa</h3>
      <p>O frio e os banhos quentes ressecam a barreira cutânea. Troque o hidratante leve por cremes mais densos e ricos em ceramidas. Evite lavar o rosto com água muito quente para não provocar efeito rebote na oleosidade.</p>

      <h3>Primavera: Preparação</h3>
      <p>Foco em antioxidantes! A vitamina C é sua melhor amiga nesta estação, potencializando o efeito do protetor solar e trazendo luminosidade para a pele que ficou "escondida" no inverno.</p>
    `,
    recommendedProducts: [11, 12, 13]
  },
  {
    id: 3,
    slug: 'tecnologia-wearable-rotina',
    title: 'Tecnologia Wearable: Como Smartwatches Transformam Sua Rotina',
    description: 'Descubra como os relógios inteligentes podem aumentar sua produtividade e melhorar sua saúde.',
    image: 'https://images.unsplash.com/photo-1537634987034-578b45727448',
    publishedAt: '2024-03-05',
    readTime: '6 min',
    category: 'Tecnologia',
    author: 'Thalles Nogueira',
    content: `
      <p>Eles deixaram de ser apenas "gadgets" curiosos para se tornarem assistentes pessoais indispensáveis. Os smartwatches modernos são verdadeiros centros de controle no seu pulso.</p>

      <h3>Saúde em Tempo Real</h3>
      <p>Monitoramento cardíaco, nível de oxigênio no sangue e análise do sono não são mais exclusividade de equipamentos médicos. Ter esses dados à mão ajuda a identificar padrões e melhorar hábitos diários.</p>

      <h3>Foco e Produtividade</h3>
      <p>Receber notificações seletivas no pulso evita que você pegue o celular a todo momento e se perca nas redes sociais. Configure seu smartwatch para alertar apenas o essencial: ligações importantes e agenda.</p>

      <h3>O Incentivo que Faltava</h3>
      <p>A gamificação dos exercícios (fechar anéis, bater metas de passos) funciona psicologicamente como um grande motivador. Ver seu progresso visualmente cria um compromisso com sua própria saúde.</p>
    `,
    recommendedProducts: [5, 1, 2]
  },
  {
    id: 4,
    slug: 'presentes-criativos-criancas',
    title: 'Presentes Incríveis para Crianças que Estimulam Criatividade',
    description: 'Fuja do óbvio e escolha brinquedos que divertem enquanto ensinam habilidades valiosas.',
    image: 'https://images.unsplash.com/photo-1655087751325-1aba19f6dd16',
    publishedAt: '2024-02-28',
    readTime: '3 min',
    category: 'Infantil',
    author: 'Vanessa Nogueira',
    content: `
      <p>Em um mundo dominado por telas, brinquedos físicos que estimulam o pensamento crítico e a coordenação motora são presentes valiosos para o desenvolvimento infantil.</p>

      <h3>Brinquedos STEM</h3>
      <p>Sigla para Science, Technology, Engineering and Math. Kits de robótica, blocos de construção complexos e jogos de lógica preparam a criança para o futuro de forma lúdica.</p>

      <h3>Arte e Expressão</h3>
      <p>Kits de pintura, instrumentos musicais e massinhas de modelar ajudam na expressão emocional. A criança aprende a externalizar sentimentos e desenvolve a sensibilidade artística.</p>

      <h3>Jogos de Tabuleiro Modernos</h3>
      <p>Esqueça os clássicos demorados e baseados apenas em sorte. Os jogos modernos focam em estratégia, cooperação e gestão de recursos, ensinando habilidades sociais importantes.</p>
    `,
    recommendedProducts: [9, 10]
  },
  {
    id: 5,
    slug: 'livros-mudaram-vidas',
    title: 'Desenvolvimento Pessoal: Livros que Mudaram Vidas',
    description: 'Uma curadoria de leituras essenciais para quem busca crescimento profissional e pessoal.',
    image: 'https://images.unsplash.com/photo-1662640010851-6c6db77fbb7d',
    publishedAt: '2024-02-20',
    readTime: '7 min',
    category: 'Livros',
    author: 'Brendon Nogueira',
    content: `
      <p>O conhecimento é o único investimento com retorno garantido. Selecionamos obras que não apenas informam, mas transformam a maneira como você enxerga o mundo e seus objetivos.</p>

      <h3>Hábitos Atômicos</h3>
      <p>Entenda como pequenas mudanças, quando consistentes, geram resultados extraordinários. É o guia definitivo para abandonar vícios e construir rotinas produtivas.</p>

      <h3>A Psicologia Financeira</h3>
      <p>Dinheiro tem mais a ver com comportamento do que com matemática. Aprenda a dominar suas emoções para tomar decisões financeiras mais inteligentes e construir riqueza a longo prazo.</p>

      <h3>Mindset</h3>
      <p>A diferença entre quem desiste e quem prospera muitas vezes está na mentalidade. Descubra como adotar o "mindset de crescimento" pode destravar seu potencial em todas as áreas da vida.</p>
    `,
    recommendedProducts: [14, 15]
  },
  {
    id: 6,
    slug: 'tendencias-moda-infantil-2024',
    title: 'Tendências de Moda Infantil 2024',
    description: 'Conforto, estilo e sustentabilidade: saiba o que está em alta para os pequenos neste ano.',
    image: 'https://images.unsplash.com/photo-1700734211614-f9091eb4b5d7',
    publishedAt: '2024-02-15',
    readTime: '4 min',
    category: 'Moda',
    author: 'Equipe Stargrowth',
    content: `
      <p>A moda infantil 2024 vem com uma proposta clara: deixar criança ser criança, mas com muito estilo. O foco total é no conforto e na durabilidade das peças.</p>

      <h3>Cores da Natureza</h3>
      <p>Tons terrosos, verdes musgo e azuis suaves dominam as coleções. São cores fáceis de combinar e que trazem uma sensação de calma e conexão com o ambiente.</p>

      <h3>Tecidos Tecnológicos</h3>
      <p>Roupas que não amassam, secam rápido e protegem contra raios UV ganham espaço. Praticidade para os pais e proteção para os filhos em um só produto.</p>

      <h3>Genderless (Sem Gênero)</h3>
      <p>Peças neutras, que podem ser usadas por meninos e meninas, facilitam a herança entre irmãos e promovem uma moda mais sustentável e consciente.</p>
    `,
    recommendedProducts: [10, 9]
  }
];

export const blogCategories = ['Todos', 'Relógios', 'Skincare', 'Tecnologia', 'Infantil', 'Livros', 'Moda'];
