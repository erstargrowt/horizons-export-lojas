
export const subscriptions = [
  {
    id: 1,
    name: 'Assinatura Básica',
    price: 49.90,
    period: 'mensal',
    benefits: [
      'Acesso a documentos básicos',
      'Desconto de 5% em produtos',
      'Newsletter semanal exclusiva'
    ],
    features: ['Documentos PDF', 'Suporte por email']
  },
  {
    id: 2,
    name: 'Assinatura Premium',
    price: 99.90,
    period: 'mensal',
    recommended: true,
    benefits: [
      'Acesso a todos os documentos',
      'Acesso a vídeos exclusivos',
      'Desconto de 15% em produtos',
      'Grupo de networking no Telegram'
    ],
    features: ['Documentos PDF e Vídeos', 'Suporte prioritário', 'Acesso antecipado a lançamentos']
  },
  {
    id: 3,
    name: 'Assinatura VIP',
    price: 199.90,
    period: 'mensal',
    benefits: [
      'Acesso total à plataforma',
      'Mentoria mensal em grupo',
      'Desconto de 25% em produtos',
      'Consultoria rápida de perfil'
    ],
    features: ['Tudo do Premium', 'Mentoria ao vivo', 'Análise de perfil']
  }
];
