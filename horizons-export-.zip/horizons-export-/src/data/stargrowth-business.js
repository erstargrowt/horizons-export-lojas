
export const businessPlans = [
  {
    id: 1,
    name: 'Plano Start',
    price: 997,
    description: 'Ideal para quem está começando e quer validar sua ideia de negócio com baixo investimento.',
    benefits: [
      'Acesso à comunidade básica',
      'Mentoria em grupo mensal',
      'Acesso a 3 cursos introdutórios',
      'Suporte via email'
    ]
  },
  {
    id: 2,
    name: 'Plano Pro',
    price: 2497,
    description: 'Para empreendedores que já têm um negócio e querem escalar suas vendas.',
    benefits: [
      'Tudo do Plano Start',
      'Mentoria quinzenal em grupo',
      'Acesso a todos os cursos',
      'Análise de perfil de negócio',
      'Suporte via WhatsApp'
    ]
  },
  {
    id: 3,
    name: 'Plano Elite',
    price: 4997,
    description: 'Acompanhamento exclusivo para quem busca alta performance e resultados rápidos.',
    benefits: [
      'Tudo do Plano Pro',
      'Mentoria individual mensal',
      'Planejamento estratégico personalizado',
      'Networking exclusivo com grandes players',
      'Acesso vitalício aos conteúdos'
    ]
  },
  {
    id: 4,
    name: 'Plano Corporate',
    price: 9997,
    description: 'Soluções customizadas para empresas que buscam treinar suas equipes e otimizar processos.',
    benefits: [
      'Treinamento in-company (online)',
      'Consultoria de processos',
      'Acesso multi-usuário',
      'Relatórios de desempenho da equipe',
      'Gerente de conta dedicado'
    ]
  },
  {
    id: 5,
    name: 'Plano Franchise',
    price: 19997,
    description: 'Modelo completo de franquia para quem quer representar a marca Stargrowth.',
    benefits: [
      'Direito de uso da marca',
      'Manual de operações completo',
      'Treinamento intensivo de franqueado',
      'Suporte jurídico e contábil inicial',
      'Território exclusivo de atuação'
    ]
  }
];
