
export const recognitions = {
  awards: [
    {
      id: 1,
      title: 'Prêmio Inovação Digital 2023',
      organization: 'Tech Awards Brasil',
      date: 'Dezembro 2023',
      description: 'Reconhecimento pela plataforma de ensino mais inovadora do ano.'
    },
    {
      id: 2,
      title: 'Top 10 Empreendedorismo',
      organization: 'Revista Negócios & Cia',
      date: 'Agosto 2023',
      description: 'Listado entre as 10 iniciativas de maior impacto no empreendedorismo nacional.'
    },
    {
      id: 3,
      title: 'Selo de Excelência em Atendimento',
      organization: 'Instituto Cliente Feliz',
      date: 'Maio 2023',
      description: 'Conquistado após manter NPS acima de 90 por 12 meses consecutivos.'
    }
  ],
  certifications: [
    { name: 'ISO 9001', issuer: 'ABNT' },
    { name: 'Great Place to Work', issuer: 'GPTW Institute' },
    { name: 'Google Partner', issuer: 'Google' }
  ],
  mediaMentions: [
    {
      source: 'Portal Exame',
      title: 'Stargrowth revoluciona o mercado de educação executiva',
      link: '#'
    },
    {
      source: 'Forbes Brasil',
      title: 'Como a Stargrowth está formando a nova geração de líderes',
      link: '#'
    },
    {
      source: 'Valor Econômico',
      title: 'Startups de educação crescem 200% no último ano',
      link: '#'
    }
  ],
  partnerships: [
    { name: 'Microsoft', type: 'Technology Partner' },
    { name: 'Amazon AWS', type: 'Cloud Partner' },
    { name: 'HubSpot', type: 'CRM Partner' }
  ]
};
