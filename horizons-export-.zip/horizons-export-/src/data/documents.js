
export const documents = [
  {
    id: 1,
    title: 'Guia Definitivo de Vendas',
    type: 'PDF',
    category: 'Vendas',
    date: '10/01/2024',
    link: '#',
    description: 'Um manual completo com scripts e processos de vendas.'
  },
  {
    id: 2,
    title: 'Planilha de Fluxo de Caixa',
    type: 'Guia',
    category: 'Finanças',
    date: '15/01/2024',
    link: '#',
    description: 'Template editável para controle financeiro empresarial.'
  },
  {
    id: 3,
    title: 'Aula Magna: Liderança Moderna',
    type: 'Vídeo',
    category: 'Liderança',
    date: '20/01/2024',
    link: '#',
    description: 'Gravação da aula especial sobre gestão de pessoas.'
  },
  {
    id: 4,
    title: 'Checklist de Marketing Digital',
    type: 'PDF',
    category: 'Marketing',
    date: '05/02/2024',
    link: '#',
    description: 'Lista de verificação para lançamentos e campanhas.'
  },
  {
    id: 5,
    title: 'Modelo de Contrato de Prestação de Serviços',
    type: 'Guia',
    category: 'Jurídico',
    date: '12/02/2024',
    link: '#',
    description: 'Minuta padrão para prestadores de serviço e freelancers.'
  },
  {
    id: 6,
    title: 'Webinar: Tendências de Mercado 2024',
    type: 'Vídeo',
    category: 'Estratégia',
    date: '25/02/2024',
    link: '#',
    description: 'Análise completa do cenário econômico atual.'
  },
  {
    id: 7,
    title: 'Ebook: Produtividade Extrema',
    type: 'PDF',
    category: 'Produtividade',
    date: '01/03/2024',
    link: '#',
    description: 'Técnicas para fazer mais em menos tempo.'
  },
  {
    id: 8,
    title: 'Calculadora de ROI',
    type: 'Guia',
    category: 'Finanças',
    date: '10/03/2024',
    link: '#',
    description: 'Ferramenta interativa para cálculo de retorno sobre investimento.'
  },
  {
    id: 9,
    title: 'Tutorial: Configurando seu CRM',
    type: 'Vídeo',
    category: 'Tecnologia',
    date: '15/03/2024',
    link: '#',
    description: 'Passo a passo para implementar um CRM na sua empresa.'
  },
  {
    id: 10,
    title: 'Template de Apresentação Comercial',
    type: 'Guia',
    category: 'Vendas',
    date: '20/03/2024',
    link: '#',
    description: 'Slides prontos para apresentar sua proposta de valor.'
  },
  {
    id: 11,
    title: 'Manual de Identidade Visual',
    type: 'PDF',
    category: 'Design',
    date: '25/03/2024',
    link: '#',
    description: 'Diretrizes básicas para manter a consistência da sua marca.'
  },
  {
    id: 12,
    title: 'Masterclass: Negociação Avançada',
    type: 'Vídeo',
    category: 'Vendas',
    date: '05/04/2024',
    link: '#',
    description: 'Técnicas de persuasão e fechamento de grandes contratos.'
  },
  {
    id: 13,
    title: 'Planilha de Precificação de Serviços',
    type: 'Guia',
    category: 'Finanças',
    date: '10/04/2024',
    link: '#',
    description: 'Calcule o preço ideal para seus serviços considerando custos e margem.'
  },
  {
    id: 14,
    title: 'Relatório de Inteligência de Mercado',
    type: 'PDF',
    category: 'Estratégia',
    date: '15/04/2024',
    link: '#',
    description: 'Dados e insights sobre o comportamento do consumidor.'
  },
  {
    id: 15,
    title: 'Workshop: Storytelling para Negócios',
    type: 'Vídeo',
    category: 'Comunicação',
    date: '20/04/2024',
    link: '#',
    description: 'Como contar histórias que vendem e conectam com o público.'
  }
];
