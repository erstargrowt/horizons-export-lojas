
export const trainings = [
  {
    id: 1,
    title: 'Gestão de Tempo para Líderes',
    description: 'Aprenda a priorizar tarefas e multiplicar sua produtividade como gestor.',
    duration: '10 horas',
    level: 'Iniciante',
    price: 297,
    category: 'Liderança'
  },
  {
    id: 2,
    title: 'Vendas de Alta Performance',
    description: 'Técnicas avançadas de negociação e fechamento para vendedores ambiciosos.',
    duration: '20 horas',
    level: 'Intermediário',
    price: 497,
    category: 'Vendas'
  },
  {
    id: 3,
    title: 'Marketing Digital Estratégico',
    description: 'Domine as principais ferramentas e estratégias para crescer sua marca online.',
    duration: '30 horas',
    level: 'Avançado',
    price: 697,
    category: 'Marketing'
  },
  {
    id: 4,
    title: 'Finanças Corporativas Básicas',
    description: 'Entenda os fundamentos financeiros para tomar decisões de negócio mais assertivas.',
    duration: '15 horas',
    level: 'Iniciante',
    price: 397,
    category: 'Finanças'
  },
  {
    id: 5,
    title: 'Liderança 4.0',
    description: 'Como liderar equipes na era digital e manter a cultura organizacional forte.',
    duration: '25 horas',
    level: 'Avançado',
    price: 897,
    category: 'Liderança'
  },
  {
    id: 6,
    title: 'Inteligência Emocional no Trabalho',
    description: 'Desenvolva soft skills essenciais para relacionamentos profissionais saudáveis.',
    duration: '12 horas',
    level: 'Iniciante',
    price: 247,
    category: 'Desenvolvimento Pessoal'
  },
  {
    id: 7,
    title: 'Gestão de Projetos Ágeis',
    description: 'Aprenda Scrum e Kanban para entregar projetos com mais rapidez e qualidade.',
    duration: '18 horas',
    level: 'Intermediário',
    price: 597,
    category: 'Gestão'
  },
  {
    id: 8,
    title: 'Oratória e Comunicação Persuasiva',
    description: 'Fale em público com confiança e convença sua audiência.',
    duration: '14 horas',
    level: 'Intermediário',
    price: 447,
    category: 'Comunicação'
  },
  {
    id: 9,
    title: 'E-commerce do Zero ao Milhão',
    description: 'Passo a passo para criar e escalar sua loja virtual.',
    duration: '40 horas',
    level: 'Avançado',
    price: 997,
    category: 'E-commerce'
  },
  {
    id: 10,
    title: 'Customer Success na Prática',
    description: 'Como reter clientes e aumentar o LTV através do sucesso do cliente.',
    duration: '16 horas',
    level: 'Intermediário',
    price: 397,
    category: 'Atendimento'
  }
];
