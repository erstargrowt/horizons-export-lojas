
import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { CartProvider } from '@/hooks/useCart';
import { AdminAuthProvider, useAdminAuth } from '@/context/AdminAuthContext';
import { CouponProvider } from '@/context/CouponContext';
import { EmailProvider } from '@/context/EmailContext';
import { AnalyticsProvider } from '@/context/AnalyticsContext';
import { EditableContentProvider } from '@/context/EditableContentContext';
import { NotificationProvider } from '@/context/NotificationContext';
import { ChatProvider } from '@/context/ChatContext';
import { InstagramProvider } from '@/context/InstagramContext';
import { GoogleAnalyticsProvider } from '@/context/GoogleAnalyticsContext';
import { ChatbotProvider } from '@/context/ChatbotContext';
import { CustomerAuthProvider } from '@/context/CustomerAuthContext';
import { Toaster } from '@/components/ui/toaster';

// Client Components
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import Home from '@/pages/Home';
import QuemSomos from '@/pages/QuemSomos';
import Contato from '@/pages/Contato';
import Departamentos from '@/pages/Departamentos';
import Categorias from '@/pages/Categorias';
import ProductDetailPage from '@/pages/ProductDetailPage';
import Cart from '@/pages/Cart';
import BlogList from '@/pages/BlogList';
import BlogPost from '@/pages/BlogPost';
import ChatWidget from '@/components/ChatWidget';
import DiscountPopup from '@/components/DiscountPopup';
import InstagramFeed from '@/pages/InstagramFeed';
import Checkout from '@/pages/Checkout';
import OrderSuccess from '@/pages/OrderSuccess';
import OrderTracking from '@/pages/OrderTracking';
import CustomerLogin from '@/pages/CustomerLogin';
import CustomerSignup from '@/pages/CustomerSignup';
import CustomerDashboard from '@/pages/CustomerDashboard';

// Admin Components
import AdminLayout from '@/components/admin/AdminLayout';
import AdminLogin from '@/pages/admin/AdminLogin';
import AdminDashboard from '@/pages/admin/AdminDashboard';
import CouponManagement from '@/pages/admin/CouponManagement';
import EmailManagement from '@/pages/admin/EmailManagement';
import CampaignManagement from '@/pages/admin/CampaignManagement';
import AnalyticsDashboard from '@/pages/admin/AnalyticsDashboard';
import NotificationsConfig from '@/pages/admin/NotificationsConfig';
import ChatConfig from '@/pages/admin/ChatConfig';
import AdminChat from '@/pages/admin/AdminChat';
import InstagramConfig from '@/pages/admin/InstagramConfig';
import GoogleAnalyticsConfig from '@/pages/admin/GoogleAnalyticsConfig';
import ChatbotConfig from '@/pages/admin/ChatbotConfig';
import ChatbotHistory from '@/pages/admin/ChatbotHistory';
import ChatbotAnalytics from '@/pages/admin/ChatbotAnalytics';

// Edit Components
import EditLayout from '@/components/edit/EditLayout';
import EditContent from '@/pages/edit/EditContent';
import EditHeroSection from '@/pages/edit/EditHeroSection';
import EditCategories from '@/pages/edit/EditCategories';
import EditProducts from '@/pages/edit/EditProducts';

const PrivateRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAdminAuth();
  if (loading) return <div>Carregando...</div>;
  if (!isAuthenticated) return <Navigate to="/admin/login" />;
  return children;
};

const ClientLayout = ({ children }) => (
  <div className="min-h-screen flex flex-col bg-white font-poppins text-gray-800">
    <Header />
    <main className="flex-grow">{children}</main>
    <Footer />
    <WhatsAppButton />
    <ChatWidget />
    <DiscountPopup />
  </div>
);

function App() {
  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "Stargrowth",
    "url": "https://www.stargrowth.com.br",
    "logo": "https://www.stargrowth.com.br/logo.png",
    "contactPoint": {
      "@type": "ContactPoint",
      "telephone": "+55-27-99999-9999",
      "contactType": "Customer Service"
    }
  };

  return (
    <Router>
      <CartProvider>
        <AdminAuthProvider>
          <CustomerAuthProvider>
          <EditableContentProvider>
            <CouponProvider>
              <EmailProvider>
                <AnalyticsProvider>
                  <NotificationProvider>
                    <ChatProvider>
                      <InstagramProvider>
                        <GoogleAnalyticsProvider>
                          <ChatbotProvider>
                              <Helmet>
                                <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
                                <script type="application/ld+json">{JSON.stringify(organizationSchema)}</script>
                              </Helmet>
                              
                              <Routes>
                                {/* Admin Routes */}
                                <Route path="/admin/login" element={<AdminLogin />} />
                                <Route path="/admin" element={<PrivateRoute><AdminLayout /></PrivateRoute>}>
                                  <Route index element={<Navigate to="/admin/dashboard" />} />
                                  <Route path="dashboard" element={<AdminDashboard />} />
                                  <Route path="cupons" element={<CouponManagement />} />
                                  <Route path="emails" element={<EmailManagement />} />
                                  <Route path="campanhas" element={<CampaignManagement />} />
                                  <Route path="analytics" element={<AnalyticsDashboard />} />
                                  <Route path="notificacoes" element={<NotificationsConfig />} />
                                  <Route path="chat-config" element={<ChatConfig />} />
                                  <Route path="chat" element={<AdminChat />} />
                                  <Route path="instagram" element={<InstagramConfig />} />
                                  <Route path="analytics-config" element={<GoogleAnalyticsConfig />} />
                                  <Route path="chatbot-config" element={<ChatbotConfig />} />
                                  <Route path="chatbot-history" element={<ChatbotHistory />} />
                                  <Route path="chatbot-analytics" element={<ChatbotAnalytics />} />
                                </Route>

                                {/* Editor Routes */}
                                <Route path="/edit-content" element={<PrivateRoute><EditLayout /></PrivateRoute>}>
                                  <Route index element={<EditContent />} />
                                  <Route path="hero" element={<EditHeroSection />} />
                                  <Route path="categories" element={<EditCategories />} />
                                </Route>
                                <Route path="/edit-products" element={<PrivateRoute><EditLayout /></PrivateRoute>}>
                                  <Route index element={<EditProducts />} />
                                </Route>
                                
                                {/* Client Routes */}
                                <Route path="*" element={
                                  <ClientLayout>
                                    <Routes>
                                      <Route path="/" element={<Home />} />
                                      <Route path="/quem-somos" element={<QuemSomos />} />
                                      <Route path="/contato" element={<Contato />} />
                                      <Route path="/departamentos" element={<Departamentos />} />
                                      <Route path="/categorias" element={<Categorias />} />
                                      <Route path="/categorias/:category" element={<Categorias />} />
                                      {/* Updated route to use ProductDetailPage */}
                                      <Route path="/product/:id" element={<ProductDetailPage />} />
                                      <Route path="/produto/:id" element={<ProductDetailPage />} />
                                      <Route path="/carrinho" element={<Cart />} />
                                      <Route path="/checkout" element={<Checkout />} />
                                      <Route path="/order-success" element={<OrderSuccess />} />
                                      <Route path="/rastreamento" element={<OrderTracking />} />
                                      <Route path="/blog" element={<BlogList />} />
                                      <Route path="/blog/:slug" element={<BlogPost />} />
                                      <Route path="/instagram-feed" element={<InstagramFeed />} />
                                      <Route path="/login" element={<CustomerLogin />} />
                                      <Route path="/cadastro" element={<CustomerSignup />} />
                                      <Route path="/minha-conta" element={<CustomerDashboard />} />
                                      <Route path="*" element={<div className="p-20 text-center font-bold text-2xl text-[#003366]">404 - Página não encontrada</div>} />
                                    </Routes>
                                  </ClientLayout>
                                } />
                              </Routes>

                              <Toaster />
                          </ChatbotProvider>
                        </GoogleAnalyticsProvider>
                      </InstagramProvider>
                    </ChatProvider>
                  </NotificationProvider>
                </AnalyticsProvider>
              </EmailProvider>
            </CouponProvider>
          </EditableContentProvider>
          </CustomerAuthProvider>
        </AdminAuthProvider>
      </CartProvider>
    </Router>
  );
}

export default App;
