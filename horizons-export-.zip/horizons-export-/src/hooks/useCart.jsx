
import React, { createContext, useContext, useState, useEffect, useCallback, useMemo } from 'react';
import { formatCurrency } from '@/api/EcommerceApi';

const CartContext = createContext();

const CART_STORAGE_KEY = 'stargrowth-cart';

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState(() => {
    try {
      const storedCart = localStorage.getItem(CART_STORAGE_KEY);
      return storedCart ? JSON.parse(storedCart) : [];
    } catch (error) {
      console.error('Error loading cart:', error);
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cartItems));
  }, [cartItems]);

  const addToCart = useCallback((product, variant, quantity = 1, availableQuantity = 999) => {
    return new Promise((resolve, reject) => {
      // Adapter for simple product objects (Mock Data compatibility)
      // Usage: addToCart(product) or addToCart(product, quantity)
      let itemVariant = variant;
      let itemQuantity = quantity;
      let itemStock = availableQuantity;

      // If variant is undefined or a number, we assume it's the (product, quantity) signature
      if (typeof variant === 'undefined' || typeof variant === 'number') {
        itemQuantity = typeof variant === 'number' ? variant : 1;
        
        // Create a variant-like structure from the product
        itemVariant = {
          id: product.id,
          title: product.name,
          price_in_cents: (product.discountPrice || product.price) * 100,
          sale_price_in_cents: (product.discountPrice || product.price) * 100,
          manage_inventory: !!product.stock,
          currency_info: { symbol: 'R$', decimal_places: 2 }
        };

        if (product.stock) {
          itemStock = product.stock;
        }
      }

      if (itemVariant.manage_inventory) {
        const existingItem = cartItems.find(item => item.variant.id === itemVariant.id);
        const currentCartQuantity = existingItem ? existingItem.quantity : 0;
        if ((currentCartQuantity + itemQuantity) > itemStock) {
          const error = new Error(`Estoque insuficiente. Apenas ${itemStock} unidades disponíveis.`);
          reject(error);
          return;
        }
      }

      setCartItems(prevItems => {
        const existingItem = prevItems.find(item => item.variant.id === itemVariant.id);
        if (existingItem) {
          return prevItems.map(item =>
            item.variant.id === itemVariant.id
              ? { ...item, quantity: item.quantity + itemQuantity }
              : item
          );
        }
        return [...prevItems, { product, variant: itemVariant, quantity: itemQuantity }];
      });
      resolve();
    });
  }, [cartItems]);

  const removeFromCart = useCallback((variantId) => {
    setCartItems(prevItems => prevItems.filter(item => item.variant.id !== variantId));
  }, []);

  const updateQuantity = useCallback((variantId, quantity) => {
    if (quantity <= 0) {
      removeFromCart(variantId);
      return;
    }
    setCartItems(prevItems =>
      prevItems.map(item =>
        item.variant.id === variantId ? { ...item, quantity } : item
      )
    );
  }, [removeFromCart]);

  const clearCart = useCallback(() => {
    setCartItems([]);
  }, []);

  const getCartTotal = useCallback(() => {
    const totalInCents = cartItems.reduce((total, item) => {
      const price = item.variant.sale_price_in_cents ?? item.variant.price_in_cents;
      return total + price * item.quantity;
    }, 0);

    if (cartItems.length > 0 && cartItems[0].variant.currency_info) {
      try {
        return formatCurrency(totalInCents, cartItems[0].variant.currency_info);
      } catch (e) {
        // Fallback if formatCurrency fails
        return `R$ ${(totalInCents / 100).toFixed(2)}`;
      }
    }
    
    return `R$ ${(totalInCents / 100).toFixed(2)}`;
  }, [cartItems]);

  const getCartCount = useCallback(() => {
    return cartItems.reduce((count, item) => count + item.quantity, 0);
  }, [cartItems]);

  // Compatibility layer for components expecting simple product list
  const cart = useMemo(() => {
    return cartItems.map(item => ({
      ...item.product,
      quantity: item.quantity,
      // Ensure we have the properties expected by legacy components
      id: item.variant.id
    }));
  }, [cartItems]);

  const value = useMemo(() => ({
    cart, // Legacy compatibility
    cartItems, // New structure
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    getCartTotal,
    getCartCount
  }), [cart, cartItems, addToCart, removeFromCart, updateQuantity, clearCart, getCartTotal, getCartCount]);

  return (
    <CartContext.Provider value={value}>
      {children}
    </CartContext.Provider>
  );
};
