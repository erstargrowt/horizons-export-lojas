
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, ShieldCheck, Truck, CreditCard } from 'lucide-react';

const HeroSection = () => {
  return (
    <section className="relative h-[85vh] min-h-[600px] flex items-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1556217257-aa1d0c385e62" 
          alt="E-commerce Hero" 
          className="w-full h-full object-cover object-center"
        />
        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#003366]/90 via-[#003366]/70 to-transparent"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="max-w-2xl text-white"
        >
          <div className="inline-block bg-[#D4AF37] text-[#003366] text-xs font-bold px-3 py-1 rounded-full mb-6 uppercase tracking-wider">
            Nova Coleção 2026
          </div>
          
          <h1 className="text-4xl md:text-6xl font-montserrat font-bold leading-tight mb-6">
            Produtos de Qualidade com <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#D4AF37] to-[#F4D03F]">Preços Imbatíveis</span>
          </h1>
          
          <div className="flex flex-wrap gap-4 text-sm md:text-base text-gray-200 mb-8 font-poppins">
            <span className="flex items-center gap-2 bg-white/10 px-3 py-1 rounded-lg backdrop-blur-sm">
              <Truck size={16} className="text-[#D4AF37]" /> Frete Grátis acima de R$ 200
            </span>
            <span className="flex items-center gap-2 bg-white/10 px-3 py-1 rounded-lg backdrop-blur-sm">
              <ShieldCheck size={16} className="text-[#D4AF37]" /> Pagamento Seguro
            </span>
            <span className="flex items-center gap-2 bg-white/10 px-3 py-1 rounded-lg backdrop-blur-sm">
              <CreditCard size={16} className="text-[#D4AF37]" /> Entrega Rápida
            </span>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <Link to="/departamentos" className="bg-[#D4AF37] hover:bg-[#F4D03F] text-[#003366] font-bold py-4 px-8 rounded-full transition-all transform hover:scale-105 shadow-[0_0_20px_rgba(212,175,55,0.5)] flex items-center justify-center gap-2 group">
              Comprar Agora <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link to="/quem-somos" className="bg-transparent border-2 border-white text-white font-bold py-4 px-8 rounded-full hover:bg-white hover:text-[#003366] transition-all flex items-center justify-center">
              Conheça a Stargrowth
            </Link>
          </div>
        </motion.div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-white to-transparent z-10"></div>
    </section>
  );
};

export default HeroSection;
