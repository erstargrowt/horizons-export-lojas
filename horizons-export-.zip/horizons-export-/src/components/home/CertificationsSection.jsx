
import React from 'react';
import { motion } from 'framer-motion';
import { Lock, Shield, CheckCircle, Award, CreditCard } from 'lucide-react';

const certifications = [
  { icon: Lock, label: 'Site SSL Seguro', desc: 'Dados Criptografados' },
  { icon: CreditCard, label: 'Pagamento Seguro', desc: 'Processamento Verificado' },
  { icon: Shield, label: 'Compra Protegida', desc: 'Garantia de Entrega' },
  { icon: Award, label: 'Avaliado por Clientes', desc: 'Qualidade Comprovada' },
];

const CertificationsSection = () => {
  return (
    <section className="py-10 border-b border-gray-100 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-wrap justify-center items-center gap-8 md:gap-12">
          {certifications.map((cert, index) => {
            const Icon = cert.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex items-center gap-3 group cursor-default"
              >
                <div className="p-3 rounded-full bg-gray-50 border border-gray-100 shadow-sm group-hover:border-[#D4AF37] group-hover:bg-[#D4AF37]/10 transition-colors">
                   <Icon className="w-6 h-6 text-gray-400 group-hover:text-[#003366] transition-colors" />
                </div>
                <div>
                  <span className="block font-montserrat font-bold text-[#003366] text-sm md:text-base">
                    {cert.label}
                  </span>
                  <span className="block font-poppins text-xs text-gray-500">
                    {cert.desc}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default CertificationsSection;
