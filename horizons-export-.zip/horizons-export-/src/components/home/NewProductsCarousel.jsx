
import React, { useRef } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, Zap, ChevronLeft, ChevronRight } from 'lucide-react';
import { useCart } from '@/hooks/useCart';
import { useToast } from '@/components/ui/use-toast';
import { products } from '@/data/products';

const NewProductsCarousel = () => {
  const scrollRef = useRef(null);
  const { addToCart } = useCart();
  const { toast } = useToast();
  const newProducts = products.filter(p => p.isNew).slice(0, 8);

  const scroll = (direction) => {
    if (scrollRef.current) {
      const { current } = scrollRef;
      const scrollAmount = direction === 'left' ? -320 : 320;
      current.scrollBy({ left: scrollAmount, behavior: 'smooth' });
    }
  };

  const handleAddToCart = (product) => {
    addToCart(product);
    toast({
      title: "Adicionado!",
      description: "Produto adicionado ao carrinho com sucesso.",
      className: "bg-green-50 border-green-200",
    });
  };

  return (
    <section className="py-16 bg-gray-50 border-t border-gray-200">
      <div className="container mx-auto px-4 relative">
        <div className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-3xl font-montserrat font-bold text-[#003366] flex items-center gap-2">
              <Zap className="text-[#D4AF37] fill-[#D4AF37]" /> Lançamentos
            </h2>
            <p className="text-gray-500 mt-2">As últimas novidades chegaram na Stargrowth</p>
          </div>
          <div className="flex gap-2">
            <button onClick={() => scroll('left')} className="p-2 rounded-full border border-gray-200 hover:bg-[#003366] hover:text-white hover:border-[#003366] transition-all text-gray-500 bg-white">
              <ChevronLeft size={24} />
            </button>
            <button onClick={() => scroll('right')} className="p-2 rounded-full border border-gray-200 hover:bg-[#003366] hover:text-white hover:border-[#003366] transition-all text-gray-500 bg-white">
              <ChevronRight size={24} />
            </button>
          </div>
        </div>

        <div 
          ref={scrollRef} 
          className="flex gap-6 overflow-x-auto pb-8 scrollbar-hide snap-x snap-mandatory"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {newProducts.map((product) => (
            <div 
              key={product.id} 
              className="min-w-[280px] md:min-w-[320px] bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 border border-gray-100 snap-start flex flex-col"
            >
              <div className="relative h-60 overflow-hidden rounded-t-xl group">
                <img src={product.image} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute top-3 left-3 bg-blue-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-sm">
                  NOVO
                </div>
              </div>
              
              <div className="p-5 flex-grow flex flex-col">
                <Link to={`/produto/${product.id}`} className="block mb-2">
                  <h3 className="font-bold text-[#003366] text-lg hover:text-[#D4AF37] transition-colors line-clamp-1">
                    {product.name}
                  </h3>
                </Link>
                
                <p className="text-sm text-gray-500 line-clamp-2 mb-4 h-10">{product.description}</p>

                <div className="flex justify-between items-center mt-auto">
                  <span className="text-xl font-bold text-[#D4AF37]">R$ {product.discountPrice.toFixed(2)}</span>
                  <button 
                    onClick={() => handleAddToCart(product)}
                    className="bg-[#003366] hover:bg-[#004488] text-white px-4 py-2 rounded-lg text-sm font-bold transition-all shadow-md"
                  >
                    Comprar
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default NewProductsCarousel;
