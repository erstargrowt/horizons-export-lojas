
import React, { useState, useEffect } from 'react';
import { motion, useSpring, useTransform } from 'framer-motion';
import { Users } from 'lucide-react';

const SatisfiedCustomersCounter = () => {
  const [inView, setInView] = useState(false);
  const springValue = useSpring(0, { bounce: 0, duration: 2000 });
  const count = useTransform(springValue, (value) => Math.floor(value));

  useEffect(() => {
    if (inView) {
      springValue.set(15482);
    }
  }, [inView, springValue]);

  return (
    <section className="py-16 bg-[#003366] text-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5" style={{ backgroundImage: 'radial-gradient(circle, #ffffff 1px, transparent 1px)', backgroundSize: '30px 30px' }}></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          onViewportEnter={() => setInView(true)}
          className="bg-white/5 backdrop-blur-lg rounded-3xl p-10 border border-white/10 max-w-4xl mx-auto text-center shadow-2xl"
        >
          <div className="inline-block p-4 rounded-full bg-[#D4AF37] mb-6 shadow-[0_0_20px_rgba(212,175,55,0.5)] animate-pulse">
            <Users size={40} className="text-white" />
          </div>
          
          <h2 className="text-5xl md:text-7xl font-bold font-montserrat mb-4 tabular-nums text-transparent bg-clip-text bg-gradient-to-b from-white to-gray-400">
             <motion.span>{count}</motion.span>+
          </h2>
          
          <p className="text-xl md:text-2xl text-[#D4AF37] font-semibold mb-2">
            Clientes Satisfeitos em Todo Brasil
          </p>
          <p className="text-gray-300 font-poppins max-w-lg mx-auto">
            Junte-se à nossa comunidade crescente de clientes que escolheram qualidade, segurança e excelência.
          </p>
        </motion.div>
      </div>
    </section>
  );
};

export default SatisfiedCustomersCounter;
