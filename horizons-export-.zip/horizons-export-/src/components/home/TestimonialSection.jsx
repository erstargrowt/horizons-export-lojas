
import React from 'react';
import { motion } from 'framer-motion';
import { Quote, Star, CheckCircle2 } from 'lucide-react';

const testimonials = [
  {
    id: 1,
    name: 'João Silva',
    location: 'São Paulo, SP',
    image: 'https://images.unsplash.com/photo-1558154839-19f6ddb31384',
    rating: 5,
    text: 'Comprei pensando que era caro, mas a qualidade justifica cada centavo. O produto chegou impecável e superou minhas expectativas. Recomendo!'
  },
  {
    id: 2,
    name: 'Maria Santos',
    location: 'Rio de Janeiro, RJ',
    image: 'https://images.unsplash.com/photo-1599856413870-40540dd55110',
    rating: 5,
    text: 'Chegou rápido, bem embalado e exatamente como descrito no site. A equipe foi super atenciosa. Voltaria a comprar com certeza!'
  },
  {
    id: 3,
    name: 'Carlos Oliveira',
    location: 'Belo Horizonte, MG',
    image: 'https://images.unsplash.com/photo-1623336411935-beb214d8ce01',
    rating: 5,
    text: 'Melhor compra que fiz este ano. O suporte foi impecável quando tive uma pequena dúvida sobre o funcionamento. Empresa séria e confiável.'
  },
  {
    id: 4,
    name: 'Ana Costa',
    location: 'Curitiba, PR',
    image: 'https://images.unsplash.com/photo-1603991414220-51b87b89a371',
    rating: 5,
    text: 'Qualidade premium com preço justo. Finalmente encontrei o que procurava! O site é seguro e fácil de navegar. Já sou cliente fiel.'
  }
];

const TestimonialSection = () => {
  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-gray-100 overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <motion.h2 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-3xl md:text-4xl font-montserrat font-bold text-[#003366] mb-4"
          >
            O Que Nossos Clientes Dizem
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-gray-600 font-poppins max-w-2xl mx-auto"
          >
            Histórias reais de quem já transformou sua rotina com a qualidade Stargrowth.
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all relative border border-gray-100"
            >
              <div className="absolute top-6 right-8 text-[#D4AF37]/20">
                <Quote size={48} fill="currentColor" />
              </div>

              <div className="flex gap-1 text-yellow-400 mb-4">
                {[...Array(5)].map((_, i) => (
                   <Star key={i} size={16} fill="currentColor" />
                ))}
              </div>

              <p className="text-gray-700 font-poppins italic mb-6 leading-relaxed relative z-10 text-sm">
                "{testimonial.text}"
              </p>

              <div className="flex items-center gap-3 mt-auto border-t border-gray-100 pt-4">
                <img 
                  src={testimonial.image} 
                  alt={testimonial.name} 
                  className="w-10 h-10 rounded-full object-cover ring-2 ring-[#D4AF37]"
                />
                <div>
                  <h4 className="font-bold text-[#003366] font-montserrat text-sm">{testimonial.name}</h4>
                  <p className="text-xs text-gray-500 font-poppins">{testimonial.location}</p>
                </div>
              </div>
              
              <div className="mt-2 flex items-center gap-1 text-[10px] text-green-600 font-bold bg-green-50 w-fit px-2 py-0.5 rounded-full">
                <CheckCircle2 size={10} /> Comprador Verificado
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialSection;
