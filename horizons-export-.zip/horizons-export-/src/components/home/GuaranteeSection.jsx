
import React from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, CheckCircle2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const GuaranteeSection = () => {
  const navigate = useNavigate();

  return (
    <section className="py-20 relative overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#003366] via-[#004d99] to-[#002244]" />
      
      {/* Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden opacity-10">
         <div className="absolute top-10 left-10 w-64 h-64 rounded-full bg-white blur-3xl" />
         <div className="absolute bottom-10 right-10 w-96 h-96 rounded-full bg-[#D4AF37] blur-3xl" />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          {/* Content */}
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:w-1/2 text-white"
          >
            <div className="inline-flex items-center gap-2 bg-[#D4AF37]/20 backdrop-blur-sm border border-[#D4AF37]/30 rounded-full px-4 py-1 mb-6">
              <ShieldCheck className="text-[#D4AF37] w-5 h-5" />
              <span className="text-[#D4AF37] font-bold text-sm uppercase tracking-wider">Risco Zero</span>
            </div>
            
            <h2 className="text-3xl md:text-5xl font-montserrat font-bold mb-6 leading-tight">
              Compre com <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#D4AF37] to-[#F4D03F]">Confiança Total</span>
            </h2>
            
            <p className="text-gray-200 font-poppins text-lg mb-8 leading-relaxed">
              Sua satisfação é garantida. Se não ficar 100% satisfeito, devolvemos seu dinheiro em até 30 dias - sem perguntas, sem burocracia, apenas respeito por você.
            </p>

            <ul className="space-y-4 mb-10">
              <li className="flex items-center gap-3">
                <CheckCircle2 className="text-[#D4AF37] w-6 h-6 flex-shrink-0" />
                <span className="font-medium text-lg">Devolução Fácil - Sem burocracia</span>
              </li>
              <li className="flex items-center gap-3">
                <CheckCircle2 className="text-[#D4AF37] w-6 h-6 flex-shrink-0" />
                <span className="font-medium text-lg">Reembolso Rápido - Em até 5 dias úteis</span>
              </li>
              <li className="flex items-center gap-3">
                <CheckCircle2 className="text-[#D4AF37] w-6 h-6 flex-shrink-0" />
                <span className="font-medium text-lg">Risco Zero - Sua satisfação é nossa prioridade</span>
              </li>
            </ul>

            <motion.button
              onClick={() => navigate('/categorias')}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-gradient-to-r from-[#D4AF37] to-[#B4941F] text-[#003366] font-montserrat font-bold text-lg px-10 py-4 rounded-full shadow-[0_0_20px_rgba(212,175,55,0.4)] hover:shadow-[0_0_30px_rgba(212,175,55,0.6)] transition-all flex items-center gap-2"
            >
              <ShieldCheck className="w-5 h-5" />
              Comprar com Confiança
            </motion.button>
          </motion.div>

          {/* Image/Visual */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="lg:w-1/2 flex justify-center"
          >
            <div className="relative w-80 h-80 md:w-96 md:h-96">
               <div className="absolute inset-0 bg-gradient-to-r from-[#D4AF37] to-[#F4D03F] rounded-full opacity-20 blur-3xl animate-pulse" />
               <div className="relative bg-white/10 backdrop-blur-md border border-white/20 rounded-3xl p-8 shadow-2xl h-full flex flex-col items-center justify-center text-center">
                  <ShieldCheck size={120} className="text-[#D4AF37] mb-6 drop-shadow-lg" />
                  <h3 className="text-3xl font-bold text-white mb-2 font-montserrat">100% Seguro</h3>
                  <p className="text-gray-300 font-poppins">Garantia integral de satisfação</p>
               </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default GuaranteeSection;
