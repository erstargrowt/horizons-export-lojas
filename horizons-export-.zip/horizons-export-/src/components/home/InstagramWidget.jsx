
import React from 'react';
import { useInstagram } from '@/context/InstagramContext';
import { motion } from 'framer-motion';
import { Heart, MessageCircle, Instagram, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';

const InstagramWidget = () => {
  const { instagramState } = useInstagram();
  const { display, posts } = instagramState;

  if (!display.showOnHome) return null;

  return (
    <section className="py-16 bg-white overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="text-center mb-10">
           <div className="inline-flex items-center justify-center p-3 bg-gradient-to-tr from-purple-500 to-pink-500 rounded-full text-white mb-4 shadow-lg">
              <Instagram size={24} />
           </div>
           <h2 className="text-3xl font-montserrat font-bold text-[#003366] mb-3">@stargrowth_oficial</h2>
           <p className="text-gray-600 max-w-2xl mx-auto">{display.sectionText}</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
           {posts.slice(0, 6).map((post, index) => (
              <motion.a
                 key={post.id}
                 href={post.link}
                 target="_blank"
                 rel="noopener noreferrer"
                 initial={{ opacity: 0, y: 20 }}
                 whileInView={{ opacity: 1, y: 0 }}
                 transition={{ delay: index * 0.1 }}
                 viewport={{ once: true }}
                 className="group relative aspect-square overflow-hidden rounded-xl bg-gray-100 block"
              >
                 <img src={post.image} alt="Instagram Post" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
                 
                 <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center text-white gap-2">
                    <div className="flex gap-4">
                       <span className="flex items-center gap-1 font-bold"><Heart size={16} fill="white" /> {post.likes}</span>
                       <span className="flex items-center gap-1 font-bold"><MessageCircle size={16} fill="white" /> {post.comments}</span>
                    </div>
                    <span className="text-xs font-medium">Ver no Instagram</span>
                 </div>
              </motion.a>
           ))}
        </div>

        <div className="text-center mt-10 flex flex-col sm:flex-row gap-4 justify-center">
           <Link 
              to="/instagram-feed" 
              className="inline-flex items-center gap-2 px-6 py-3 border-2 border-[#003366] text-[#003366] font-bold rounded-full hover:bg-[#003366] hover:text-white transition-all"
           >
              Ver Galeria Completa
           </Link>
           <a 
              href="https://instagram.com" 
              target="_blank" 
              className="inline-flex items-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-bold rounded-full shadow-lg hover:shadow-xl hover:scale-105 transition-all"
           >
              <ExternalLink size={18} /> Seguir no Instagram
           </a>
        </div>
      </div>
    </section>
  );
};

export default InstagramWidget;
