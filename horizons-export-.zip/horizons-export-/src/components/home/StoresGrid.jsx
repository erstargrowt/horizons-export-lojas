
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Watch, Sparkles, Crown, Zap, Heart, Star, Cpu, Baby, BookOpen } from 'lucide-react';

const iconMap = {
  Watch,
  Sparkles,
  Crown,
  Zap,
  Heart,
  Star,
  Cpu,
  Baby,
  BookOpen,
};

const stores = [
  {
    name: 'Loja de Relógios',
    description: 'Elegância e precisão em cada modelo',
    category: 'Relógios',
    icon: 'Watch',
  },
  {
    name: 'Loja Galen',
    description: 'Cosméticos premium para sua beleza',
    category: 'Cosméticos',
    icon: 'Sparkles',
  },
  {
    name: 'Conceito Premium',
    description: 'Produtos exclusivos e sofisticados',
    category: 'Novidades',
    icon: 'Crown',
  },
  {
    name: 'Loja Falco',
    description: 'Tecnologia de ponta em eletrônicos',
    category: 'Eletrônicos',
    icon: 'Zap',
  },
  {
    name: 'Cosméticos & Bem-Estar',
    description: 'Cuidados especiais para você',
    category: 'Cosméticos',
    icon: 'Heart',
  },
  {
    name: 'Só Novidades',
    description: 'Os últimos lançamentos do mercado',
    category: 'Novidades',
    icon: 'Star',
  },
  {
    name: 'Tech & Gadgets',
    description: 'Inovação e tecnologia',
    category: 'Eletrônicos',
    icon: 'Cpu',
  },
  {
    name: 'Moda Kids',
    description: 'Diversão e aprendizado para crianças',
    category: 'Kids',
    icon: 'Baby',
  },
  {
    name: 'Biblioteca Digital',
    description: 'Conhecimento ao alcance de todos',
    category: 'eBooks',
    icon: 'BookOpen',
  },
];

const StoresGrid = () => {
  const navigate = useNavigate();

  return (
    <section className="py-12 bg-gradient-to-br from-[#003366] to-[#0055aa]">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-montserrat font-bold text-white text-center mb-8">
          Nossas Lojas Especializadas
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {stores.map((store, index) => {
            const Icon = iconMap[store.icon];
            return (
              <motion.button
                key={store.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.05, y: -5 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate(`/categorias/${store.category}`)}
                className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all text-left"
              >
                <div className="flex items-start gap-4">
                  <div className="bg-gradient-to-br from-[#D4AF37] to-[#F4D03F] rounded-full p-3">
                    <Icon className="w-6 h-6 text-[#003366]" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-montserrat font-bold text-lg text-[#003366] mb-1">
                      {store.name}
                    </h3>
                    <p className="font-poppins text-sm text-gray-600">
                      {store.description}
                    </p>
                  </div>
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default StoresGrid;
