
import React from 'react';
import { motion } from 'framer-motion';
import { Truck, ShieldCheck, MessageCircle, Lock } from 'lucide-react';

const benefits = [
  {
    icon: Truck,
    title: 'Frete Grátis',
    description: 'Compre sem preocupação - Frete Grátis acima de R$ 200 para todo o Brasil.',
    color: 'from-blue-500 to-blue-600'
  },
  {
    icon: ShieldCheck,
    title: 'Sua Satisfação é Nossa Prioridade',
    description: '30 dias para devolver - Reembolso 100% garantido sem perguntas.',
    color: 'from-amber-500 to-amber-600'
  },
  {
    icon: MessageCircle,
    title: 'Dúvidas? Estamos Aqui',
    description: 'Suporte 24h via WhatsApp para ajudar você a qualquer hora do dia.',
    color: 'from-green-500 to-green-600'
  },
  {
    icon: Lock,
    title: 'Seus Dados Protegidos',
    description: 'Criptografia bancária de ponta a ponta - Suas informações 100% seguras.',
    color: 'from-purple-500 to-purple-600'
  }
];

const BenefitsSection = () => {
  return (
    <section className="py-16 bg-white relative z-10 -mt-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <motion.div
                key={benefit.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.03 }}
                className="bg-white rounded-xl p-6 shadow-xl border border-gray-100 hover:border-[#D4AF37]/30 transition-all flex flex-col items-center text-center group"
              >
                <div className={`w-16 h-16 rounded-full bg-gradient-to-br ${benefit.color} flex items-center justify-center mb-4 text-white shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                  <Icon size={32} />
                </div>
                <h3 className="font-montserrat font-bold text-lg text-[#003366] mb-2 group-hover:text-[#D4AF37] transition-colors">{benefit.title}</h3>
                <p className="font-poppins text-sm text-gray-600 leading-relaxed">{benefit.description}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default BenefitsSection;
