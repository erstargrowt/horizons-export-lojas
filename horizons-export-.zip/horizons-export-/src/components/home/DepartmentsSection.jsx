
import React from 'react';
import { Link } from 'react-router-dom';
import { Watch, ShoppingBag, Palette, Gift, Book, Smartphone, Baby, Coffee, Headphones, Zap } from 'lucide-react';

const DepartmentsSection = () => {
  const departments = [
    { name: 'Loja Relógios', icon: Watch, link: '/categorias?category=Relógios', color: 'bg-amber-50 text-amber-600' },
    { name: 'Loja Galen', icon: ShoppingBag, link: '/categorias', color: 'bg-blue-50 text-blue-600' },
    { name: 'Conceito', icon: Palette, link: '/categorias', color: 'bg-purple-50 text-purple-600' },
    { name: 'Loja Falco', icon: Gift, link: '/categorias', color: 'bg-emerald-50 text-emerald-600' },
    { name: 'Cosméticos', icon: Palette, link: '/categorias?category=Cosméticos', color: 'bg-pink-50 text-pink-600' },
    { name: 'Só Novidades', icon: Zap, link: '/categorias?category=Novidades', color: 'bg-yellow-50 text-yellow-600' },
    { name: 'Eletrônicos', icon: Smartphone, link: '/categorias?category=Eletrônicos', color: 'bg-indigo-50 text-indigo-600' },
    { name: 'Moda Kids', icon: Baby, link: '/categorias?category=Kids', color: 'bg-cyan-50 text-cyan-600' },
    { name: 'eBooks', icon: Book, link: '/categorias?category=eBooks', color: 'bg-rose-50 text-rose-600' },
  ];

  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-montserrat font-bold text-[#003366]">Explore Nossas Lojas Especializadas</h2>
          <p className="text-gray-500 mt-4">Tudo o que você precisa em um só lugar</p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {departments.map((dept, index) => (
            <Link 
              key={index} 
              to={dept.link}
              className="flex items-center gap-4 p-6 rounded-xl border border-gray-100 hover:shadow-xl hover:border-[#D4AF37]/30 transition-all duration-300 group bg-white"
            >
              <div className={`p-4 rounded-full ${dept.color} group-hover:scale-110 transition-transform duration-300`}>
                <dept.icon size={24} />
              </div>
              <div className="flex flex-col">
                <span className="font-bold text-[#003366] text-lg group-hover:text-[#D4AF37] transition-colors">{dept.name}</span>
                <span className="text-xs text-gray-400 font-medium">Ver Produtos</span>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default DepartmentsSection;
