
import React from 'react';
import { Link } from 'react-router-dom';
import { Smartphone, Watch, Baby, Sparkles, BookOpen, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

const CategoryCarousel = () => {
  const categories = [
    { name: 'Eletrônicos', icon: Smartphone, path: '/categorias?category=Eletrônicos', color: 'bg-blue-100 text-blue-600' },
    { name: 'Relógios', icon: Watch, path: '/categorias?category=Relógios', color: 'bg-amber-100 text-amber-600' },
    { name: 'Kids', icon: Baby, path: '/categorias?category=Kids', color: 'bg-pink-100 text-pink-600' },
    { name: 'Cosméticos', icon: Sparkles, path: '/categorias?category=Cosméticos', color: 'bg-purple-100 text-purple-600' },
    { name: 'eBooks', icon: BookOpen, path: '/categorias?category=eBooks', color: 'bg-emerald-100 text-emerald-600' },
    { name: 'Novidades', icon: Zap, path: '/categorias?category=Novidades', color: 'bg-yellow-100 text-yellow-600' },
  ];

  return (
    <section className="py-12 bg-white border-b border-gray-100">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-montserrat font-bold text-[#003366] mb-8 text-center">Navegue por Categorias</h2>
        
        <div className="flex flex-wrap justify-center gap-6 md:gap-8">
          {categories.map((cat, index) => (
            <motion.div
              key={index}
              whileHover={{ y: -5, scale: 1.05 }}
              transition={{ type: "spring", stiffness: 300 }}
            >
              <Link to={cat.path} className="flex flex-col items-center gap-3 group">
                <div className={`w-20 h-20 rounded-full flex items-center justify-center ${cat.color} shadow-md group-hover:shadow-lg transition-all duration-300`}>
                  <cat.icon size={32} />
                </div>
                <span className="font-medium text-[#003366] text-sm group-hover:text-[#D4AF37] transition-colors">
                  {cat.name}
                </span>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoryCarousel;
