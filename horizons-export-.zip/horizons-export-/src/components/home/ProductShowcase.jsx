
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart, Star, Heart, Eye } from 'lucide-react';
import { useCart } from '@/hooks/useCart';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';
import { products } from '@/data/products';

const ProductShowcase = () => {
  const { addToCart } = useCart();
  const { toast } = useToast();
  const [visibleProducts, setVisibleProducts] = useState(8);
  const featuredProducts = products.slice(0, 16); // Take first 16 products

  const handleAddToCart = (product) => {
    addToCart(product);
    toast({
      title: "Produto adicionado!",
      description: `${product.name} foi adicionado ao seu carrinho.`,
      className: "bg-green-50 border-green-200",
    });
  };

  const loadMore = () => {
    setVisibleProducts(prev => Math.min(prev + 4, featuredProducts.length));
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-montserrat font-bold text-[#003366] mb-4">Ofertas em Destaque</h2>
          <div className="w-24 h-1 bg-[#D4AF37] mx-auto rounded-full"></div>
          <p className="mt-4 text-gray-600">Os melhores produtos selecionados especialmente para você.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {featuredProducts.slice(0, visibleProducts).map((product) => (
            <motion.div 
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4 }}
              className="bg-white rounded-xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden group flex flex-col h-full border border-gray-100"
            >
              {/* Product Image & Badges */}
              <div className="relative h-64 overflow-hidden bg-gray-100">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                
                {product.discount > 0 && (
                  <div className="absolute top-3 left-3 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded shadow-md animate-pulse">
                    -{product.discount}% OFF
                  </div>
                )}
                
                <div className="absolute top-3 right-3 bg-[#D4AF37] text-[#003366] text-xs font-bold px-2 py-1 rounded shadow-md flex items-center gap-1">
                  <Star size={10} fill="#003366" /> {product.rating}
                </div>

                {/* Quick Actions Overlay */}
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-4">
                  <button className="bg-white p-3 rounded-full text-[#003366] hover:text-[#D4AF37] hover:shadow-lg transition-all transform hover:scale-110" title="Ver Detalhes">
                    <Link to={`/produto/${product.id}`}><Eye size={20} /></Link>
                  </button>
                  <button className="bg-white p-3 rounded-full text-[#003366] hover:text-red-500 hover:shadow-lg transition-all transform hover:scale-110" title="Favoritar">
                    <Heart size={20} />
                  </button>
                </div>
              </div>

              {/* Product Info */}
              <div className="p-5 flex-grow flex flex-col">
                <div className="text-xs text-gray-500 mb-1 uppercase tracking-wide">{product.category}</div>
                <Link to={`/produto/${product.id}`} className="block">
                  <h3 className="font-bold text-[#003366] text-lg mb-2 line-clamp-2 hover:text-[#D4AF37] transition-colors h-14">
                    {product.name}
                  </h3>
                </Link>
                
                <div className="flex items-center gap-2 mb-4 mt-auto">
                  <span className="text-gray-400 line-through text-sm">
                    R$ {product.originalPrice.toFixed(2).replace('.', ',')}
                  </span>
                  <span className="text-2xl font-bold text-[#D4AF37]">
                    R$ {product.discountPrice.toFixed(2).replace('.', ',')}
                  </span>
                </div>

                <div className="grid grid-cols-5 gap-2 mt-auto">
                  <button 
                    onClick={() => handleAddToCart(product)}
                    className="col-span-4 bg-[#003366] hover:bg-[#004488] text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2 transition-colors shadow-md hover:shadow-lg text-sm"
                  >
                    <ShoppingCart size={18} /> Comprar Agora
                  </button>
                  <button 
                    onClick={() => handleAddToCart(product)}
                    className="col-span-1 border-2 border-[#003366]/20 hover:border-[#D4AF37] hover:bg-[#D4AF37]/10 text-[#003366] rounded-lg flex items-center justify-center transition-all"
                  >
                    +
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {visibleProducts < featuredProducts.length && (
          <div className="text-center mt-12">
            <button 
              onClick={loadMore}
              className="bg-transparent border-2 border-[#003366] text-[#003366] hover:bg-[#003366] hover:text-white font-bold py-3 px-8 rounded-full transition-all uppercase tracking-wider text-sm"
            >
              Carregar Mais Ofertas
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

export default ProductShowcase;
