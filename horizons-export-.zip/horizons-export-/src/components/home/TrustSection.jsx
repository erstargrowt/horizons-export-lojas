
import React from 'react';
import { ShieldCheck, Truck, ThumbsUp, MessageCircle } from 'lucide-react';
import { motion } from 'framer-motion';

const TrustSection = () => {
  const features = [
    {
      icon: ShieldCheck,
      title: "Pagamento 100% Seguro",
      description: "Seus dados estão protegidos com criptografia SSL de ponta a ponta."
    },
    {
      icon: Truck,
      title: "Frete Grátis",
      description: "Em todas as compras acima de R$ 200,00 para todo o Brasil."
    },
    {
      icon: ThumbsUp,
      title: "Garantia de Satisfação",
      description: "Não gostou? Você tem até 7 dias para devolver gratuitamente."
    },
    {
      icon: MessageCircle,
      title: "Suporte 24/7",
      description: "Atendimento personalizado via WhatsApp a qualquer hora."
    }
  ];

  return (
    <section className="py-16 bg-[#003366] text-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((item, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.5 }}
              className="flex flex-col items-center text-center p-6 bg-white/5 rounded-xl backdrop-blur-sm hover:bg-white/10 transition-colors border border-white/10"
            >
              <div className="w-16 h-16 bg-[#D4AF37] text-[#003366] rounded-full flex items-center justify-center mb-4 shadow-lg">
                <item.icon size={32} />
              </div>
              <h3 className="font-bold text-lg mb-2 text-[#D4AF37]">{item.title}</h3>
              <p className="text-gray-300 text-sm leading-relaxed">{item.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrustSection;
