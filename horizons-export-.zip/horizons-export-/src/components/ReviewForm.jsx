
import React, { useState } from 'react';
import { Star, Send } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { motion } from 'framer-motion';

const ReviewForm = ({ productId, onReviewSubmit }) => {
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [title, setTitle] = useState('');
  const [comment, setComment] = useState('');
  const [recommend, setRecommend] = useState(true);
  const [name, setName] = useState('');
  const { toast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (rating === 0) {
      toast({ title: "Avaliação necessária", description: "Por favor, selecione uma nota de 1 a 5 estrelas.", variant: "destructive" });
      return;
    }

    const newReview = {
      id: Date.now(),
      productId,
      rating,
      title,
      comment,
      recommend,
      author: name || 'Cliente Stargrowth',
      date: new Date().toISOString(),
      verified: true, // Simulation
      helpful: 0,
      notHelpful: 0
    };

    onReviewSubmit(newReview);
    
    // Reset form
    setRating(0);
    setTitle('');
    setComment('');
    setName('');
    setRecommend(true);

    toast({ 
      title: "Avaliação enviada!", 
      description: "Obrigado por compartilhar sua opinião.", 
      className: "bg-green-50 border-green-200 text-green-800"
    });
  };

  return (
    <form onSubmit={handleSubmit} className="bg-gray-50 p-6 rounded-xl border border-gray-200 mb-8">
      <h3 className="text-lg font-bold text-[#003366] mb-4">Deixe sua avaliação</h3>
      
      {/* Stars */}
      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-2">Sua Nota</label>
        <div className="flex gap-1">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              className="focus:outline-none transition-transform hover:scale-110"
              onMouseEnter={() => setHoverRating(star)}
              onMouseLeave={() => setHoverRating(0)}
              onClick={() => setRating(star)}
            >
              <Star 
                className={`w-8 h-8 ${star <= (hoverRating || rating) ? 'fill-[#D4AF37] text-[#D4AF37]' : 'text-gray-300'}`} 
              />
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
         <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Seu Nome</label>
            <input 
              type="text" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none"
              placeholder="Ex: Maria Silva"
              required
            />
         </div>
         <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Título da Avaliação</label>
            <input 
              type="text" 
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none"
              placeholder="Ex: Adorei o produto!"
              required
            />
         </div>
      </div>

      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-700 mb-1">Seu Comentário</label>
        <textarea 
          value={comment}
          onChange={(e) => setComment(e.target.value)}
          rows="4"
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-[#D4AF37] focus:border-[#D4AF37] outline-none"
          placeholder="Conte-nos mais sobre sua experiência..."
          required
        ></textarea>
      </div>

      <div className="flex items-center gap-2 mb-6">
        <input 
          type="checkbox" 
          id="recommend"
          checked={recommend}
          onChange={(e) => setRecommend(e.target.checked)}
          className="rounded text-[#003366] focus:ring-[#003366]"
        />
        <label htmlFor="recommend" className="text-sm text-gray-700">Recomendo este produto</label>
      </div>

      <motion.button 
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        type="submit"
        className="bg-[#003366] text-white font-bold py-3 px-8 rounded-lg flex items-center gap-2 hover:bg-[#004d99] transition-colors"
      >
        <Send size={18} /> Enviar Avaliação
      </motion.button>
    </form>
  );
};

export default ReviewForm;
