
import React, { useState } from 'react';
import { Outlet, Link, useNavigate, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { LayoutDashboard, Ticket, Mail, Megaphone, BarChart3, LogOut, Menu, X, ShoppingBag, Bell, Instagram, MessageCircle, Settings, MessageSquare, TrendingUp } from 'lucide-react';
import { useAdminAuth } from '@/context/AdminAuthContext';

const AdminLayout = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const { logout } = useAdminAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    logout();
    navigate('/admin/login');
  };

  const menuItems = [
    { path: '/admin/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { path: '/admin/chat', icon: MessageCircle, label: 'Chat Suporte' },
    { path: '/admin/notificacoes', icon: Bell, label: 'Notificações' },
    { path: '/admin/instagram', icon: Instagram, label: 'Instagram' },
    { path: '/admin/cupons', icon: Ticket, label: 'Cupons' },
    { path: '/admin/emails', icon: Mail, label: 'Emails' },
    { path: '/admin/campanhas', icon: Megaphone, label: 'Campanhas' },
    { path: '/admin/analytics', icon: BarChart3, label: 'Analytics' },
    
    // New Menu Items
    { path: '/admin/analytics-config', icon: TrendingUp, label: 'Config. GA4' },
    { path: '/admin/chatbot-config', icon: MessageSquare, label: 'Config. Chatbot' },
    { path: '/admin/chatbot-history', icon: MessageCircle, label: 'Histórico IA' },
    { path: '/admin/chatbot-analytics', icon: BarChart3, label: 'Analytics IA' },
    { path: '/admin/chat-config', icon: Settings, label: 'Config. Chat' },
  ];

  return (
    <div className="min-h-screen bg-gray-100 flex">
      {/* Sidebar */}
      <AnimatePresence mode="wait">
        {(isSidebarOpen || window.innerWidth >= 768) && (
          <motion.aside
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: 260, opacity: 1 }}
            exit={{ width: 0, opacity: 0 }}
            className={`bg-[#0a66c2] text-white h-screen fixed md:sticky top-0 left-0 z-40 overflow-hidden flex flex-col shadow-xl`}
          >
            <div className="p-6 flex items-center justify-between">
              <div className="flex items-center gap-2 font-montserrat font-bold text-xl">
                <div className="w-8 h-8 bg-[#D4AF37] rounded-full flex items-center justify-center text-[#0a66c2]">S</div>
                <span className="text-[#D4AF37]">Admin</span>
              </div>
              <button onClick={() => setIsSidebarOpen(false)} className="md:hidden">
                <X />
              </button>
            </div>

            <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto custom-scrollbar">
              {menuItems.map((item) => (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                    location.pathname === item.path
                      ? 'bg-[#D4AF37] text-[#0a66c2] font-bold shadow-md'
                      : 'text-gray-300 hover:bg-white/10 hover:text-white'
                  }`}
                >
                  <item.icon size={20} />
                  <span>{item.label}</span>
                </Link>
              ))}
            </nav>

            <div className="p-4 border-t border-white/10">
              <button
                onClick={handleLogout}
                className="flex items-center gap-3 px-4 py-3 w-full rounded-lg text-red-300 hover:bg-red-500/20 hover:text-red-200 transition-all"
              >
                <LogOut size={20} />
                <span>Sair</span>
              </button>
            </div>
          </motion.aside>
        )}
      </AnimatePresence>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="bg-white shadow-sm h-16 flex items-center justify-between px-6 sticky top-0 z-30">
          <div className="flex items-center gap-4">
            <button onClick={() => setIsSidebarOpen(!isSidebarOpen)} className="text-[#0a66c2] p-2 hover:bg-gray-100 rounded-lg">
              <Menu size={24} />
            </button>
            <h1 className="font-montserrat font-bold text-[#0a66c2] text-lg hidden sm:block">
              Painel Administrativo
            </h1>
          </div>
          <div className="flex items-center gap-4">
             <Link to="/" target="_blank" className="text-sm font-medium text-gray-500 hover:text-[#0a66c2] flex items-center gap-2">
                <ShoppingBag size={16} /> Ver Loja
             </Link>
             <div className="w-8 h-8 bg-gray-200 rounded-full flex items-center justify-center font-bold text-[#0a66c2]">
                A
             </div>
          </div>
        </header>

        <main className="flex-1 p-6 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
