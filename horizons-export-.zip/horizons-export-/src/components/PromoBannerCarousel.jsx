
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, ShoppingBag } from 'lucide-react';
import { Link } from 'react-router-dom';

const offers = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1641803216631-47d43eb4f35e',
    title: 'Eletrônicos Premium',
    subtitle: 'Tecnologia de ponta para você',
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1560884124-6ad1e0cdf737',
    title: 'Nova Coleção de Relógios',
    subtitle: 'Elegância em cada segundo',
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1695956079230-7f7064d82294',
    title: 'Beleza & Cuidados',
    subtitle: 'Realce sua beleza natural',
  },
  {
    id: 4,
    image: 'https://images.unsplash.com/photo-1662063386711-4ea396cccebf',
    title: 'Moda Exclusiva',
    subtitle: 'Estilo que define você',
  },
  {
    id: 5,
    image: 'https://images.unsplash.com/photo-1700843699012-0dadd2089fe4',
    title: 'Acessórios Modernos',
    subtitle: 'Detalhes que fazem a diferença',
  },
  {
    id: 6,
    image: 'https://images.unsplash.com/photo-1527264935190-1401c51b5bbc',
    title: 'Ofertas Imperdíveis',
    subtitle: 'Descontos de até 50%',
  },
  {
    id: 7,
    image: 'https://images.unsplash.com/photo-1700847304964-9fe563059742',
    title: 'Lançamentos 2026',
    subtitle: 'O futuro chegou',
  },
  {
    id: 8,
    image: 'https://images.unsplash.com/photo-1563593047639-972f98366493',
    title: 'Perfumes Importados',
    subtitle: 'Fragrâncias marcantes',
  },
  {
    id: 9,
    image: 'https://images.unsplash.com/photo-1611403570720-162d8829689a',
    title: 'Smart Home',
    subtitle: 'Conectividade total',
  },
  {
    id: 10,
    image: 'https://images.unsplash.com/photo-1574079771556-f09a65db11e0',
    title: 'Edição Limitada',
    subtitle: 'Garanta o seu agora',
  },
];

const PromoBannerCarousel = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setDirection(1);
      setCurrentIndex((prev) => (prev + 1) % offers.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const slideVariants = {
    enter: (direction) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0,
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1,
    },
    exit: (direction) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0,
    }),
  };

  const swipe = (newDirection) => {
    setDirection(newDirection);
    setCurrentIndex((prev) => {
      if (newDirection === 1) return (prev + 1) % offers.length;
      return (prev - 1 + offers.length) % offers.length;
    });
  };

  return (
    <div className="relative w-full overflow-hidden bg-gray-900 group h-[50vh] md:h-[60vh] lg:h-[70vh]">
      <AnimatePresence initial={false} custom={direction}>
        <motion.div
          key={currentIndex}
          custom={direction}
          variants={slideVariants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{
            x: { type: "spring", stiffness: 300, damping: 30 },
            opacity: { duration: 0.2 },
          }}
          className="absolute inset-0 w-full h-full"
        >
          {/* Image with zoom effect */}
          <motion.div 
            className="w-full h-full"
            initial={{ scale: 1 }}
            animate={{ scale: 1.05 }}
            transition={{ duration: 6, ease: "linear" }}
          >
             <img
              src={offers[currentIndex].image}
              alt={offers[currentIndex].title}
              className="w-full h-full object-cover opacity-70"
            />
          </motion.div>
          
          <div className="absolute inset-0 bg-gradient-to-t from-[#0a66c2]/80 via-transparent to-transparent" />
          
          <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4">
            <motion.h2 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="text-3xl md:text-5xl lg:text-6xl font-montserrat font-bold text-white mb-4 drop-shadow-lg"
            >
              {offers[currentIndex].title}
            </motion.h2>
            <motion.p 
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="text-lg md:text-xl text-gray-200 mb-8 font-poppins drop-shadow-md"
            >
              {offers[currentIndex].subtitle}
            </motion.p>
            <motion.div
               initial={{ y: 20, opacity: 0 }}
               animate={{ y: 0, opacity: 1 }}
               transition={{ delay: 0.4 }}
            >
              <Link 
                to="/categorias"
                className="bg-[#D4AF37] hover:bg-[#b5952f] text-[#0a66c2] font-bold py-3 px-8 rounded-full flex items-center gap-2 transform transition-all shadow-lg hover:shadow-[#D4AF37]/50"
              >
                <motion.span
                  animate={{ scale: [1, 1.1, 1] }}
                  transition={{ repeat: Infinity, duration: 1.5 }}
                >
                  Comprar Agora
                </motion.span>
                <ShoppingBag size={20} />
              </Link>
            </motion.div>
          </div>
        </motion.div>
      </AnimatePresence>

      {/* Navigation Buttons */}
      <button
        onClick={() => swipe(-1)}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-10 bg-white/10 hover:bg-white/30 backdrop-blur-sm p-3 rounded-full text-white transition-all opacity-0 group-hover:opacity-100"
      >
        <ChevronLeft size={24} />
      </button>
      <button
        onClick={() => swipe(1)}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-10 bg-white/10 hover:bg-white/30 backdrop-blur-sm p-3 rounded-full text-white transition-all opacity-0 group-hover:opacity-100"
      >
        <ChevronRight size={24} />
      </button>

      {/* Dots */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10 flex gap-2">
        {offers.map((_, index) => (
          <button
            key={index}
            onClick={() => {
              setDirection(index > currentIndex ? 1 : -1);
              setCurrentIndex(index);
            }}
            className={`w-3 h-3 rounded-full transition-all ${
              index === currentIndex
                ? 'bg-[#D4AF37] w-8'
                : 'bg-white/50 hover:bg-white/80'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

export default PromoBannerCarousel;
