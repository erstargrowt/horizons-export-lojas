
import React from 'react';
import { Lock, ShieldCheck, Phone } from 'lucide-react';

const TopBar = () => {
  return (
    <div className="bg-[#0a66c2] text-white py-2 px-4 text-xs font-medium sticky top-0 z-50">
      <div className="container mx-auto flex flex-col sm:flex-row justify-between items-center gap-2 text-center sm:text-left">
        <div className="flex items-center gap-4">
          <span className="text-[#D4AF37] font-bold">Frete Grátis acima de R$ 200</span>
        </div>
        
        <div className="flex flex-wrap justify-center gap-4 sm:gap-6">
          <div className="flex items-center gap-1.5">
            <Lock size={12} className="text-[#D4AF37]" />
            <span>Site Criptografado</span>
          </div>
          <div className="flex items-center gap-1.5">
            <ShieldCheck size={12} className="text-[#D4AF37]" />
            <span>Pagamento Seguro</span>
          </div>
          <a href="https://wa.me/5527999999999" target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 hover:text-[#D4AF37] transition-colors">
            <Phone size={12} className="text-[#D4AF37]" />
            <span>(27) 99999-9999</span>
          </a>
        </div>
      </div>
    </div>
  );
};

export default TopBar;
