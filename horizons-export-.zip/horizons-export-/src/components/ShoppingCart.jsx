
import React, { useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart as ShoppingCartIcon, X, Plus, Minus, Trash2, ArrowRight } from 'lucide-react';
import { useCart } from '@/hooks/useCart';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';

const ShoppingCartSidebar = ({ isCartOpen, setIsCartOpen }) => {
  const navigate = useNavigate();
  const { cartItems, removeFromCart, updateQuantity, getCartTotal } = useCart();

  const handleCheckout = () => {
    setIsCartOpen(false);
    navigate('/checkout');
  };

  return (
    <AnimatePresence>
      {isCartOpen && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 z-[60] backdrop-blur-sm"
            onClick={() => setIsCartOpen(false)}
          />

          {/* Sidebar */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="fixed inset-y-0 right-0 z-[70] w-full max-w-md bg-white shadow-2xl flex flex-col font-poppins"
          >
            {/* Header */}
            <div className="p-5 border-b border-gray-100 flex items-center justify-between bg-white">
              <h2 className="text-xl font-bold text-[#003366] flex items-center gap-2">
                <ShoppingCartIcon size={20} /> Seu Carrinho
              </h2>
              <button 
                onClick={() => setIsCartOpen(false)}
                className="p-2 hover:bg-gray-100 rounded-full text-gray-500 transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            {/* Items */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {cartItems.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center text-gray-400">
                  <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mb-4">
                    <ShoppingCartIcon size={40} className="text-gray-300" />
                  </div>
                  <p className="font-medium text-gray-600 mb-2">Seu carrinho está vazio</p>
                  <p className="text-sm">Explore nossa loja e encontre produtos incríveis.</p>
                  <Button 
                    onClick={() => { setIsCartOpen(false); navigate('/'); }}
                    className="mt-6 bg-[#0a66c2] text-white"
                  >
                    Começar a Comprar
                  </Button>
                </div>
              ) : (
                cartItems.map((item) => (
                  <motion.div 
                    layout
                    key={item.variant.id} 
                    className="flex gap-4 p-3 border border-gray-100 rounded-xl hover:border-gray-200 transition-colors"
                  >
                    <div className="w-20 h-20 bg-gray-50 rounded-lg overflow-hidden flex-shrink-0">
                      <img src={item.product.image} alt={item.product.title} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 flex flex-col justify-between">
                      <div>
                        <h3 className="font-bold text-gray-800 text-sm line-clamp-2 leading-snug">{item.product.title}</h3>
                        <p className="text-xs text-gray-500 mt-1">{item.variant.title}</p>
                      </div>
                      <div className="flex items-center justify-between mt-2">
                         <div className="font-bold text-[#0a66c2] text-sm">{item.variant.sale_price_formatted}</div>
                         <div className="flex items-center gap-2">
                            <div className="flex items-center bg-gray-50 rounded-lg h-7">
                               <button onClick={() => updateQuantity(item.variant.id, item.quantity - 1)} className="px-2 h-full hover:bg-gray-200 rounded-l-lg text-gray-600 flex items-center"><Minus size={12} /></button>
                               <span className="text-xs font-bold w-6 text-center">{item.quantity}</span>
                               <button onClick={() => updateQuantity(item.variant.id, item.quantity + 1)} className="px-2 h-full hover:bg-gray-200 rounded-r-lg text-gray-600 flex items-center"><Plus size={12} /></button>
                            </div>
                            <button onClick={() => removeFromCart(item.variant.id)} className="text-gray-400 hover:text-red-500 transition-colors">
                               <Trash2 size={16} />
                            </button>
                         </div>
                      </div>
                    </div>
                  </motion.div>
                ))
              )}
            </div>

            {/* Footer */}
            {cartItems.length > 0 && (
              <div className="p-6 border-t border-gray-100 bg-gray-50">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-gray-600 font-medium">Subtotal</span>
                  <span className="text-xl font-bold text-[#003366]">{getCartTotal()}</span>
                </div>
                <div className="space-y-3">
                   <Button 
                     onClick={handleCheckout} 
                     className="w-full bg-[#0a66c2] hover:bg-[#004182] text-white py-6 rounded-xl text-lg font-bold shadow-lg hover:shadow-xl transition-all flex items-center justify-center gap-2"
                   >
                     Finalizar Compra <ArrowRight size={18} />
                   </Button>
                   <Button 
                     variant="ghost" 
                     onClick={() => setIsCartOpen(false)}
                     className="w-full text-gray-500 hover:text-[#003366]"
                   >
                     Continuar Comprando
                   </Button>
                </div>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

export default ShoppingCartSidebar;
