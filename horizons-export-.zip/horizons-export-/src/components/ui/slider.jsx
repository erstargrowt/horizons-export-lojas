
import React from 'react';

export const Slider = ({ 
  value = [0, 100], 
  min = 0, 
  max = 100, 
  step = 1, 
  onValueChange,
  defaultValue,
  className = ''
}) => {
  const currentValue = value || defaultValue || [min, max];
  const [isDragging, setIsDragging] = React.useState(null);

  const handleMouseDown = (index) => {
    setIsDragging(index);
  };

  const handleMouseUp = () => {
    setIsDragging(null);
  };

  const handleMouseMove = (e) => {
    if (isDragging === null) return;

    const slider = e.currentTarget;
    const rect = slider.getBoundingClientRect();
    const percent = (e.clientX - rect.left) / rect.width;
    const newValue = Math.round((percent * (max - min) + min) / step) * step;
    const clampedValue = Math.max(min, Math.min(max, newValue));

    const newValues = [...currentValue];
    newValues[isDragging] = clampedValue;

    if (isDragging === 0 && newValues[0] > newValues[1]) {
      newValues[0] = newValues[1];
    } else if (isDragging === 1 && newValues[1] < newValues[0]) {
      newValues[1] = newValues[0];
    }

    onValueChange?.(newValues);
  };

  const getPercentage = (val) => ((val - min) / (max - min)) * 100;

  return (
    <div 
      className={`relative w-full h-2 bg-gray-200 rounded-lg cursor-pointer select-none ${className}`}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      <div
        className="absolute h-full bg-[#003366] rounded-lg"
        style={{
          left: `${getPercentage(currentValue[0])}%`,
          right: `${100 - getPercentage(currentValue[1])}%`
        }}
      />
      
      {currentValue.map((val, index) => (
        <div
          key={index}
          className="absolute w-5 h-5 bg-white border-2 border-[#003366] rounded-full top-1/2 transform -translate-y-1/2 -translate-x-1/2 cursor-grab active:cursor-grabbing shadow-md hover:shadow-lg transition-shadow"
          style={{ left: `${getPercentage(val)}%` }}
          onMouseDown={() => handleMouseDown(index)}
        />
      ))}
    </div>
  );
};

export default Slider;
