
import React from 'react';
import { Link } from 'react-router-dom';
import { MessageCircle, Mail, Facebook, Instagram, Linkedin, MapPin, Twitter, Lock, CreditCard } from 'lucide-react';
import Logo from '@/components/Logo';

const Footer = () => {
  return (
    <footer className="bg-[#0a66c2] text-white mt-16 border-t-8 border-[#D4AF37]">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand & Social */}
          <div>
            <div className="flex items-center gap-2 mb-6 text-white">
              {/* Using a custom light version of logo for dark bg if needed, but the original logo component has gradient text. 
                  Let's re-implement logo visual here for better contrast or just use text if Logo component doesn't look good on blue.
                  The Logo component uses dark text gradient. Let's just use white text here to match design.
              */}
               <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-md border-2 border-[#D4AF37] overflow-hidden">
                 <img src="https://images.unsplash.com/photo-1640190213120-cc920c9c39f4" alt="Logo" className="w-full h-full object-cover" />
               </div>
               <h3 className="text-2xl font-montserrat font-bold text-white">
                  Stargrowth
               </h3>
            </div>
            <p className="text-sm text-gray-100 font-poppins mb-8 leading-relaxed">
              Transformando vidas e negócios através de conhecimento, inovação e oportunidades. Junte-se à nossa comunidade de líderes e visionários.
            </p>
            <div className="flex gap-4">
               <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-[#D4AF37] hover:text-[#0a66c2] transition-all"><Facebook size={20} /></a>
               <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-[#D4AF37] hover:text-[#0a66c2] transition-all"><Instagram size={20} /></a>
               <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-[#D4AF37] hover:text-[#0a66c2] transition-all"><Linkedin size={20} /></a>
               <a href="#" className="bg-white/10 p-2 rounded-full hover:bg-[#D4AF37] hover:text-[#0a66c2] transition-all"><Twitter size={20} /></a>
            </div>
          </div>

          {/* Links 1 */}
          <div>
            <h4 className="text-lg font-bold text-[#D4AF37] mb-6 font-montserrat">Explorar</h4>
            <ul className="space-y-3 text-sm font-poppins">
              <li><Link to="/negocio-stargrowth" className="text-gray-100 hover:text-white hover:underline transition-colors">Negócio Stargrowth</Link></li>
              <li><Link to="/plano-de-negocio" className="text-gray-100 hover:text-white hover:underline transition-colors">Plano de Negócio</Link></li>
              <li><Link to="/treinamentos-para-executivos" className="text-gray-100 hover:text-white hover:underline transition-colors">Treinamentos</Link></li>
              <li><Link to="/documentos" className="text-gray-100 hover:text-white hover:underline transition-colors">Documentos</Link></li>
              <li><Link to="/sobre-nos" className="text-gray-100 hover:text-white hover:underline transition-colors">Sobre Nós</Link></li>
              <li><Link to="/idealizador-fundador" className="text-gray-100 hover:text-white hover:underline transition-colors">Idealizador</Link></li>
            </ul>
          </div>

          {/* Links 2 */}
          <div>
             <h4 className="text-lg font-bold text-[#D4AF37] mb-6 font-montserrat">Legal & Suporte</h4>
             <ul className="space-y-3 text-sm font-poppins">
               <li><Link to="/politica-de-privacidade" className="text-gray-100 hover:text-white hover:underline transition-colors">Política de Privacidade</Link></li>
               <li><Link to="/termos-e-condicoes" className="text-gray-100 hover:text-white hover:underline transition-colors">Termos de Uso</Link></li>
               <li><Link to="/reembolso-devolucoes" className="text-gray-100 hover:text-white hover:underline transition-colors">Reembolso e Devoluções</Link></li>
               <li><Link to="/termos-e-condicoes-executivo" className="text-gray-100 hover:text-white hover:underline transition-colors">Termos Executivo</Link></li>
               <li><Link to="/financas" className="text-gray-100 hover:text-white hover:underline transition-colors">Finanças</Link></li>
               <li><Link to="/faq" className="text-gray-100 hover:text-white hover:underline transition-colors">FAQ</Link></li>
             </ul>
          </div>

          {/* Contact & Newsletter */}
          <div>
            <h4 className="text-lg font-bold text-[#D4AF37] mb-6 font-montserrat">Contato</h4>
            <ul className="space-y-4 text-sm font-poppins mb-8">
               <li className="flex items-start gap-3">
                  <MapPin className="text-[#D4AF37] w-5 h-5 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-100">Av. Paulista, 1000 - Bela Vista<br/>São Paulo - SP, Brasil</span>
               </li>
               <li className="flex items-center gap-3">
                  <Mail className="text-[#D4AF37] w-5 h-5 flex-shrink-0" />
                  <span className="text-gray-100">contato@stargrowth.com.br</span>
               </li>
            </ul>
            
            <h5 className="font-bold text-white mb-3 text-sm">Inscreva-se na Newsletter</h5>
            <div className="flex">
               <input type="email" placeholder="Seu melhor email" className="bg-white/10 border border-white/20 rounded-l-lg px-4 py-2 text-sm text-white focus:outline-none w-full placeholder-gray-300" />
               <button className="bg-[#D4AF37] hover:bg-[#F4D03F] text-[#0a66c2] font-bold px-4 py-2 rounded-r-lg transition-colors">
                  OK
               </button>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 mt-16 pt-8 flex flex-col md:flex-row justify-between items-center gap-6">
           <div className="flex flex-col items-center md:items-start gap-2">
              <span className="text-xs text-gray-300 font-bold uppercase tracking-wider">Métodos de Pagamento</span>
              <div className="flex gap-3 text-gray-200">
                 <CreditCard /> 
                 <span className="text-xs border border-gray-400 rounded px-2 py-0.5 font-bold">PIX</span>
                 <span className="text-xs border border-gray-400 rounded px-2 py-0.5 font-bold">BOLETO</span>
              </div>
           </div>
           
           <div className="text-center md:text-right">
             <p className="text-sm text-gray-300">© {new Date().getFullYear()} Stargrowth. Todos os direitos reservados.</p>
             <p className="text-xs text-gray-400 mt-1">CNPJ: 12.345.678/0001-90</p>
           </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
