
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Check, Trash2, AlertCircle } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { products } from '@/data/products';

const ComparisonModal = ({ product, isOpen, onClose }) => {
  const [compareList, setCompareList] = useState([]);
  const { toast } = useToast();

  useEffect(() => {
    const saved = localStorage.getItem('stargrowth_compare');
    if (saved) {
      setCompareList(JSON.parse(saved));
    }
  }, []);

  const addToCompare = () => {
    if (compareList.find(p => p.id === product.id)) {
      toast({ title: "Já está na lista", description: "Este produto já foi adicionado à comparação." });
      return;
    }
    
    if (compareList.length >= 3) {
      toast({ title: "Limite atingido", description: "Você pode comparar no máximo 3 produtos." });
      return;
    }

    const newList = [...compareList, product];
    setCompareList(newList);
    localStorage.setItem('stargrowth_compare', JSON.stringify(newList));
    toast({ title: "Adicionado à comparação", className: "bg-green-50 border-green-200 text-green-800" });
  };

  const removeFromCompare = (id) => {
    const newList = compareList.filter(p => p.id !== id);
    setCompareList(newList);
    localStorage.setItem('stargrowth_compare', JSON.stringify(newList));
  };

  if (!isOpen) return null;

  // Simple modal just to manage comparison list state for now, 
  // normally would be a side drawer or a full modal
  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/50 backdrop-blur-sm p-4" onClick={onClose}>
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-auto p-6"
          onClick={e => e.stopPropagation()}
        >
          <div className="flex justify-between items-center mb-6 border-b pb-4">
            <h2 className="text-2xl font-montserrat font-bold text-[#003366]">Comparar Produtos</h2>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-colors">
              <X className="w-6 h-6 text-gray-500" />
            </button>
          </div>

          {compareList.length === 0 ? (
             <div className="text-center py-12">
               <AlertCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
               <p className="text-gray-500 mb-4">Sua lista de comparação está vazia.</p>
               <button 
                 onClick={addToCompare}
                 className="bg-[#003366] text-white px-6 py-2 rounded-lg font-medium hover:bg-[#004d99] transition-colors"
               >
                 Adicionar {product.name} à lista
               </button>
             </div>
          ) : (
            <>
               <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                 {compareList.map(item => (
                   <div key={item.id} className="border rounded-xl p-4 relative bg-gray-50">
                     <button 
                       onClick={() => removeFromCompare(item.id)}
                       className="absolute top-2 right-2 p-1.5 bg-white rounded-full text-red-500 hover:bg-red-50 transition-colors shadow-sm"
                     >
                       <Trash2 className="w-4 h-4" />
                     </button>
                     <img src={item.image} alt={item.name} className="w-24 h-24 object-cover rounded-md mx-auto mb-3" />
                     <h3 className="font-bold text-sm text-center mb-2 line-clamp-2 text-[#003366]">{item.name}</h3>
                     <p className="text-center font-bold text-[#D4AF37]">R$ {item.discountPrice.toFixed(2)}</p>
                     
                     <div className="mt-4 text-xs space-y-2">
                       <div className="flex justify-between border-b pb-1">
                         <span className="text-gray-500">Avaliação</span>
                         <span className="font-medium">{item.rating} ★</span>
                       </div>
                       <div className="flex justify-between border-b pb-1">
                         <span className="text-gray-500">Estoque</span>
                         <span className="font-medium">{item.stock} un.</span>
                       </div>
                       <div className="flex justify-between border-b pb-1">
                         <span className="text-gray-500">Categoria</span>
                         <span className="font-medium">{item.category}</span>
                       </div>
                     </div>
                   </div>
                 ))}
                 
                 {/* Slot to add current product if not in list and space available */}
                 {compareList.length < 3 && !compareList.find(p => p.id === product.id) && (
                   <div className="border-2 border-dashed border-gray-300 rounded-xl p-4 flex flex-col items-center justify-center bg-gray-50/50 min-h-[200px]">
                      <p className="text-sm text-gray-500 mb-3 text-center">Adicione o produto atual para comparar</p>
                      <button 
                        onClick={addToCompare}
                        className="bg-[#D4AF37] text-white px-4 py-2 rounded-lg text-sm font-bold hover:bg-[#c4a030] transition-colors flex items-center gap-2"
                      >
                        <Check className="w-4 h-4" /> Adicionar
                      </button>
                   </div>
                 )}
               </div>
            </>
          )}

          <div className="flex justify-end pt-4 border-t">
            <button 
              onClick={onClose}
              className="text-gray-500 font-medium hover:text-[#003366] transition-colors"
            >
              Fechar
            </button>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default ComparisonModal;
