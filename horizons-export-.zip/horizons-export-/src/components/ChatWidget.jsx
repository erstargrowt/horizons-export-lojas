
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MessageCircle, X, Send, Minus } from 'lucide-react';
import { useChat } from '@/context/ChatContext';
import { useGoogleAnalytics } from '@/context/GoogleAnalyticsContext';

const ChatWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');
  const [activeConvId, setActiveConvId] = useState(null);
  const messagesEndRef = useRef(null);
  
  const { chatState, createConversation, addMessage } = useChat();
  const { trackEvent } = useGoogleAnalytics();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatState.conversations, isOpen]);

  const handleToggle = () => {
    if (!isOpen) {
      trackEvent('chat_open');
    }
    setIsOpen(!isOpen);
  };

  const handleSend = (e) => {
    e.preventDefault();
    if (!message.trim()) return;

    trackEvent('chat_message_sent');

    let convId = activeConvId;
    if (!convId) {
      // Simulate creating conversation for guest
      convId = createConversation({
        clientId: 'guest_' + Date.now(),
        clientName: 'Visitante',
        clientEmail: '',
        clientPhone: ''
      });
      setActiveConvId(convId);
    }
    
    addMessage(convId, message, 'client');
    setMessage('');
  };

  const activeConversation = chatState.conversations.find(c => c.id === activeConvId);

  if (!chatState.config.active) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="absolute bottom-16 right-0 w-[350px] h-[500px] bg-white rounded-2xl shadow-2xl overflow-hidden flex flex-col border border-gray-200"
          >
            {/* Header */}
            <div className="bg-[#003366] p-4 flex justify-between items-center text-white">
              <div>
                <h3 className="font-bold font-montserrat">Suporte Stargrowth</h3>
                <div className="flex items-center gap-2 text-xs opacity-90">
                  <span className="w-2 h-2 bg-green-400 rounded-full"></span>
                  Online agora
                </div>
              </div>
              <button onClick={() => setIsOpen(false)} className="hover:bg-white/10 p-1 rounded">
                <Minus size={20} />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
               {/* Welcome Message */}
               <div className="flex justify-start">
                  <div className="bg-white text-gray-800 p-3 rounded-xl rounded-tl-none shadow-sm max-w-[80%] text-sm">
                     {chatState.config.welcomeMessage}
                  </div>
               </div>

               {activeConversation?.messages.map((msg) => (
                 <div key={msg.id} className={`flex ${msg.sender === 'client' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] p-3 rounded-xl shadow-sm text-sm ${
                       msg.sender === 'client' 
                       ? 'bg-[#003366] text-white rounded-tr-none' 
                       : 'bg-white text-gray-800 rounded-tl-none'
                    }`}>
                       {msg.text}
                    </div>
                 </div>
               ))}
               <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <div className="p-4 bg-white border-t">
              <form onSubmit={handleSend} className="flex gap-2">
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Digite sua mensagem..."
                  className="flex-1 border border-gray-300 rounded-full px-4 py-2 text-sm focus:outline-none focus:border-[#003366]"
                />
                <button 
                  type="submit" 
                  disabled={!message.trim()}
                  className="bg-[#D4AF37] text-[#003366] p-2 rounded-full disabled:opacity-50 hover:bg-[#c4a030] transition-colors"
                >
                  <Send size={18} />
                </button>
              </form>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <button
        onClick={handleToggle}
        className="bg-[#003366] text-white p-4 rounded-full shadow-lg hover:scale-110 transition-transform flex items-center justify-center"
      >
        {isOpen ? <X size={24} /> : <MessageCircle size={24} />}
      </button>
    </div>
  );
};

export default ChatWidget;
