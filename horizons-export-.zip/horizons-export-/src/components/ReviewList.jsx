
import React, { useState } from 'react';
import { Star, ThumbsUp, ThumbsDown, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const ReviewList = ({ reviews }) => {
  const [filterStar, setFilterStar] = useState(0);
  const [sortBy, setSortBy] = useState('recent');

  const filteredReviews = reviews
    .filter(r => filterStar === 0 || r.rating === filterStar)
    .sort((a, b) => {
      if (sortBy === 'recent') return new Date(b.date) - new Date(a.date);
      if (sortBy === 'highest') return b.rating - a.rating;
      if (sortBy === 'lowest') return a.rating - b.rating;
      return 0;
    });

  return (
    <div>
      {/* Filters */}
      <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4 border-b border-gray-100 pb-4">
        <div className="flex flex-wrap gap-2">
          <button 
            onClick={() => setFilterStar(0)}
            className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${filterStar === 0 ? 'bg-[#003366] text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
          >
            Todas
          </button>
          {[5, 4, 3, 2, 1].map(star => (
            <button
              key={star}
              onClick={() => setFilterStar(star)}
              className={`px-3 py-1 rounded-full text-sm font-medium transition-colors flex items-center gap-1 ${filterStar === star ? 'bg-[#003366] text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
            >
              {star} <Star size={12} className="fill-current" />
            </button>
          ))}
        </div>

        <select 
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="border border-gray-300 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
        >
          <option value="recent">Mais Recentes</option>
          <option value="highest">Maior Nota</option>
          <option value="lowest">Menor Nota</option>
        </select>
      </div>

      {/* List */}
      <div className="space-y-4">
        <AnimatePresence>
          {filteredReviews.length > 0 ? (
            filteredReviews.map((review) => (
              <motion.div
                key={review.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm"
              >
                <div className="flex justify-between items-start mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-[#003366] text-white rounded-full flex items-center justify-center font-bold">
                      {review.author.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-bold text-[#003366] text-sm">{review.author}</h4>
                      <div className="flex items-center gap-1">
                        <div className="flex text-[#D4AF37]">
                          {[...Array(5)].map((_, i) => (
                            <Star key={i} size={12} className={i < review.rating ? 'fill-current' : 'text-gray-200'} />
                          ))}
                        </div>
                        <span className="text-xs text-gray-400">• {new Date(review.date).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                  {review.verified && (
                    <span className="flex items-center gap-1 text-xs text-green-600 font-bold bg-green-50 px-2 py-1 rounded-full">
                      <CheckCircle2 size={12} /> Compra Verificada
                    </span>
                  )}
                </div>

                <h5 className="font-bold text-gray-800 mb-2">{review.title}</h5>
                <p className="text-gray-600 text-sm mb-4 leading-relaxed">{review.comment}</p>

                <div className="flex items-center gap-4 text-xs text-gray-500">
                  <button className="flex items-center gap-1 hover:text-[#003366]">
                    <ThumbsUp size={14} /> Útil ({review.helpful || 0})
                  </button>
                  <button className="flex items-center gap-1 hover:text-[#003366]">
                    <ThumbsDown size={14} /> Não útil ({review.notHelpful || 0})
                  </button>
                </div>
              </motion.div>
            ))
          ) : (
             <div className="text-center py-10 text-gray-500">
               Nenhuma avaliação encontrada com este filtro.
             </div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default ReviewList;
