
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShoppingCart, Star, Heart, TrendingUp, Truck, Eye } from 'lucide-react';
import { motion } from 'framer-motion';
import { useCart } from '@/hooks/useCart';
import { useAnalytics } from '@/context/AnalyticsContext'; 
import { useGoogleAnalytics } from '@/context/GoogleAnalyticsContext'; 
import { useToast } from '@/components/ui/use-toast';
import ComparisonModal from '@/components/ComparisonModal';

const ProductCard = ({ product }) => {
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { trackEvent: trackInternalEvent } = useAnalytics();
  const { trackEvent: trackGAEvent } = useGoogleAnalytics();
  const { toast } = useToast();
  const [isHovered, setIsHovered] = useState(false);
  const [isWishlisted, setIsWishlisted] = useState(false);
  const [showComparison, setShowComparison] = useState(false);
  const [viewers, setViewers] = useState(0);

  useEffect(() => {
    const wishlist = JSON.parse(localStorage.getItem('stargrowth_wishlist') || '[]');
    setIsWishlisted(wishlist.some(id => id === product.id));
    // Simulate real-time viewers
    setViewers(Math.floor(Math.random() * 10) + 1);
  }, [product.id]);

  const toggleWishlist = (e) => {
    e.stopPropagation();
    let wishlist = JSON.parse(localStorage.getItem('stargrowth_wishlist') || '[]');
    
    if (isWishlisted) {
      wishlist = wishlist.filter(id => id !== product.id);
      toast({ title: 'Removido dos favoritos', description: 'Produto removido com sucesso.' });
    } else {
      wishlist.push(product.id);
      trackInternalEvent('wishlist_add', { productId: product.id, productName: product.name });
      trackGAEvent('add_to_wishlist', {
        items: [{ item_id: product.id, item_name: product.name }]
      });
      toast({ 
        title: '❤️ Adicionado aos favoritos!', 
        description: 'Produto salvo na sua lista de desejos.',
        className: "bg-gradient-to-r from-[#0a66c2] to-[#D4AF37] text-white border-none"
      });
    }
    
    localStorage.setItem('stargrowth_wishlist', JSON.stringify(wishlist));
    setIsWishlisted(!isWishlisted);
  };

  const handleAddToCart = (e) => {
    e.stopPropagation();
    addToCart(product);
    trackInternalEvent('add_to_cart', { productId: product.id, productName: product.name, price: product.discountPrice });
    trackGAEvent('add_to_cart', {
      currency: 'BRL',
      value: product.discountPrice,
      items: [{ item_id: product.id, item_name: product.name, price: product.discountPrice }]
    });

    toast({
      title: (
        <div className="flex items-center gap-2">
           <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 260, damping: 20 }} className="bg-green-50 rounded-full p-1">
             <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
               <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
             </svg>
           </motion.div>
           <span>Produto adicionado!</span>
        </div>
      ),
      description: `${product.name} já está no seu carrinho.`,
      className: "bg-gradient-to-r from-[#0a66c2] to-[#004182] text-white border-l-4 border-[#D4AF37]",
      duration: 3000,
    });
  };

  const handleCompare = (e) => {
    e.stopPropagation();
    setShowComparison(true);
    trackInternalEvent('compare_click', { productId: product.id });
  };

  const handleProductClick = () => {
    trackInternalEvent('product_view', { productId: product.id, productName: product.name });
    trackGAEvent('select_item', {
      items: [{ item_id: product.id, item_name: product.name }]
    });
    navigate(`/produto/${product.id}`);
  };

  const stockPercent = Math.min(100, (product.stock / 50) * 100);
  const stockColor = product.stock < 10 ? 'bg-red-500' : product.stock < 25 ? 'bg-yellow-500' : 'bg-green-500';

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        whileHover={{ y: -8, scale: 1.02 }}
        transition={{ duration: 0.3 }}
        onHoverStart={() => setIsHovered(true)}
        onHoverEnd={() => setIsHovered(false)}
        className="bg-white/90 backdrop-blur-sm rounded-2xl shadow-lg hover:shadow-2xl overflow-hidden cursor-pointer group border border-gray-100 flex flex-col h-full relative"
        onClick={handleProductClick}
      >
        <button onClick={toggleWishlist} className="absolute top-4 right-4 z-20 p-2 bg-white/80 backdrop-blur-md rounded-full shadow-sm hover:bg-white transition-all hover:scale-110 group-hover:opacity-100">
          <Heart className={`w-5 h-5 transition-colors ${isWishlisted ? 'fill-red-500 text-red-500' : 'text-gray-400 hover:text-red-500'}`} />
        </button>

        {product.stock < 10 && (
          <motion.div 
            animate={{ scale: [1, 1.1, 1] }} 
            transition={{ repeat: Infinity, duration: 1.5 }}
            className="absolute top-4 right-14 z-20 bg-red-600 text-white text-[10px] font-bold px-2 py-1 rounded-full shadow-md"
          >
            Últimas {product.stock} un.
          </motion.div>
        )}

        <div className="relative overflow-hidden aspect-[4/3]">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" loading="lazy" />
          {product.discount > 0 && (
            <motion.div animate={{ scale: [1, 1.05, 1] }} transition={{ repeat: Infinity, duration: 2 }} className="absolute top-4 left-4 bg-gradient-to-r from-red-600 to-red-500 text-white px-3 py-1 rounded-full text-xs font-bold shadow-md z-10">
              -{product.discount}% OFF
            </motion.div>
          )}
          <div className={`absolute inset-0 bg-black/10 transition-opacity duration-300 ${isHovered ? 'opacity-100' : 'opacity-0'}`} />
          <div className={`absolute bottom-0 left-0 right-0 p-4 transform transition-transform duration-300 ${isHovered ? 'translate-y-0' : 'translate-y-full'}`}>
             <button onClick={handleCompare} className="w-full bg-white/90 backdrop-blur text-[#0a66c2] text-xs font-bold py-2 rounded shadow mb-2 hover:bg-white transition-colors">Comparar</button>
          </div>
        </div>

        <div className="p-5 flex flex-col flex-grow">
          <div className="flex flex-wrap gap-2 mb-2">
            {product.freeShipping && <div className="flex items-center gap-1 text-[10px] font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded-full border border-green-100"><Truck className="w-3 h-3" /> Frete Grátis</div>}
            <div className="flex items-center gap-1 text-[10px] font-bold text-[#0a66c2] bg-blue-50 px-2 py-0.5 rounded-full border border-blue-100"><Eye className="w-3 h-3" /> {viewers} vendo</div>
          </div>

          <h3 className="font-montserrat font-bold text-base text-[#0a66c2] mb-1 line-clamp-2 leading-tight group-hover:text-[#D4AF37] transition-colors">{product.name}</h3>

          <div className="flex items-center gap-1 mb-3">
            <div className="flex text-yellow-400">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className={`w-3.5 h-3.5 ${i < Math.floor(product.rating) ? 'fill-current' : 'text-gray-200 fill-gray-200'}`} />
              ))}
            </div>
            <span className="text-xs text-gray-500 font-medium ml-1">({product.reviews})</span>
          </div>

          <div className="mt-auto">
             <div className="flex items-baseline gap-2 mb-1">
              {product.originalPrice > product.discountPrice && <span className="text-xs text-gray-400 line-through">R$ {product.originalPrice.toFixed(2)}</span>}
             </div>
             <div className="flex items-end justify-between">
                <span className="text-xl font-bold text-[#0a66c2]">R$ {product.discountPrice.toFixed(2)}</span>
                <span className="text-xs text-gray-500 mb-1">à vista</span>
             </div>
          </div>
          
          <div className="w-full bg-gray-100 h-1.5 rounded-full mt-3 mb-1 overflow-hidden">
            <motion.div initial={{ width: 0 }} whileInView={{ width: `${stockPercent}%` }} transition={{ duration: 1, delay: 0.2 }} className={`h-full rounded-full ${stockColor}`} />
          </div>
          <div className="flex justify-between items-center mb-3">
             <span className="text-[10px] text-gray-400">Estoque disponível</span>
             {product.stock < 10 && <span className="text-[10px] text-red-500 font-bold animate-pulse">Acabando!</span>}
          </div>

          <motion.button whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.95 }} onClick={handleAddToCart} className="w-full bg-gradient-to-r from-[#0a66c2] to-[#004182] hover:from-[#004182] hover:to-[#0a66c2] text-white font-poppins font-semibold text-sm py-3 rounded-lg flex items-center justify-center gap-2 shadow-md hover:shadow-lg transition-all group-hover:ring-2 ring-[#D4AF37]/50">
            <ShoppingCart className="w-4 h-4" /> Adicionar
          </motion.button>
        </div>
      </motion.div>
      {showComparison && <ComparisonModal product={product} isOpen={showComparison} onClose={(e) => { e?.stopPropagation(); setShowComparison(false); }} />}
    </>
  );
};

export default ProductCard;
