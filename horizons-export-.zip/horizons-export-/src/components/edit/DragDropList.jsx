
import React from 'react';
import { Reorder, useDragControls } from 'framer-motion';
import { GripVertical, Trash2, Edit } from 'lucide-react';

const DragDropItem = ({ item, onEdit, onDelete, children }) => {
  const controls = useDragControls();
  
  return (
    <Reorder.Item
      value={item}
      dragListener={false}
      dragControls={controls}
      className="bg-white border border-gray-200 rounded-lg mb-2 p-3 flex items-center gap-3 shadow-sm select-none"
    >
      <div 
        onPointerDown={(e) => controls.start(e)}
        className="cursor-grab active:cursor-grabbing text-gray-400 hover:text-gray-600 p-1"
      >
        <GripVertical size={20} />
      </div>
      
      <div className="flex-1 min-w-0">
        {children}
      </div>

      <div className="flex gap-1">
        <button onClick={() => onEdit(item)} className="p-2 text-blue-600 hover:bg-blue-50 rounded"><Edit size={18} /></button>
        <button onClick={() => onDelete(item)} className="p-2 text-red-600 hover:bg-red-50 rounded"><Trash2 size={18} /></button>
      </div>
    </Reorder.Item>
  );
};

const DragDropList = ({ items, onReorder, onEdit, onDelete, renderItem }) => {
  return (
    <Reorder.Group axis="y" values={items} onReorder={onReorder} className="space-y-2">
      {items.map((item) => (
        <DragDropItem key={item.id} item={item} onEdit={onEdit} onDelete={onDelete}>
          {renderItem(item)}
        </DragDropItem>
      ))}
    </Reorder.Group>
  );
};

export default DragDropList;
