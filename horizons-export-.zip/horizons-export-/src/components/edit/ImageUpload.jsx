
import React, { useState } from 'react';
import { Upload, X } from 'lucide-react';

const ImageUpload = ({ label, value, onChange }) => {
  const [preview, setPreview] = useState(value);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert('Arquivo muito grande. Máximo 5MB.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreview(reader.result);
        onChange(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleUrlChange = (e) => {
    setPreview(e.target.value);
    onChange(e.target.value);
  };

  return (
    <div className="mb-4">
      {label && <label className="block text-sm font-bold text-gray-700 mb-1">{label}</label>}
      <div className="flex gap-4 items-start">
        <div className="flex-1">
          <input
            type="text"
            value={value}
            onChange={handleUrlChange}
            placeholder="URL da imagem ou upload"
            className="w-full px-4 py-2 mb-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#D4AF37] text-gray-900"
          />
          <div className="relative border-2 border-dashed border-gray-300 rounded-lg p-4 hover:border-[#D4AF37] transition-colors bg-gray-50 text-center">
            <input
              type="file"
              accept="image/*"
              onChange={handleFileChange}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <Upload className="mx-auto h-8 w-8 text-gray-400 mb-2" />
            <p className="text-sm text-gray-500">Clique ou arraste para upload (Max 5MB)</p>
          </div>
        </div>
        {preview && (
          <div className="relative w-24 h-24 border border-gray-200 rounded-lg overflow-hidden bg-white shadow-sm shrink-0">
            <img src={preview} alt="Preview" className="w-full h-full object-cover" />
            <button
              onClick={() => { setPreview(''); onChange(''); }}
              className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-0.5 hover:bg-red-600"
            >
              <X size={12} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ImageUpload;
