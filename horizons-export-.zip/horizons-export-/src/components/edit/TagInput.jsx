
import React, { useState } from 'react';
import { X, Plus } from 'lucide-react';

const TagInput = ({ label, value = [], onChange, placeholder }) => {
  const [input, setInput] = useState('');

  const addTag = (e) => {
    e.preventDefault();
    const val = input.trim();
    if (val && !value.includes(val)) {
      onChange([...value, val]);
      setInput('');
    }
  };

  const removeTag = (tagToRemove) => {
    onChange(value.filter(tag => tag !== tagToRemove));
  };

  return (
    <div className="mb-4">
      {label && <label className="block text-sm font-bold text-gray-700 mb-1">{label}</label>}
      <div className="flex flex-wrap gap-2 mb-2 p-2 border border-gray-200 rounded-lg bg-gray-50 min-h-[40px]">
        {value.map((tag, idx) => (
          <span key={idx} className="bg-white border border-gray-300 text-gray-700 px-2 py-1 rounded-md text-sm flex items-center gap-1">
            {tag}
            <button onClick={() => removeTag(tag)} className="text-gray-400 hover:text-red-500"><X size={14} /></button>
          </span>
        ))}
        {value.length === 0 && <span className="text-gray-400 text-sm italic p-1">Nenhuma tag adicionada</span>}
      </div>
      <form onSubmit={addTag} className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={placeholder || "Adicionar tag..."}
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#D4AF37]"
        />
        <button type="submit" className="bg-[#003366] text-white p-2 rounded-lg hover:bg-[#004d99]">
          <Plus size={20} />
        </button>
      </form>
    </div>
  );
};

export default TagInput;
