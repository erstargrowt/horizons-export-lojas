
import React from 'react';
import { Check, X } from 'lucide-react';

const MultiSelect = ({ label, options, value = [], onChange }) => {
  const toggleOption = (optionValue) => {
    if (value.includes(optionValue)) {
      onChange(value.filter(v => v !== optionValue));
    } else {
      onChange([...value, optionValue]);
    }
  };

  return (
    <div className="mb-4">
      {label && <label className="block text-sm font-bold text-gray-700 mb-1">{label}</label>}
      <div className="flex flex-wrap gap-2 mb-2">
        {value.map(val => {
          const option = options.find(o => o.value === val);
          return (
            <span key={val} className="bg-[#003366] text-white px-2 py-1 rounded-full text-xs flex items-center gap-1">
              {option ? option.label : val}
              <button onClick={() => toggleOption(val)} className="hover:text-red-300"><X size={12} /></button>
            </span>
          );
        })}
      </div>
      <div className="border border-gray-300 rounded-lg max-h-40 overflow-y-auto bg-white">
        {options.map(option => (
          <button
            key={option.value}
            onClick={() => toggleOption(option.value)}
            className="flex items-center justify-between w-full px-4 py-2 hover:bg-gray-50 text-left text-sm"
          >
            <span>{option.label}</span>
            {value.includes(option.value) && <Check size={16} className="text-[#D4AF37]" />}
          </button>
        ))}
      </div>
    </div>
  );
};

export default MultiSelect;
