
import React from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { LayoutDashboard, Save, RotateCcw, Download, Upload, Undo, Redo, Image, List, ShoppingBag, Settings, FileText, Info, ArrowLeft } from 'lucide-react';
import { useEditableContent } from '@/context/EditableContentContext';
import { useToast } from '@/components/ui/use-toast';

const EditLayout = () => {
  const { undo, redo, canUndo, canRedo, resetToDefaults, exportData, importData } = useEditableContent();
  const location = useLocation();
  const { toast } = useToast();

  const menuItems = [
    { path: '/edit-content/hero', icon: Image, label: 'Hero Section' },
    { path: '/edit-content/categories', icon: List, label: 'Categorias' },
    { path: '/edit-products', icon: ShoppingBag, label: 'Produtos' },
    { path: '/edit-blog', icon: FileText, label: 'Blog' },
    { path: '/edit-settings', icon: Settings, label: 'Configurações' },
    { path: '/edit-about', icon: Info, label: 'Sobre Nós' },
  ];

  const handleImport = (e) => {
    if (e.target.files?.[0]) {
      importData(e.target.files[0]);
      toast({ title: "Importado com sucesso!" });
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      {/* Top Bar */}
      <header className="bg-[#003366] text-white h-16 px-4 flex items-center justify-between shadow-md z-20">
        <div className="flex items-center gap-4">
          <Link to="/admin/dashboard" className="hover:bg-white/10 p-2 rounded-full transition-colors">
            <ArrowLeft size={20} />
          </Link>
          <h1 className="font-montserrat font-bold text-lg">Editor de Conteúdo</h1>
        </div>
        
        <div className="flex items-center gap-2">
          <button onClick={undo} disabled={!canUndo} className="p-2 hover:bg-white/10 rounded disabled:opacity-30" title="Desfazer (Ctrl+Z)">
            <Undo size={18} />
          </button>
          <button onClick={redo} disabled={!canRedo} className="p-2 hover:bg-white/10 rounded disabled:opacity-30" title="Refazer (Ctrl+Y)">
            <Redo size={18} />
          </button>
          <div className="h-6 w-px bg-white/20 mx-2"></div>
          <button onClick={resetToDefaults} className="p-2 hover:bg-red-500/50 rounded flex items-center gap-2 text-sm">
            <RotateCcw size={16} /> Restaurar Padrão
          </button>
          <button onClick={exportData} className="p-2 hover:bg-white/10 rounded flex items-center gap-2 text-sm">
            <Download size={16} /> Exportar
          </button>
          <label className="p-2 hover:bg-white/10 rounded flex items-center gap-2 text-sm cursor-pointer">
            <Upload size={16} /> Importar
            <input type="file" onChange={handleImport} accept=".json" className="hidden" />
          </label>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className="w-64 bg-white border-r border-gray-200 overflow-y-auto">
          <nav className="p-4 space-y-1">
            {menuItems.map(item => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                  location.pathname === item.path
                    ? 'bg-[#003366] text-white'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                <item.icon size={18} />
                {item.label}
              </Link>
            ))}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto bg-gray-50 p-8">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="max-w-4xl mx-auto bg-white rounded-xl shadow-sm border border-gray-200 p-6"
          >
            <Outlet />
          </motion.div>
        </main>
      </div>
    </div>
  );
};

export default EditLayout;
