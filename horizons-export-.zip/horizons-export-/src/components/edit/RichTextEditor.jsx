
import React from 'react';
import { Bold, Italic, Underline, Link, List } from 'lucide-react';

const RichTextEditor = ({ label, value, onChange, placeholder }) => {
  // Simplistic implementation using textarea for robustness, as full WYSIWYG is complex
  // In a real app, use Tiptap or Quill. Here we simulate basic formatting for data storage
  // but just use a textarea for input to ensure stability.

  return (
    <div className="mb-4">
      {label && <label className="block text-sm font-bold text-gray-700 mb-1">{label}</label>}
      <div className="border border-gray-300 rounded-lg overflow-hidden bg-white focus-within:ring-2 focus-within:ring-[#D4AF37]">
        <div className="bg-gray-50 border-b border-gray-200 p-2 flex gap-2">
          <button type="button" className="p-1 hover:bg-gray-200 rounded text-gray-600" title="Bold"><Bold size={16} /></button>
          <button type="button" className="p-1 hover:bg-gray-200 rounded text-gray-600" title="Italic"><Italic size={16} /></button>
          <button type="button" className="p-1 hover:bg-gray-200 rounded text-gray-600" title="Underline"><Underline size={16} /></button>
          <div className="w-px h-6 bg-gray-300 mx-1"></div>
          <button type="button" className="p-1 hover:bg-gray-200 rounded text-gray-600" title="List"><List size={16} /></button>
          <button type="button" className="p-1 hover:bg-gray-200 rounded text-gray-600" title="Link"><Link size={16} /></button>
        </div>
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder || "Digite seu texto aqui (HTML básico suportado)..."}
          className="w-full p-4 min-h-[150px] outline-none resize-y"
        />
      </div>
      <p className="text-xs text-gray-400 mt-1">Suporta HTML básico para formatação.</p>
    </div>
  );
};

export default RichTextEditor;
