
import React, { useState } from 'react';
import * as Icons from 'lucide-react';
import { Search, X } from 'lucide-react';

const popularIcons = [
  'ShoppingBag', 'ShoppingCart', 'CreditCard', 'Truck', 'Shield', 'ShieldCheck', 'Lock', 'Unlock',
  'User', 'Users', 'UserCheck', 'Star', 'Heart', 'ThumbsUp', 'Award', 'Badge', 'Zap', 'Activity',
  'Smartphone', 'Watch', 'Tablet', 'Laptop', 'Monitor', 'Speaker', 'Headphones', 'Camera', 'Video',
  'Mail', 'Phone', 'MessageCircle', 'Send', 'Globe', 'MapPin', 'Home', 'Store', 'Building',
  'ArrowRight', 'ArrowLeft', 'ChevronRight', 'ChevronLeft', 'Check', 'X', 'Plus', 'Minus',
  'Clock', 'Calendar', 'Timer', 'Sun', 'Moon', 'Cloud', 'Droplets', 'Wind', 'Coffee', 'Gift',
  'Percent', 'DollarSign', 'Tag', 'Bookmark', 'BookOpen', 'FileText', 'Image', 'Music', 'Baby',
  'Sparkles', 'Crown', 'Cpu', 'Book'
];

const IconPicker = ({ value, onChange, label }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');

  const filteredIcons = popularIcons.filter(icon => 
    icon.toLowerCase().includes(search.toLowerCase())
  );

  const SelectedIcon = Icons[value] || Icons.HelpCircle;

  return (
    <div className="mb-4">
      {label && <label className="block text-sm font-bold text-gray-700 mb-1">{label}</label>}
      
      {isOpen ? (
        <div className="border border-gray-300 rounded-lg p-4 bg-white shadow-lg relative z-50">
          <div className="flex justify-between items-center mb-3">
            <div className="relative flex-1 mr-2">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Buscar ícone..."
                className="w-full pl-8 pr-3 py-1.5 border border-gray-200 rounded text-sm focus:outline-none focus:border-[#D4AF37]"
                autoFocus
              />
            </div>
            <button onClick={() => setIsOpen(false)} className="text-gray-400 hover:text-gray-600">
              <X size={20} />
            </button>
          </div>
          
          <div className="grid grid-cols-6 gap-2 max-h-60 overflow-y-auto">
            {filteredIcons.map(iconName => {
              const Icon = Icons[iconName];
              if (!Icon) return null;
              return (
                <button
                  key={iconName}
                  onClick={() => { onChange(iconName); setIsOpen(false); }}
                  className={`p-2 rounded flex flex-col items-center justify-center gap-1 hover:bg-gray-100 transition-colors ${value === iconName ? 'bg-blue-50 border border-blue-200' : ''}`}
                  title={iconName}
                >
                  <Icon size={20} />
                </button>
              );
            })}
          </div>
        </div>
      ) : (
        <button
          onClick={() => setIsOpen(true)}
          className="flex items-center gap-3 px-4 py-2 border border-gray-300 rounded-lg bg-white hover:bg-gray-50 w-full text-left"
        >
          <div className="w-8 h-8 bg-gray-100 rounded flex items-center justify-center text-[#003366]">
            <SelectedIcon size={20} />
          </div>
          <span className="flex-1 font-medium">{value || 'Selecione um ícone'}</span>
          <span className="text-xs text-gray-400">Alterar</span>
        </button>
      )}
    </div>
  );
};

export default IconPicker;
