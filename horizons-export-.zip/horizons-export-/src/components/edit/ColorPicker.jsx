
import React from 'react';

const presets = [
  { name: 'Azul Profundo', value: '#003366' },
  { name: 'Branco', value: '#FFFFFF' },
  { name: 'Ouro', value: '#D4AF37' },
  { name: 'Prata', value: '#C0C0C0' },
  { name: 'Preto', value: '#000000' },
  { name: 'Cinza', value: '#F3F4F6' }
];

const ColorPicker = ({ label, value, onChange }) => {
  return (
    <div className="mb-4">
      {label && <label className="block text-sm font-bold text-gray-700 mb-1">{label}</label>}
      <div className="flex items-center gap-3">
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-12 h-12 rounded cursor-pointer border-2 border-gray-200 p-1 bg-white"
        />
        <input
          type="text"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-32 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-[#D4AF37] uppercase"
        />
        <div className="flex gap-2 flex-wrap">
          {presets.map(preset => (
            <button
              key={preset.value}
              onClick={() => onChange(preset.value)}
              className="w-8 h-8 rounded-full border border-gray-200 shadow-sm hover:scale-110 transition-transform"
              style={{ backgroundColor: preset.value }}
              title={preset.name}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ColorPicker;
