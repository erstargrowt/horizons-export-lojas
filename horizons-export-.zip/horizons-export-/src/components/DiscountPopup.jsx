
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Gift, Copy, Check } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useEmails } from '@/context/EmailContext';

const DiscountPopup = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [showCode, setShowCode] = useState(false);
  const [discountCode, setDiscountCode] = useState('');
  const [isCopied, setIsCopied] = useState(false);
  const { toast } = useToast();
  const { addEmail } = useEmails();

  useEffect(() => {
    const hasVisited = localStorage.getItem('stargrowth_first_visit');
    const isSubscribed = localStorage.getItem('stargrowth_subscribed');

    if (!hasVisited && !isSubscribed) {
      const timer = setTimeout(() => {
        setIsOpen(true);
        localStorage.setItem('stargrowth_first_visit', 'true');
      }, 4000);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleSubscribe = (e) => {
    e.preventDefault();
    if (email && email.includes('@')) {
      const code = `BEMVINDO15${Math.floor(1000 + Math.random() * 9000)}`;
      setDiscountCode(code);
      setShowCode(true);
      
      // Save email via context
      addEmail(email);
      localStorage.setItem('stargrowth_subscribed', 'true');
      
      toast({ title: "Inscrição confirmada!", className: "bg-green-50 text-green-800" });
    } else {
      toast({ title: "Email inválido", description: "Por favor, insira um email válido.", variant: "destructive" });
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(discountCode);
    setIsCopied(true);
    toast({ 
      title: "Código copiado!", 
      description: "Use no checkout para ganhar 15% OFF.",
      className: "bg-green-50 border-green-200 text-green-800"
    });
    setTimeout(() => setIsCopied(false), 3000);
  };

  const handleClose = () => {
    setIsOpen(false);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 50 }}
            transition={{ type: 'spring', damping: 20, stiffness: 300 }}
            className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden relative"
          >
            <button 
              onClick={handleClose}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600 z-10 p-1 bg-white/50 rounded-full"
            >
              <X size={20} />
            </button>

            <div className="bg-gradient-to-r from-[#003366] to-[#004d99] p-8 text-center relative overflow-hidden">
               <div className="absolute top-0 left-0 w-full h-full opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]"></div>
               <div className="w-16 h-16 bg-[#D4AF37] rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg animate-bounce">
                  <Gift size={32} className="text-white" />
               </div>
               <h2 className="text-2xl font-bold text-white font-montserrat mb-2">Bem-vindo à Stargrowth!</h2>
               <p className="text-[#D4AF37] font-bold text-lg uppercase tracking-wider">Ganhe 15% de Desconto</p>
            </div>

            <div className="p-8">
              {!showCode ? (
                <>
                  <p className="text-gray-600 text-center mb-6 font-poppins">
                    Inscreva-se em nossa lista VIP e receba um cupom exclusivo para sua primeira compra agora mesmo!
                  </p>
                  <form onSubmit={handleSubscribe} className="space-y-4">
                    <div>
                      <input 
                        type="email" 
                        placeholder="Seu melhor email" 
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#D4AF37] bg-gray-50 text-gray-900"
                        required
                      />
                    </div>
                    <button type="submit" className="w-full bg-gradient-to-r from-[#D4AF37] to-[#B4941F] text-[#003366] font-bold py-3 rounded-lg hover:shadow-lg transition-all transform hover:scale-[1.02]">
                      Desbloquear Meu Desconto
                    </button>
                  </form>
                  <p className="text-xs text-gray-400 text-center mt-4">Respeitamos sua privacidade. Cancele quando quiser.</p>
                </>
              ) : (
                <div className="text-center">
                  <p className="text-gray-600 mb-4 font-medium">Parabéns! Aqui está seu código exclusivo:</p>
                  <div className="bg-gray-100 border-2 border-dashed border-[#D4AF37] rounded-xl p-4 mb-6 relative cursor-pointer group" onClick={copyToClipboard}>
                    <span className="text-2xl font-bold text-[#003366] tracking-widest font-mono">{discountCode}</span>
                    <div className="absolute inset-0 flex items-center justify-center bg-black/5 opacity-0 group-hover:opacity-100 transition-opacity rounded-xl">
                      <span className="text-xs font-bold text-gray-600">Clique para copiar</span>
                    </div>
                  </div>
                  <button onClick={copyToClipboard} className={`w-full py-3 rounded-lg font-bold transition-all flex items-center justify-center gap-2 ${isCopied ? 'bg-green-500 text-white' : 'bg-[#003366] text-white hover:bg-[#004d99]'}`}>
                    {isCopied ? <><Check size={20} /> Código Copiado!</> : <><Copy size={20} /> Copiar Código</>}
                  </button>
                  <button onClick={handleClose} className="mt-4 text-gray-500 text-sm hover:text-[#003366] underline">Continuar comprando</button>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default DiscountPopup;
