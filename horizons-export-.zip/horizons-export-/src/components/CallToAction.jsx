
import React from 'react';
import { motion } from 'framer-motion';
import { BellRing } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const CallToAction = () => {
  const navigate = useNavigate();

  return (
    <div className="container mx-auto px-4 text-center">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="max-w-2xl mx-auto"
      >
        <div className="inline-block p-3 bg-white/10 rounded-full mb-6 backdrop-blur-sm">
           <BellRing className="text-[#D4AF37] w-8 h-8 animate-pulse" />
        </div>

        <h2 className="text-3xl md:text-4xl font-montserrat font-bold text-white mb-4">
          Não Perca Nossas Ofertas Exclusivas
        </h2>
        
        <p className="text-gray-200 font-poppins text-lg mb-8">
          Receba notificações de novos produtos e descontos especiais. <br/>
          <span className="text-[#D4AF37] font-bold">Ofertas limitadas - Aproveite enquanto há estoque!</span>
        </p>
        
        <motion.button
          onClick={() => navigate('/categorias')}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="bg-gradient-to-r from-[#D4AF37] to-[#B4941F] text-[#0a66c2] font-montserrat font-bold text-lg px-10 py-4 rounded-full shadow-[0_0_20px_rgba(212,175,55,0.4)] hover:shadow-[0_0_30px_rgba(212,175,55,0.6)] transition-all"
        >
          Receber Ofertas Agora
        </motion.button>
      </motion.div>
    </div>
  );
};

export default CallToAction;
