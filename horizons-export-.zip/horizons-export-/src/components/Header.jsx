
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingCart as ShoppingCartIcon, Menu, X, Search, User, LogOut } from 'lucide-react';
import { useCart } from '@/hooks/useCart';
import { useCustomerAuth } from '@/context/CustomerAuthContext';
import { motion, AnimatePresence } from 'framer-motion';
import Logo from '@/components/Logo';
import ShoppingCartSidebar from '@/components/ShoppingCart';

const Header = () => {
  const { cartItems } = useCart();
  const { currentUser, logout } = useCustomerAuth();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();

  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/categorias?search=${encodeURIComponent(searchQuery)}`);
    }
  };

  const handleLogout = () => {
    logout();
    setIsUserMenuOpen(false);
    navigate('/');
  };

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Departamentos', path: '/departamentos' },
    { name: 'Categorias', path: '/categorias' },
    { name: 'Quem Somos', path: '/quem-somos' },
    { name: 'Contato', path: '/contato' },
  ];

  return (
    <>
      <header className="bg-white shadow-md font-poppins relative z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between gap-4 md:gap-8">
            
            {/* Logo & Mobile Menu Button */}
            <div className="flex items-center gap-4">
              <button 
                className="lg:hidden p-2 text-[#0a66c2]"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>

              <Logo />
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-8 text-sm font-medium text-[#0a66c2]">
              {navLinks.map((link) => (
                <Link key={link.path} to={link.path} className="hover:text-[#D4AF37] transition-colors uppercase tracking-wide">
                  {link.name}
                </Link>
              ))}
            </nav>

            {/* Search Bar */}
            <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-md relative">
              <input 
                type="text" 
                placeholder="O que você procura hoje?" 
                className="w-full pl-4 pr-10 py-2.5 rounded-full border border-gray-200 focus:border-[#0a66c2] focus:ring-1 focus:ring-[#0a66c2] outline-none text-sm transition-all"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-[#0a66c2] rounded-full text-white hover:bg-[#004182] transition-colors">
                <Search size={16} />
              </button>
            </form>

            {/* Actions */}
            <div className="flex items-center gap-4">
               <button 
                 onClick={() => setIsCartOpen(true)}
                 className="relative p-2 hover:bg-gray-100 rounded-full text-[#0a66c2] transition-colors"
               >
                 <ShoppingCartIcon size={24} />
                 {cartCount > 0 && (
                   <span className="absolute -top-1 -right-1 bg-[#D4AF37] text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center shadow-sm animate-pulse">
                     {cartCount}
                   </span>
                 )}
               </button>

               {/* User Menu */}
               <div className="relative">
                 {currentUser ? (
                   <button 
                     onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                     className="flex items-center gap-2 px-3 py-1.5 bg-gray-50 hover:bg-gray-100 rounded-full border border-gray-200 transition-colors"
                   >
                     <div className="w-8 h-8 rounded-full bg-[#0a66c2] text-white flex items-center justify-center font-bold text-xs">
                       {currentUser.name.charAt(0).toUpperCase()}
                     </div>
                     <span className="text-sm font-medium text-[#0a66c2] hidden md:block">
                       Olá, {currentUser.name.split(' ')[0]}
                     </span>
                   </button>
                 ) : (
                   <Link to="/login" className="flex items-center gap-2 text-[#0a66c2] font-medium hover:text-[#D4AF37] transition-colors">
                     <User size={24} />
                     <span className="hidden md:block text-sm">Entrar</span>
                   </Link>
                 )}
                 
                 <AnimatePresence>
                  {isUserMenuOpen && currentUser && (
                    <motion.div
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      transition={{ duration: 0.2 }}
                      className="absolute right-0 top-full mt-2 w-48 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden z-50 origin-top-right"
                    >
                      <div className="bg-[#0a66c2] px-4 py-3">
                        <p className="text-xs text-white/70">Logado como</p>
                        <p className="text-sm font-bold text-white truncate">{currentUser.email}</p>
                      </div>
                      <Link to="/minha-conta" onClick={() => setIsUserMenuOpen(false)} className="block px-4 py-3 text-sm text-gray-700 hover:bg-gray-50 transition-colors">Minha Conta</Link>
                      <Link to="/minha-conta?tab=orders" onClick={() => setIsUserMenuOpen(false)} className="block px-4 py-3 text-sm text-gray-700 hover:bg-gray-50 transition-colors">Meus Pedidos</Link>
                      <div className="h-px bg-gray-100 my-1"></div>
                      <button onClick={handleLogout} className="w-full text-left px-4 py-3 text-sm text-red-600 hover:bg-red-50 flex items-center gap-2 transition-colors">
                        <LogOut size={16} /> Sair
                      </button>
                    </motion.div>
                  )}
                 </AnimatePresence>
               </div>
            </div>
          </div>

          {/* Mobile Search Bar (visible only on small screens) */}
          <form onSubmit={handleSearch} className="mt-4 md:hidden relative">
            <input 
              type="text" 
              placeholder="O que você procura hoje?" 
              className="w-full pl-4 pr-10 py-2.5 rounded-lg border border-gray-200 focus:border-[#0a66c2] focus:ring-1 focus:ring-[#0a66c2] outline-none text-sm"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 text-[#0a66c2]">
              <Search size={20} />
            </button>
          </form>
        </div>

        {/* Mobile Menu Overlay */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, x: -300 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -300 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              className="fixed inset-y-0 left-0 w-64 bg-white shadow-2xl z-50 lg:hidden flex flex-col"
            >
              <div className="p-5 border-b border-gray-100 flex justify-between items-center bg-[#0a66c2] text-white">
                <span className="font-montserrat font-bold text-lg">Menu</span>
                <button onClick={() => setIsMenuOpen(false)} className="text-white">
                  <X size={24} />
                </button>
              </div>
              
              <div className="flex-1 overflow-y-auto py-4">
                <div className="flex flex-col space-y-1">
                  {navLinks.map((link) => (
                    <Link 
                      key={link.path} 
                      to={link.path} 
                      className="px-6 py-3 text-[#0a66c2] font-medium hover:bg-blue-50 hover:text-[#D4AF37] transition-colors border-l-4 border-transparent hover:border-[#D4AF37]"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      {link.name}
                    </Link>
                  ))}
                </div>
                
                <div className="mt-6 pt-6 border-t border-gray-100 px-6">
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">Minha Conta</p>
                  {!currentUser ? (
                    <Link to="/login" onClick={() => setIsMenuOpen(false)} className="flex items-center gap-3 text-[#0a66c2] font-bold py-2">
                      <User size={20} /> Entrar / Cadastrar
                    </Link>
                  ) : (
                    <>
                      <Link to="/minha-conta" onClick={() => setIsMenuOpen(false)} className="flex items-center gap-3 text-[#0a66c2] py-2">
                        <User size={20} /> Meu Perfil
                      </Link>
                      <button onClick={() => { handleLogout(); setIsMenuOpen(false); }} className="flex items-center gap-3 text-red-600 py-2 w-full text-left mt-2">
                        <LogOut size={20} /> Sair
                      </button>
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Backdrop for mobile menu */}
        {isMenuOpen && (
          <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setIsMenuOpen(false)} />
        )}
      </header>

      {/* Cart Sidebar */}
      <ShoppingCartSidebar isCartOpen={isCartOpen} setIsCartOpen={setIsCartOpen} />
    </>
  );
};

export default Header;
