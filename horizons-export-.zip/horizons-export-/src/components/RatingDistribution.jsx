
import React from 'react';
import { Star } from 'lucide-react';

const RatingDistribution = ({ reviews }) => {
  const totalReviews = reviews.length;
  const averageRating = totalReviews > 0 
    ? (reviews.reduce((acc, r) => acc + r.rating, 0) / totalReviews).toFixed(1)
    : 0;

  const distribution = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
  reviews.forEach(r => distribution[r.rating] = (distribution[r.rating] || 0) + 1);

  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 mb-8">
      <div className="flex flex-col md:flex-row gap-8 items-center">
        {/* Average Display */}
        <div className="text-center md:w-1/3">
          <div className="text-5xl font-bold text-[#003366] mb-2">{averageRating}</div>
          <div className="flex justify-center text-[#D4AF37] mb-2">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className={`w-6 h-6 ${i < Math.round(averageRating) ? 'fill-current' : 'text-gray-200'}`} />
            ))}
          </div>
          <p className="text-gray-500 text-sm">{totalReviews} avaliações</p>
        </div>

        {/* Bars */}
        <div className="flex-1 w-full space-y-2">
          {[5, 4, 3, 2, 1].map(star => {
            const count = distribution[star];
            const percent = totalReviews > 0 ? (count / totalReviews) * 100 : 0;
            return (
              <div key={star} className="flex items-center gap-3 text-sm">
                <span className="font-bold text-gray-600 w-3">{star}</span>
                <Star className="w-4 h-4 text-[#D4AF37] fill-current" />
                <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-[#D4AF37] rounded-full"
                    style={{ width: `${percent}%` }}
                  />
                </div>
                <span className="text-gray-400 w-8 text-right">{count}</span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default RatingDistribution;
