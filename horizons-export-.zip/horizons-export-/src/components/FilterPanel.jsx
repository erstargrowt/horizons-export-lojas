
import React from 'react';
import { Slider } from '@/components/ui/slider';
import { Star } from 'lucide-react';

const FilterPanel = ({ filters, setFilters, categories, maxPrice }) => {
  return (
    <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
      <h3 className="font-bold text-[#003366] mb-6">Filtros</h3>

      {/* Categories */}
      <div className="mb-6">
        <h4 className="text-sm font-bold text-gray-700 mb-3">Categorias</h4>
        <div className="space-y-2">
          {categories.map(cat => (
            <label key={cat} className="flex items-center gap-2 cursor-pointer">
              <input 
                type="radio" 
                name="category"
                checked={filters.category === cat}
                onChange={() => setFilters({ ...filters, category: cat })}
                className="text-[#003366] focus:ring-[#003366]"
              />
              <span className="text-sm text-gray-600 hover:text-[#003366]">{cat}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Price */}
      <div className="mb-6">
        <h4 className="text-sm font-bold text-gray-700 mb-3">Preço</h4>
        <Slider 
          defaultValue={[0, maxPrice]} 
          max={maxPrice} 
          step={10} 
          value={filters.priceRange} 
          onValueChange={(val) => setFilters({...filters, priceRange: val})}
          className="mb-2"
        />
        <div className="flex justify-between text-xs text-gray-500 font-medium">
          <span>R$ {filters.priceRange[0]}</span>
          <span>R$ {filters.priceRange[1]}</span>
        </div>
      </div>

      {/* Rating */}
      <div>
        <h4 className="text-sm font-bold text-gray-700 mb-3">Avaliação Mínima</h4>
        <div className="space-y-2">
          {[4, 3, 2, 1].map(rating => (
            <button
              key={rating}
              onClick={() => setFilters({ ...filters, rating })}
              className={`flex items-center gap-1 text-sm w-full p-1 rounded hover:bg-gray-50 ${filters.rating === rating ? 'bg-blue-50 font-bold text-[#003366]' : 'text-gray-600'}`}
            >
              <div className="flex text-yellow-400">
                 {[...Array(5)].map((_, i) => (
                    <Star key={i} size={14} className={i < rating ? 'fill-current' : 'text-gray-300'} />
                 ))}
              </div>
              <span className="ml-1">& acima</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FilterPanel;
