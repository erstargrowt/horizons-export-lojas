
import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';

const Breadcrumb = ({ items }) => {
  // Schema.org BreadcrumbList
  const schema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": window.location.origin
      },
      ...items.map((item, index) => ({
        "@type": "ListItem",
        "position": index + 2,
        "name": item.label,
        "item": window.location.origin + item.path
      }))
    ]
  };

  return (
    <>
      <script type="application/ld+json">
        {JSON.stringify(schema)}
      </script>
      <nav className="flex items-center text-sm text-gray-500 mb-6 font-poppins overflow-x-auto whitespace-nowrap py-2">
        <Link to="/" className="hover:text-[#D4AF37] flex items-center gap-1 transition-colors">
          <Home size={14} /> Home
        </Link>
        {items.map((item, index) => (
          <React.Fragment key={index}>
            <ChevronRight className="w-4 h-4 mx-2 text-gray-400 flex-shrink-0" />
            {index === items.length - 1 ? (
              <span className="text-[#003366] font-semibold truncate">{item.label}</span>
            ) : (
              <Link to={item.path} className="hover:text-[#D4AF37] transition-colors truncate">
                {item.label}
              </Link>
            )}
          </React.Fragment>
        ))}
      </nav>
    </>
  );
};

export default Breadcrumb;
