
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const Logo = () => {
  return (
    <Link to="/" className="block">
      <motion.div 
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="flex items-center gap-2"
      >
        <img 
          src="https://images.unsplash.com/photo-1640190213120-cc920c9c39f4" 
          alt="Stargrowth Logo" 
          className="w-10 h-10 md:w-12 md:h-12 object-cover rounded-full shadow-md border-2 border-[#D4AF37]" 
        />
        <span className="text-xl md:text-2xl font-montserrat font-bold bg-gradient-to-r from-[#0a66c2] to-[#D4AF37] bg-clip-text text-transparent">
          Stargrowth
        </span>
      </motion.div>
    </Link>
  );
};

export default Logo;
