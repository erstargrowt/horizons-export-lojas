
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';

const NotificationContext = createContext();

export const useNotifications = () => useContext(NotificationContext);

const defaultTemplates = {
  nova_venda: 'Nova venda realizada! Pedido #{pedido_id} no valor de R$ {valor}. Cliente: {cliente_nome}.',
  pedido_confirmado: 'Olá {cliente_nome}, seu pedido #{pedido_id} foi confirmado com sucesso! Obrigado por comprar conosco.',
  pedido_enviado: 'Boas notícias, {cliente_nome}! Seu pedido #{pedido_id} foi enviado. Acompanhe pelo link: {link_rastreamento}',
  pedido_entregue: 'Olá {cliente_nome}, seu pedido #{pedido_id} foi entregue. Esperamos que goste!',
  carrinho_abandonado: 'Oi {cliente_nome}, notamos que você deixou itens no carrinho. Volte e finalize sua compra com 5% de desconto!',
  cupom_aplicado: 'Você aplicou o cupom {cupom_codigo} com sucesso!',
  novo_contato: 'Novo contato recebido de {cliente_nome}. Assunto: {assunto}.'
};

const defaultHistory = [
  { id: 1, date: new Date().toISOString(), type: 'whatsapp', client: 'João Silva', order: '#1234', status: 'enviado', action: 'Pedido Confirmado' },
  { id: 2, date: new Date(Date.now() - 86400000).toISOString(), type: 'email', client: 'Maria Santos', order: '#1235', status: 'pendente', action: 'Carrinho Abandonado' },
];

export const NotificationProvider = ({ children }) => {
  const { toast } = useToast();
  
  const [config, setConfig] = useState(() => {
    const saved = localStorage.getItem('stargrowth_notifications');
    return saved ? JSON.parse(saved) : {
      channels: {
        whatsapp: false,
        sms: false,
        email: true
      },
      credentials: {
        whatsappApiKey: '',
        whatsappPhoneId: '',
        whatsappNumber: '',
        smsAccountSid: '',
        smsAuthToken: '',
        smsNumber: ''
      },
      templates: defaultTemplates,
      history: defaultHistory
    };
  });

  useEffect(() => {
    localStorage.setItem('stargrowth_notifications', JSON.stringify(config));
  }, [config]);

  const saveNotificationConfig = (newConfig) => {
    setConfig(prev => ({ ...prev, ...newConfig }));
    toast({ title: "Configurações de notificação salvas!" });
  };

  const updateTemplate = (key, text) => {
    setConfig(prev => ({
      ...prev,
      templates: { ...prev.templates, [key]: text }
    }));
    toast({ title: "Template atualizado!" });
  };

  const sendNotification = (type, data, channel = 'email') => {
    // Simulate sending
    const template = config.templates[type] || '';
    let message = template;
    
    // Simple interpolation
    Object.keys(data).forEach(key => {
      message = message.replace(`{${key}}`, data[key]);
    });

    const newLog = {
      id: Date.now(),
      date: new Date().toISOString(),
      type: channel,
      client: data.cliente_nome || 'Cliente',
      order: data.pedido_id || '-',
      status: 'enviado',
      action: type.replace('_', ' ').toUpperCase()
    };

    setConfig(prev => ({
      ...prev,
      history: [newLog, ...prev.history]
    }));

    toast({ title: `Notificação enviada via ${channel}!` });
    return true;
  };

  const deleteNotificationLog = (id) => {
    setConfig(prev => ({
      ...prev,
      history: prev.history.filter(h => h.id !== id)
    }));
    toast({ title: "Log removido." });
  };

  return (
    <NotificationContext.Provider value={{
      config,
      saveNotificationConfig,
      updateTemplate,
      sendNotification,
      deleteNotificationLog
    }}>
      {children}
    </NotificationContext.Provider>
  );
};
