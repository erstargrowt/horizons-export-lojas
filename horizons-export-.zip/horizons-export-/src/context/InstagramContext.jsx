
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';

const InstagramContext = createContext();

export const useInstagram = () => useContext(InstagramContext);

// Mock Data generator
const generateMockPosts = (count) => {
  return Array.from({ length: count }).map((_, i) => ({
    id: `post_${i}`,
    image: `https://source.unsplash.com/random/400x400?fashion,style&sig=${i}`,
    caption: `Nova coleção chegando com tudo! Confira as novidades em nosso site. #moda #estilo #stargrowth ${i}`,
    likes: Math.floor(Math.random() * 500) + 50,
    comments: Math.floor(Math.random() * 50) + 5,
    date: new Date(Date.now() - (i * 86400000)).toISOString(),
    link: 'https://instagram.com'
  }));
};

export const InstagramProvider = ({ children }) => {
  const { toast } = useToast();

  const [instagramState, setInstagramState] = useState(() => {
    const saved = localStorage.getItem('stargrowth_instagram');
    return saved ? JSON.parse(saved) : {
      config: {
        businessId: '',
        accessToken: '',
        active: true
      },
      display: {
        count: 12,
        showOnHome: true,
        sectionText: 'Siga-nos no Instagram para novidades exclusivas!'
      },
      posts: generateMockPosts(12),
      lastUpdated: new Date().toISOString()
    };
  });

  useEffect(() => {
    localStorage.setItem('stargrowth_instagram', JSON.stringify(instagramState));
  }, [instagramState]);

  const saveConfig = (newConfig) => {
    setInstagramState(prev => ({
      ...prev,
      config: { ...prev.config, ...newConfig }
    }));
    toast({ title: "Configurações do Instagram salvas!" });
  };

  const updateDisplay = (newDisplay) => {
    setInstagramState(prev => ({
      ...prev,
      display: { ...prev.display, ...newDisplay }
    }));
    toast({ title: "Configurações de exibição atualizadas!" });
  };

  const refreshFeed = () => {
    // In a real app, this would fetch from Instagram Graph API
    const newPosts = generateMockPosts(instagramState.display.count);
    setInstagramState(prev => ({
      ...prev,
      posts: newPosts,
      lastUpdated: new Date().toISOString()
    }));
    toast({ title: "Feed atualizado com sucesso!" });
  };

  return (
    <InstagramContext.Provider value={{
      instagramState,
      saveConfig,
      updateDisplay,
      refreshFeed
    }}>
      {children}
    </InstagramContext.Provider>
  );
};
