
import React, { createContext, useContext, useState, useEffect } from 'react';

const CouponContext = createContext();

export const useCoupons = () => useContext(CouponContext);

export const CouponProvider = ({ children }) => {
  const [coupons, setCoupons] = useState(() => {
    const saved = localStorage.getItem('stargrowth_coupons');
    return saved ? JSON.parse(saved) : [
      { id: 1, code: 'BEMVINDO15', type: 'percentage', value: 15, maxUses: 1000, used: 45, expiration: '2026-12-31', status: 'active', description: 'Desconto de boas-vindas' },
      { id: 2, code: 'FRETEGRATIS', type: 'fixed', value: 20, maxUses: 500, used: 120, expiration: '2025-12-31', status: 'active', description: 'Frete grátis fixo' }
    ];
  });

  useEffect(() => {
    localStorage.setItem('stargrowth_coupons', JSON.stringify(coupons));
  }, [coupons]);

  const addCoupon = (coupon) => {
    setCoupons([...coupons, { ...coupon, id: Date.now(), used: 0, status: 'active' }]);
  };

  const updateCoupon = (id, updatedData) => {
    setCoupons(coupons.map(c => c.id === id ? { ...c, ...updatedData } : c));
  };

  const deleteCoupon = (id) => {
    setCoupons(coupons.filter(c => c.id !== id));
  };

  const validateCoupon = (code, cartTotal) => {
    const coupon = coupons.find(c => c.code === code && c.status === 'active');
    if (!coupon) return { valid: false, message: 'Cupom inválido ou inativo.' };

    if (new Date(coupon.expiration) < new Date()) return { valid: false, message: 'Este cupom expirou.' };
    if (coupon.used >= coupon.maxUses) return { valid: false, message: 'Limite de usos atingido.' };

    let discountAmount = 0;
    if (coupon.type === 'percentage') {
      discountAmount = (cartTotal * coupon.value) / 100;
    } else {
      discountAmount = coupon.value;
    }

    // Ensure discount doesn't exceed total
    discountAmount = Math.min(discountAmount, cartTotal);

    return { 
      valid: true, 
      coupon: { ...coupon, discountAmount },
      message: 'Cupom aplicado com sucesso!' 
    };
  };

  const incrementUsage = (code) => {
    setCoupons(coupons.map(c => c.code === code ? { ...c, used: c.used + 1 } : c));
  };

  return (
    <CouponContext.Provider value={{ coupons, addCoupon, updateCoupon, deleteCoupon, validateCoupon, incrementUsage }}>
      {children}
    </CouponContext.Provider>
  );
};
