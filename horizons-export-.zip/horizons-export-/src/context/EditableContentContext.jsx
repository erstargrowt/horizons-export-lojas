
import React, { createContext, useContext, useState, useEffect } from 'react';
import { products as defaultProducts } from '@/data/products';
import { blogPosts as defaultBlogPosts } from '@/data/blog';

// Default Data
const defaultHero = {
  headline: 'Qualidade Premium com Preços que Cabem no Seu Bolso',
  subheadline: 'Mais de 15.000 clientes satisfeitos | Frete Grátis acima de R$ 200 | Garantia de 30 dias',
  ctaText: 'Descubra Ofertas Exclusivas Agora',
  backgroundImage: 'https://images.unsplash.com/photo-1642452222105-b2933e287da4',
  backgroundColor: '#003366'
};

const defaultCategories = [
  { id: '1', name: 'Eletrônicos', icon: 'Smartphone', color: 'from-blue-500 to-blue-600', desc: 'Tecnologia que conecta você ao futuro' },
  { id: '2', name: 'Relógios', icon: 'Watch', color: 'from-amber-500 to-amber-600', desc: 'Relógios de Luxo com Preços Acessíveis' },
  { id: '3', name: 'Kids', icon: 'Baby', color: 'from-pink-500 to-pink-600', desc: 'Brinquedos que educam e divertem' },
  { id: '4', name: 'Cosméticos', icon: 'Sparkles', color: 'from-purple-500 to-purple-600', desc: 'Beleza que vem de dentro para fora' },
  { id: '5', name: 'eBooks', icon: 'BookOpen', color: 'from-green-500 to-green-600', desc: 'Conhecimento que transforma vidas' },
  { id: '6', name: 'Novidades', icon: 'Zap', color: 'from-red-500 to-red-600', desc: 'Descubra o que há de novo no mercado' },
];

const defaultBenefits = [
  { id: '1', icon: 'Truck', title: 'Frete Grátis', description: 'Compre sem preocupação - Frete Grátis acima de R$ 200 para todo o Brasil.', color: 'from-blue-500 to-blue-600' },
  { id: '2', icon: 'ShieldCheck', title: 'Satisfação Garantida', description: '30 dias para devolver - Reembolso 100% garantido sem perguntas.', color: 'from-amber-500 to-amber-600' },
  { id: '3', icon: 'MessageCircle', title: 'Suporte 24h', description: 'Suporte via WhatsApp para ajudar você a qualquer hora do dia.', color: 'from-green-500 to-green-600' },
  { id: '4', icon: 'Lock', title: 'Dados Protegidos', description: 'Criptografia bancária de ponta a ponta - Suas informações 100% seguras.', color: 'from-purple-500 to-purple-600' }
];

const defaultTestimonials = [
  { id: 1, name: 'João Silva', location: 'São Paulo, SP', image: 'https://images.unsplash.com/photo-1558154839-19f6ddb31384', rating: 5, text: 'Comprei pensando que era caro, mas a qualidade justifica cada centavo.', verified: true },
  { id: 2, name: 'Maria Santos', location: 'Rio de Janeiro, RJ', image: 'https://images.unsplash.com/photo-1599856413870-40540dd55110', rating: 5, text: 'Chegou rápido, bem embalado e exatamente como descrito no site.', verified: true },
  { id: 3, name: 'Carlos Oliveira', location: 'Belo Horizonte, MG', image: 'https://images.unsplash.com/photo-1623336411935-beb214d8ce01', rating: 5, text: 'Melhor compra que fiz este ano. O suporte foi impecável.', verified: true }
];

const defaultGuarantee = {
  headline: 'Compre com Confiança Total',
  description: 'Sua satisfação é garantida. Se não ficar 100% satisfeito, devolvemos seu dinheiro em até 30 dias - sem perguntas, sem burocracia.',
  image: 'ShieldCheck', // Icon name or URL
  points: ['Devolução Fácil', 'Reembolso Rápido', 'Risco Zero']
};

const defaultCertifications = [
  { id: '1', icon: 'Lock', label: 'Site SSL Seguro', desc: 'Dados Criptografados', color: '#003366' },
  { id: '2', icon: 'CreditCard', label: 'Pagamento Seguro', desc: 'Processamento Verificado', color: '#003366' },
  { id: '3', icon: 'Shield', label: 'Compra Protegida', desc: 'Garantia de Entrega', color: '#003366' },
  { id: '4', icon: 'Award', label: 'Avaliado por Clientes', desc: 'Qualidade Comprovada', color: '#003366' },
];

const defaultStores = [
  { id: '1', name: 'Loja de Relógios', description: 'Elegância e precisão', category: 'Relógios', icon: 'Watch', color: '#D4AF37' },
  { id: '2', name: 'Loja Galen', description: 'Cosméticos premium', category: 'Cosméticos', icon: 'Sparkles', color: '#D4AF37' },
  { id: '3', name: 'Conceito Premium', description: 'Produtos exclusivos', category: 'Novidades', icon: 'Crown', color: '#D4AF37' },
  { id: '4', name: 'Loja Falco', description: 'Tecnologia de ponta', category: 'Eletrônicos', icon: 'Zap', color: '#D4AF37' },
];

const defaultSettings = {
  companyInfo: {
    name: 'Stargrowth',
    email: 'contato@stargrowth.com.br',
    phone: '5511999999999',
    address: 'Av. Paulista, 1000 - São Paulo, SP',
    businessHours: 'Seg-Sex: 9h às 18h'
  },
  colors: {
    primary: '#003366',
    secondary: '#D4AF37',
    background: '#FFFFFF',
    text: '#333333'
  },
  social: {
    facebook: 'https://facebook.com',
    instagram: 'https://instagram.com',
    twitter: '',
    linkedin: '',
    youtube: '',
    tiktok: ''
  },
  policies: {
    terms: 'Termos de uso padrão...',
    privacy: 'Política de privacidade padrão...',
    exchange: 'Política de troca padrão...',
    delivery: 'Política de entrega padrão...'
  },
  shipping: {
    freeShippingThreshold: 200,
    message: 'Frete Grátis acima de R$ 200',
    standardRate: 20,
    deliveryDays: 5
  }
};

const defaultAbout = {
  founder: { 
    name: 'Natan Ribeiro', 
    title: 'CEO & Fundador', 
    bio: 'Apaixonado por tecnologia e inovação, com mais de 25 anos de experiência.', 
    photo: 'https://horizons-cdn.hostinger.com/f50c14b4-5de5-4f32-b526-1484686f041d/e49cc7e020819855ca2b7c730a0ef51d.png',
    experience: '25 Anos',
    specialties: ['Liderança', 'Inovação', 'E-commerce']
  },
  team: [
    { id: 1, name: 'Ana Silva', position: 'Diretora de Marketing', description: 'Especialista em branding.', photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330' },
    { id: 2, name: 'Carlos Santos', position: 'CTO', description: 'Líder de tecnologia.', photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e' }
  ],
  mission: 'Transformar a experiência de compra online.',
  vision: 'Ser referência global em qualidade e atendimento.',
  values: [{ id: 1, title: 'Inovação', desc: 'Sempre buscando o novo.' }, { id: 2, title: 'Ética', desc: 'Transparência em tudo.' }]
};

const EditableContentContext = createContext();

export const useEditableContent = () => useContext(EditableContentContext);

export const EditableContentProvider = ({ children }) => {
  const [content, setContent] = useState(() => {
    try {
      const saved = localStorage.getItem('stargrowth_content');
      return saved ? { ...JSON.parse(saved) } : {
        hero: defaultHero,
        categories: defaultCategories,
        benefits: defaultBenefits,
        testimonials: defaultTestimonials,
        guarantee: defaultGuarantee,
        certifications: defaultCertifications,
        stores: defaultStores,
        products: defaultProducts,
        blogPosts: defaultBlogPosts,
        settings: defaultSettings,
        about: defaultAbout
      };
    } catch (e) {
      console.error("Failed to load content", e);
      return {
        hero: defaultHero,
        categories: defaultCategories,
        benefits: defaultBenefits,
        testimonials: defaultTestimonials,
        guarantee: defaultGuarantee,
        certifications: defaultCertifications,
        stores: defaultStores,
        products: defaultProducts,
        blogPosts: defaultBlogPosts,
        settings: defaultSettings,
        about: defaultAbout
      };
    }
  });

  const [history, setHistory] = useState([]);
  const [redoStack, setRedoStack] = useState([]);

  useEffect(() => {
    localStorage.setItem('stargrowth_content', JSON.stringify(content));
  }, [content]);

  const updateContent = (section, data) => {
    setHistory(prev => [...prev.slice(-49), content]);
    setRedoStack([]);
    setContent(prev => ({ ...prev, [section]: data }));
  };

  const undo = () => {
    if (history.length === 0) return;
    const previous = history[history.length - 1];
    setRedoStack(prev => [content, ...prev]);
    setContent(previous);
    setHistory(prev => prev.slice(0, -1));
  };

  const redo = () => {
    if (redoStack.length === 0) return;
    const next = redoStack[0];
    setHistory(prev => [...prev, content]);
    setContent(next);
    setRedoStack(prev => prev.slice(1));
  };

  const resetToDefaults = () => {
    if (window.confirm('Tem certeza que deseja restaurar o padrão? Todas as alterações serão perdidas.')) {
      setContent({
        hero: defaultHero,
        categories: defaultCategories,
        benefits: defaultBenefits,
        testimonials: defaultTestimonials,
        guarantee: defaultGuarantee,
        certifications: defaultCertifications,
        stores: defaultStores,
        products: defaultProducts,
        blogPosts: defaultBlogPosts,
        settings: defaultSettings,
        about: defaultAbout
      });
      setHistory([]);
      setRedoStack([]);
    }
  };

  const exportData = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(content));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", `stargrowth_backup_${new Date().toISOString()}.json`);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  const importData = (file) => {
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const importedData = JSON.parse(event.target.result);
        if (window.confirm('Isso irá sobrescrever todo o conteúdo atual. Continuar?')) {
          setContent(importedData);
        }
      } catch (e) {
        alert('Erro ao importar arquivo. Formato inválido.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <EditableContentContext.Provider value={{
      ...content,
      updateContent,
      undo,
      redo,
      canUndo: history.length > 0,
      canRedo: redoStack.length > 0,
      resetToDefaults,
      exportData,
      importData
    }}>
      {children}
    </EditableContentContext.Provider>
  );
};
