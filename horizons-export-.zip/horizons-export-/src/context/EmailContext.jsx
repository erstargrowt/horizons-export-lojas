
import React, { createContext, useContext, useState, useEffect } from 'react';

const EmailContext = createContext();

export const useEmails = () => useContext(EmailContext);

export const EmailProvider = ({ children }) => {
  const [emails, setEmails] = useState(() => {
    const saved = localStorage.getItem('stargrowth_email_list');
    return saved ? JSON.parse(saved) : [
      { id: 1, email: 'cliente@exemplo.com', status: 'engajado', date: '2024-01-15T10:00:00Z' },
      { id: 2, email: 'novo@teste.com', status: 'novo', date: '2024-02-20T14:30:00Z' }
    ];
  });

  const [campaigns, setCampaigns] = useState(() => {
    const saved = localStorage.getItem('stargrowth_campaigns');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('stargrowth_email_list', JSON.stringify(emails));
  }, [emails]);

  useEffect(() => {
    localStorage.setItem('stargrowth_campaigns', JSON.stringify(campaigns));
  }, [campaigns]);

  const addEmail = (email) => {
    if (!emails.find(e => e.email === email)) {
      setEmails([...emails, { id: Date.now(), email, status: 'novo', date: new Date().toISOString() }]);
    }
  };

  const updateEmailStatus = (id, status) => {
    setEmails(emails.map(e => e.id === id ? { ...e, status } : e));
  };

  const deleteEmail = (id) => {
    setEmails(emails.filter(e => e.id !== id));
  };

  const createCampaign = (campaign) => {
    setCampaigns([...campaigns, { ...campaign, id: Date.now(), sent: 0, openRate: 0, clickRate: 0, status: 'agendado' }]);
  };

  const deleteCampaign = (id) => {
    setCampaigns(campaigns.filter(c => c.id !== id));
  };

  return (
    <EmailContext.Provider value={{ emails, addEmail, updateEmailStatus, deleteEmail, campaigns, createCampaign, deleteCampaign }}>
      {children}
    </EmailContext.Provider>
  );
};
