
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';

const ChatContext = createContext();

export const useChat = () => useContext(ChatContext);

const defaultConversations = [
  {
    id: '1',
    clientId: 'c1',
    clientName: 'João Silva',
    clientEmail: 'joao@email.com',
    clientPhone: '11999999999',
    status: 'aberta', // aberta, fechada, aguardando
    agentId: null,
    createdAt: new Date(Date.now() - 1000000).toISOString(),
    lastMessageAt: new Date(Date.now() - 5000).toISOString(),
    messages: [
      { id: 'm1', sender: 'client', text: 'Olá, gostaria de saber sobre o prazo de entrega.', timestamp: new Date(Date.now() - 1000000).toISOString() },
      { id: 'm2', sender: 'agent', text: 'Olá João! O prazo depende do seu CEP. Qual seria?', timestamp: new Date(Date.now() - 50000).toISOString() },
      { id: 'm3', sender: 'client', text: '01001-000', timestamp: new Date(Date.now() - 5000).toISOString() }
    ],
    lastOrder: { date: '2023-10-15', value: 'R$ 450,00', status: 'Entregue' }
  }
];

const defaultQuickReplies = [
  { id: '1', text: 'Olá! Como posso ajudar você hoje?' },
  { id: '2', text: 'Nosso horário de atendimento é das 9h às 18h.' },
  { id: '3', text: 'O prazo de entrega é de 3 a 5 dias úteis.' },
  { id: '4', text: 'Posso confirmar seu número de pedido?' }
];

const defaultAgents = [
  { id: 'a1', name: 'Suporte Geral', email: 'suporte@stargrowth.com', status: 'online' }
];

export const ChatProvider = ({ children }) => {
  const { toast } = useToast();
  
  const [chatState, setChatState] = useState(() => {
    const saved = localStorage.getItem('stargrowth_chat');
    return saved ? JSON.parse(saved) : {
      conversations: defaultConversations,
      config: {
        active: true,
        startTime: '09:00',
        endTime: '18:00',
        welcomeMessage: 'Olá! Bem-vindo ao suporte Stargrowth. Como podemos ajudar?',
        offlineMessage: 'No momento estamos offline. Deixe sua mensagem e responderemos em breve.',
        responseTime: '5', // minutos
      },
      quickReplies: defaultQuickReplies,
      agents: defaultAgents,
      currentUserStatus: 'online' 
    };
  });

  const [notificationSound] = useState(new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3'));

  useEffect(() => {
    localStorage.setItem('stargrowth_chat', JSON.stringify(chatState));
  }, [chatState]);

  const addMessage = (conversationId, text, sender = 'client') => {
    const newMessage = {
      id: Date.now().toString(),
      sender,
      text,
      timestamp: new Date().toISOString()
    };

    if (sender === 'client') {
      try {
        notificationSound.play();
      } catch (e) {
        console.log('Audio play failed', e);
      }
    }

    setChatState(prev => {
      const updatedConversations = prev.conversations.map(conv => {
        if (conv.id === conversationId) {
          return {
            ...conv,
            messages: [...conv.messages, newMessage],
            lastMessageAt: new Date().toISOString(),
            status: sender === 'client' ? 'aguardando' : 'aberta'
          };
        }
        return conv;
      });
      return { ...prev, conversations: updatedConversations };
    });
  };

  const createConversation = (clientData) => {
    const newConv = {
      id: Date.now().toString(),
      ...clientData,
      status: 'aberta',
      agentId: null,
      createdAt: new Date().toISOString(),
      lastMessageAt: new Date().toISOString(),
      messages: [],
      lastOrder: null
    };
    
    setChatState(prev => ({
      ...prev,
      conversations: [newConv, ...prev.conversations]
    }));
    return newConv.id;
  };

  const updateConfig = (newConfig) => {
    setChatState(prev => ({ ...prev, config: { ...prev.config, ...newConfig } }));
    toast({ title: "Configurações de chat atualizadas!" });
  };

  const addAgent = (agent) => {
    setChatState(prev => ({ ...prev, agents: [...prev.agents, { ...agent, id: Date.now().toString(), status: 'offline' }] }));
  };
  
  const removeAgent = (id) => {
     setChatState(prev => ({ ...prev, agents: prev.agents.filter(a => a.id !== id) }));
  };

  return (
    <ChatContext.Provider value={{
      chatState,
      addMessage,
      createConversation,
      updateConfig,
      addAgent,
      removeAgent,
      setChatState
    }}>
      {children}
    </ChatContext.Provider>
  );
};
