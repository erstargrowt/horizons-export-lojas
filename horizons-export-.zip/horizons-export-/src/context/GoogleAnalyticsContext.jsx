
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';

const GoogleAnalyticsContext = createContext();

export const useGoogleAnalytics = () => useContext(GoogleAnalyticsContext);

export const GoogleAnalyticsProvider = ({ children }) => {
  const location = useLocation();
  const { toast } = useToast();
  
  const [config, setConfig] = useState(() => {
    const saved = localStorage.getItem('stargrowth_ga_config');
    return saved ? JSON.parse(saved) : {
      trackingId: '',
      propertyId: '',
      enabled: false,
      customEvents: true,
      conversions: true,
      userBehavior: true
    };
  });

  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    localStorage.setItem('stargrowth_ga_config', JSON.stringify(config));
  }, [config]);

  // Initialize GA Script
  useEffect(() => {
    if (config.enabled && config.trackingId && !isInitialized) {
      // Inject script
      const script = document.createElement('script');
      script.src = `https://www.googletagmanager.com/gtag/js?id=${config.trackingId}`;
      script.async = true;
      document.head.appendChild(script);

      window.dataLayer = window.dataLayer || [];
      function gtag(){window.dataLayer.push(arguments);}
      window.gtag = gtag;
      gtag('js', new Date());
      gtag('config', config.trackingId);
      
      setIsInitialized(true);
      console.log('Google Analytics Initialized:', config.trackingId);
    }
  }, [config.enabled, config.trackingId, isInitialized]);

  // Track Page Views
  useEffect(() => {
    if (config.enabled && isInitialized) {
      window.gtag('config', config.trackingId, {
        page_path: location.pathname + location.search,
      });
      console.log('Page View Tracked:', location.pathname);
    }
  }, [location, config.enabled, isInitialized, config.trackingId]);

  const testConnection = () => {
    return new Promise((resolve, reject) => {
      // Simulation of a connection test
      setTimeout(() => {
        if (config.trackingId.startsWith('G-')) {
          resolve(true);
        } else {
          reject(new Error('Formato de ID inválido'));
        }
      }, 1500);
    });
  };

  const trackEvent = (eventName, params = {}) => {
    if (!config.enabled || !isInitialized) return;
    
    // Check if event type is enabled
    if (
      (eventName === 'purchase' && !config.conversions) ||
      (!['purchase', 'page_view'].includes(eventName) && !config.customEvents)
    ) {
      return;
    }

    window.gtag('event', eventName, params);
    console.log(`Event Tracked [${eventName}]:`, params);
  };

  const trackConversion = (value, currency = 'BRL', transactionId) => {
    if (!config.enabled || !isInitialized || !config.conversions) return;
    
    window.gtag('event', 'purchase', {
      transaction_id: transactionId,
      value: value,
      currency: currency
    });
    console.log('Conversion Tracked:', { value, transactionId });
  };

  const saveConfig = (newConfig) => {
    setConfig(newConfig);
    toast({ title: 'Configurações do Google Analytics salvas!' });
  };

  return (
    <GoogleAnalyticsContext.Provider value={{
      config,
      saveConfig,
      testConnection,
      trackEvent,
      trackConversion
    }}>
      {children}
    </GoogleAnalyticsContext.Provider>
  );
};
