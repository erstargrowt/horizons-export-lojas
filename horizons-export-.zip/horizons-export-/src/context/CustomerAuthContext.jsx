
import React, { createContext, useContext, useState, useEffect } from 'react';

const CustomerAuthContext = createContext();

export const useCustomerAuth = () => useContext(CustomerAuthContext);

export const CustomerAuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Load session from localStorage on mount
  useEffect(() => {
    const storedUser = localStorage.getItem('stargrowth_customer_session');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  const login = (email, password) => {
    const customers = JSON.parse(localStorage.getItem('stargrowth_customers') || '[]');
    // Simple local validation
    const user = customers.find(c => c.email === email && c.password === password);
    
    if (user) {
      const sessionUser = { ...user };
      delete sessionUser.password; // Don't store password in session for security
      localStorage.setItem('stargrowth_customer_session', JSON.stringify(sessionUser));
      setCurrentUser(sessionUser);
      return { success: true };
    }
    return { success: false, message: 'Email ou senha inválidos' };
  };

  const signup = (userData) => {
    const customers = JSON.parse(localStorage.getItem('stargrowth_customers') || '[]');
    
    // Check if email already exists
    if (customers.find(c => c.email === userData.email)) {
      return { success: false, message: 'Email já cadastrado' };
    }

    const newUser = { 
      id: Date.now(), 
      ...userData, 
      createdAt: new Date().toISOString() 
    };
    
    const updatedCustomers = [...customers, newUser];
    localStorage.setItem('stargrowth_customers', JSON.stringify(updatedCustomers));
    
    // Auto login after signup
    const sessionUser = { ...newUser };
    delete sessionUser.password;
    localStorage.setItem('stargrowth_customer_session', JSON.stringify(sessionUser));
    setCurrentUser(sessionUser);
    
    return { success: true };
  };

  const logout = () => {
    localStorage.removeItem('stargrowth_customer_session');
    setCurrentUser(null);
  };

  const updateProfile = (data) => {
    if (!currentUser) return;
    
    const customers = JSON.parse(localStorage.getItem('stargrowth_customers') || '[]');
    const updatedCustomers = customers.map(c => c.id === currentUser.id ? { ...c, ...data } : c);
    localStorage.setItem('stargrowth_customers', JSON.stringify(updatedCustomers));
    
    const updatedUser = { ...currentUser, ...data };
    localStorage.setItem('stargrowth_customer_session', JSON.stringify(updatedUser));
    setCurrentUser(updatedUser);
    return { success: true };
  };

  const recoverPassword = (email) => {
    const customers = JSON.parse(localStorage.getItem('stargrowth_customers') || '[]');
    const user = customers.find(c => c.email === email);
    
    if (user) {
      // In a real app, send email. Here we just simulate success.
      return { success: true, message: 'Link de recuperação enviado para seu email.' };
    }
    // For security, usually returns success even if not found, but for local dev:
    return { success: false, message: 'Email não encontrado.' };
  };

  return (
    <CustomerAuthContext.Provider value={{ 
      currentUser, 
      login, 
      signup, 
      logout, 
      updateProfile, 
      recoverPassword,
      loading 
    }}>
      {!loading && children}
    </CustomerAuthContext.Provider>
  );
};
