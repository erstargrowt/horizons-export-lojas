
import React, { createContext, useContext, useState, useEffect } from 'react';

const AnalyticsContext = createContext();

export const useAnalytics = () => useContext(AnalyticsContext);

export const AnalyticsProvider = ({ children }) => {
  const [events, setEvents] = useState(() => {
    const saved = localStorage.getItem('stargrowth_analytics_events');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('stargrowth_analytics_events', JSON.stringify(events));
  }, [events]);

  const trackEvent = (type, data = {}) => {
    const newEvent = {
      id: Date.now() + Math.random(),
      type,
      timestamp: new Date().toISOString(),
      ...data
    };
    setEvents(prev => [...prev, newEvent]);
  };

  const getEventsByType = (type) => events.filter(e => e.type === type);

  // Helper to generate chart data
  const getDailyVisits = (days = 30) => {
    const data = [];
    const now = new Date();
    for (let i = days - 1; i >= 0; i--) {
      const date = new Date(now);
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      const count = events.filter(e => e.type === 'page_view' && e.timestamp.startsWith(dateStr)).length;
      data.push({ date: date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }), visitors: count + Math.floor(Math.random() * 50) }); // + random noise for demo
    }
    return data;
  };

  return (
    <AnalyticsContext.Provider value={{ events, trackEvent, getEventsByType, getDailyVisits }}>
      {children}
    </AnalyticsContext.Provider>
  );
};
