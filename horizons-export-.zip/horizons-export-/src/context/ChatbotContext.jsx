
import React, { createContext, useContext, useState, useEffect } from 'react';
import { useToast } from '@/components/ui/use-toast';

const ChatbotContext = createContext();

export const useChatbot = () => useContext(ChatbotContext);

const defaultFaqs = [
  { id: '1', question: 'Qual o prazo de entrega?', answer: 'O prazo de entrega varia de acordo com seu CEP, geralmente entre 3 a 7 dias úteis.' },
  { id: '2', question: 'Como faço uma troca?', answer: 'Você pode solicitar a troca através do nosso painel de "Meus Pedidos" em até 30 dias após o recebimento.' },
  { id: '3', question: 'Quais as formas de pagamento?', answer: 'Aceitamos cartão de crédito em até 12x, boleto bancário e PIX com 5% de desconto.' }
];

export const ChatbotProvider = ({ children }) => {
  const { toast } = useToast();
  
  const [config, setConfig] = useState(() => {
    const saved = localStorage.getItem('stargrowth_chatbot_config');
    return saved ? JSON.parse(saved) : {
      apiKey: '',
      model: 'gpt-3.5-turbo',
      enabled: true,
      temperature: 0.7,
      maxTokens: 150,
      systemContext: 'Você é um assistente virtual útil e amigável da loja Stargrowth. Responda com clareza e educação.',
      faqs: defaultFaqs
    };
  });

  const [history, setHistory] = useState(() => {
    const saved = localStorage.getItem('stargrowth_chatbot_history');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('stargrowth_chatbot_config', JSON.stringify(config));
  }, [config]);

  useEffect(() => {
    localStorage.setItem('stargrowth_chatbot_history', JSON.stringify(history));
  }, [history]);

  const saveConfig = (newConfig) => {
    setConfig(newConfig);
    toast({ title: 'Configurações do Chatbot salvas!' });
  };

  const addFaq = (question, answer) => {
    const newFaq = { id: Date.now().toString(), question, answer };
    setConfig(prev => ({ ...prev, faqs: [...prev.faqs, newFaq] }));
    toast({ title: 'FAQ adicionada com sucesso!' });
  };

  const deleteFaq = (id) => {
    setConfig(prev => ({ ...prev, faqs: prev.faqs.filter(f => f.id !== id) }));
    toast({ title: 'FAQ removida.' });
  };

  const sendMessage = async (message, conversationId = null) => {
    // Simulate AI response logic
    let responseText = "Desculpe, não entendi. Pode reformular?";
    
    // Simple Keyword matching from FAQs for demo purposes
    const lowerMsg = message.toLowerCase();
    const matchedFaq = config.faqs.find(f => lowerMsg.includes(f.question.toLowerCase()) || lowerMsg.split(' ').some(w => w.length > 4 && f.question.toLowerCase().includes(w)));
    
    if (matchedFaq) {
      responseText = matchedFaq.answer;
    } else {
      // Mock generic response
      responseText = "Entendi sua dúvida. Vou verificar isso para você. Enquanto isso, gostaria de ver nossas ofertas?";
    }

    const newMessage = { sender: 'user', text: message, timestamp: new Date().toISOString() };
    const botResponse = { sender: 'bot', text: responseText, timestamp: new Date().toISOString() };

    // Update History
    setHistory(prev => {
      let updatedHistory = [...prev];
      let conversationIndex = updatedHistory.findIndex(c => c.id === conversationId);
      
      if (conversationIndex >= 0) {
        updatedHistory[conversationIndex].messages.push(newMessage, botResponse);
        updatedHistory[conversationIndex].lastMessage = new Date().toISOString();
      } else {
        updatedHistory.push({
          id: conversationId || Date.now().toString(),
          clientName: 'Visitante',
          startTime: new Date().toISOString(),
          lastMessage: new Date().toISOString(),
          status: 'active',
          messages: [newMessage, botResponse],
          satisfaction: null
        });
      }
      return updatedHistory;
    });

    return responseText;
  };

  const getAnalytics = () => {
    const total = history.length;
    const resolved = history.filter(h => h.status === 'resolved').length;
    const satisfaction = history.filter(h => h.satisfaction === 'thumbsUp').length;
    
    return {
      totalConversations: total,
      resolutionRate: total > 0 ? ((resolved / total) * 100).toFixed(1) : 0,
      satisfactionRate: total > 0 ? ((satisfaction / total) * 100).toFixed(1) : 0,
    };
  };

  return (
    <ChatbotContext.Provider value={{
      config,
      history,
      saveConfig,
      addFaq,
      deleteFaq,
      sendMessage,
      getAnalytics
    }}>
      {children}
    </ChatbotContext.Provider>
  );
};
