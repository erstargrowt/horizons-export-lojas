
import React, { createContext, useContext, useState, useEffect } from 'react';

const AdminAuthContext = createContext();

export const useAdminAuth = () => useContext(AdminAuthContext);

export const AdminAuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);

  // Load session from localStorage on mount
  useEffect(() => {
    const token = localStorage.getItem('stargrowth_admin_token');
    if (token === 'admin_secret_token') {
      setIsAuthenticated(true);
    }
    setLoading(false);
  }, []);

  const login = (email, password) => {
    // Hardcoded credentials for local development
    if (email === 'admin@stargrowth.com.br' && password === 'admin123') {
      localStorage.setItem('stargrowth_admin_token', 'admin_secret_token');
      setIsAuthenticated(true);
      return true;
    }
    return false;
  };

  const logout = () => {
    localStorage.removeItem('stargrowth_admin_token');
    setIsAuthenticated(false);
  };

  return (
    <AdminAuthContext.Provider value={{ isAuthenticated, login, logout, loading }}>
      {!loading && children}
    </AdminAuthContext.Provider>
  );
};
